import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  timeout: 30000,
  workers: 1,
  reporter: "list",
  use: {
    baseURL: "http://127.0.0.1:8001",
    headless: true,
    viewport: { width: 1440, height: 1060 },
    screenshot: "only-on-failure",
  },
  webServer: {
    command: "cd .. && .venv/bin/python scripts/e2e_server.py",
    url: "http://127.0.0.1:8001/api/health",
    reuseExistingServer: false,
  },
});
