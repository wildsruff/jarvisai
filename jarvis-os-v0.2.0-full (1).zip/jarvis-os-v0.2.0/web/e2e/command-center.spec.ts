import { test, expect, Page } from "@playwright/test";

async function login(page: Page) {
  await page.goto("/");
  await page
    .getByLabel("Administrator password")
    .fill("e2e-password-for-local-tests");
  await page.getByRole("button", { name: "Connect to JARVIS" }).click();
  await expect(
    page.getByRole("heading", { name: "Estate overview", exact: true }),
  ).toBeVisible();
}
async function nav(page: Page, name: string) {
  await page
    .getByRole("navigation")
    .getByRole("button", { name, exact: true })
    .click();
}

test("all fifteen views render without browser errors; desktop screenshot", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await login(page);
  await page.screenshot({
    path: "../docs/screenshots/overview-desktop.png",
    fullPage: true,
  });
  for (const name of [
    "AI Conversation",
    "Digital Twin",
    "Environment",
    "Devices",
    "Automations",
    "Security",
    "Energy",
    "Robotics",
    "AI Agents",
    "Memory",
    "Research",
    "Development Lab",
    "System Diagnostics",
    "Administration",
  ]) {
    await nav(page, name);
    await expect(
      page.getByRole("heading", { name, exact: true }),
    ).toBeVisible();
  }
  expect(errors).toEqual([]);
});

test("chat streams, memories can be corrected and deleted, automation dry-run works", async ({
  page,
}) => {
  await login(page);
  await nav(page, "AI Conversation");
  await page
    .getByLabel("Message JARVIS")
    .fill("Give me an estate status overview");
  await page.getByRole("button", { name: "Send message", exact: true }).click();
  await expect(page.locator(".message.assistant").last()).toContainText(
    "simulated estate",
  );
  await expect(
    page.getByRole("heading", { name: "Inference metrics" }),
  ).toBeVisible();
  await nav(page, "Memory");
  await page.getByRole("button", { name: "Add memory", exact: true }).click();
  await page
    .getByRole("textbox", { name: "Content", exact: true })
    .fill("E2E: the study is preferred for reading.");
  await page.getByRole("button", { name: "Save memory" }).click();
  const card = page
    .locator(".memory-card")
    .filter({ hasText: "E2E: the study" });
  await expect(card).toBeVisible();
  await card.getByRole("button", { name: "Inspect / correct" }).click();
  await page
    .getByRole("textbox", { name: "Content", exact: true })
    .fill("E2E: the living room is preferred for reading.");
  await page.getByLabel("I have verified this information").check();
  await page.getByRole("button", { name: "Save memory" }).click();
  const corrected = page
    .locator(".memory-card")
    .filter({ hasText: "E2E: the living room" });
  await expect(corrected).toContainText("Verified");
  await corrected
    .getByRole("button", { name: "Delete memory", exact: true })
    .click();
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Delete memory" })
    .click();
  await expect(corrected).toHaveCount(0);
  await nav(page, "Automations");
  await page
    .getByRole("button", { name: "Dry-run", exact: true })
    .first()
    .click();
  await expect(page.getByRole("dialog")).toContainText(
    "No devices were changed.",
  );
});

test("device change, anonymous spatial event, simulated safety event, research and proposal review", async ({
  page,
}) => {
  await login(page);
  await nav(page, "Devices");
  const card = page
    .locator(".device-card")
    .filter({ hasText: "Living room" })
    .filter({ hasText: "Lighting" });
  await card.getByRole("slider").fill("47");
  await card.getByRole("button", { name: "Apply", exact: true }).click();
  await expect(card).toContainText("MANUAL OVERRIDE");
  await nav(page, "Digital Twin");
  await page.getByLabel("Simulate occupancy").fill("3");
  await page.getByRole("button", { name: "Update detections" }).click();
  await expect(page.getByRole("status")).toContainText("occupancy updated");
  await nav(page, "Security");
  await page.getByRole("button", { name: "Inject simulated event" }).click();
  await expect(page.locator(".alert-card").last()).toContainText("SMOKE");
  await page
    .getByRole("button", { name: "Acknowledge", exact: true })
    .last()
    .click();
  await page.getByRole("button", { name: "Restore normal conditions" }).click();
  await expect(
    page.getByRole("heading", { name: "No active simulated events" }),
  ).toBeVisible();
  await nav(page, "Research");
  await page.getByRole("button", { name: "Prepare research" }).click();
  await expect(page.locator(".research-card").first()).toContainText(
    "not a completed web search",
    { timeout: 10000 },
  );
  await nav(page, "Development Lab");
  await page.getByRole("button", { name: "New improvement proposal" }).click();
  await page
    .getByLabel("Title", { exact: true })
    .fill("E2E accessible trend comparison");
  await page
    .getByLabel("Problem, plan, tests & rollback")
    .fill(
      "Compare yesterday and today, verify chart labels, revert the UI commit if needed.",
    );
  await page.getByLabel("Affected components").fill("dashboard");
  await page.getByRole("button", { name: "Submit for plan review" }).click();
  await page
    .locator(".proposal-grid .panel")
    .last()
    .getByRole("button", { name: "Approve plan" })
    .click();
  await expect(page.locator(".proposal-grid .panel").last()).toContainText(
    "plan-approved",
  );
});

test("mobile navigation and layout fit a phone", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await login(page);
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(390);
  await page.screenshot({
    path: "../docs/screenshots/overview-mobile.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Open navigation" }).click();
  await nav(page, "AI Conversation");
  await expect(page.getByLabel("Message JARVIS")).toBeVisible();
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(390);
});

test("candidate memory requires approval and exposes correction history", async ({
  page,
}) => {
  await login(page);
  await nav(page, "AI Conversation");
  await page
    .getByLabel("Message JARVIS")
    .fill("I prefer a quiet workspace for reading.");
  await page.getByRole("button", { name: "Send message", exact: true }).click();
  await expect(page.locator(".message.assistant").last()).not.toContainText(
    "Thinking locally",
  );
  await nav(page, "Memory");
  const candidate = page
    .locator(".memory-candidate")
    .filter({ hasText: "quiet workspace" });
  await expect(candidate).toBeVisible();
  await expect(
    page.locator(".memory-card").filter({ hasText: "quiet workspace" }),
  ).toHaveCount(0);
  await candidate
    .getByRole("button", { name: "Approve memory", exact: true })
    .click();
  const card = page
    .locator(".memory-card")
    .filter({ hasText: "quiet workspace" });
  await expect(card).toContainText("Unverified");
  await card.getByRole("button", { name: "History", exact: true }).click();
  await expect(page.getByRole("dialog")).toContainText("Revision 1");
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page.screenshot({
    path: "../docs/iteration-2/memory-review.png",
    fullPage: true,
  });
});

test("cooperating agents await approval, publish disabled routine, and model settings persist", async ({
  page,
}) => {
  await login(page);
  const before = (
    await (await page.request.get("/api/v1/state")).json()
  ).devices.map((d: any) => [d.id, d.value]);
  await nav(page, "AI Agents");
  await page
    .getByRole("button", { name: "Prepare comfort plan", exact: true })
    .click();
  const task = page
    .locator(".task")
    .filter({ hasText: "comfort plan" })
    .first();
  await expect(task).toContainText("awaiting_approval", { timeout: 10000 });
  await task.locator(".task-header > button").first().click();
  await expect(task).toContainText("Human approval checkpoint");
  await task.getByText(/Execution timeline/).click();
  await page.screenshot({
    path: "../docs/iteration-2/agent-checkpoint.png",
    fullPage: true,
  });
  await task
    .getByRole("button", { name: "Approve disabled routine", exact: true })
    .click();
  await expect(task.locator(".task-header > .badge")).toHaveText("completed", {
    timeout: 10000,
  });
  const state = await (await page.request.get("/api/v1/state")).json();
  const rule = state.rules.find((r: any) => r.source_task);
  expect(rule.enabled).toBe(false);
  expect(state.devices.map((d: any) => [d.id, d.value])).toEqual(before);
  await nav(page, "Administration");
  await page
    .getByRole("spinbutton", { name: "Context character budget", exact: true })
    .fill("8192");
  await page
    .getByRole("button", { name: "Save inference configuration", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText("configuration saved");
  const info = await (await page.request.get("/api/v1/models")).json();
  expect(info.configuration.context_chars).toBe(8192);
  expect(info.discovery.status).toBe("mock");
});
