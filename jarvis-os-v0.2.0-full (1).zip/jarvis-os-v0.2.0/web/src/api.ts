export type Row = Record<string, any>;
export interface EstateState {
  rooms: Row[];
  sensors: Row[];
  devices: Row[];
  audios: Row[];
  rules: Row[];
  robots: Row[];
  agents: Row[];
  memories: Row[];
  alerts: Row[];
  tasks: Row[];
  runs: Row[];
  research: Row[];
  proposals: Row[];
  inferences: Row[];
  settings: Row;
  schedule: Row;
  recommendations: Row[];
  audit: Row[];
  system: Row;
  memory_candidates: Row[];
  suggestions: Row[];
}
let csrf = "";
export function setCsrf(value: string) {
  csrf = value;
}
export async function api<T = Row>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const response = await fetch("/api/v1" + path, {
    method,
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!response.ok) {
    const error = await response
      .json()
      .catch(() => ({ detail: response.statusText }));
    throw new Error(
      error.error?.message ||
        (typeof error.detail === "string"
          ? error.detail
          : "Check the form values and try again."),
    );
  }
  return response.json();
}
export async function chatStream(
  message: string,
  task: string,
  signal: AbortSignal,
  onToken: (text: string) => void,
  onDone: (metrics: Row) => void,
  onEvent?: (event: Row) => void,
) {
  const response = await fetch("/api/v1/chat", {
    method: "POST",
    signal,
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
    body: JSON.stringify({ message, task }),
  });
  if (!response.ok) {
    const e = await response.json();
    throw new Error(e.detail);
  }
  const reader = response.body!.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split("\n\n");
    buffer = parts.pop() || "";
    for (const part of parts)
      if (part.startsWith("data: ")) {
        const event = JSON.parse(part.slice(6));
        onEvent?.(event);
        if (event.type === "token") onToken(event.text);
        if (event.type === "done") onDone(event.metrics);
      }
  }
}
