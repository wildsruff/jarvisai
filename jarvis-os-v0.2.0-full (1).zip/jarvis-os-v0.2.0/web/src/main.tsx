import {
  Activity,
  ArrowRight,
  Bell,
  Bot,
  Boxes,
  BrainCircuit,
  CheckCheck,
  ChevronRight,
  CircuitBoard,
  Clock3,
  Code2,
  Compass,
  Home,
  Layers3,
  Leaf,
  LockKeyhole,
  LogOut,
  MemoryStick,
  Menu,
  MessageSquare,
  Search,
  Settings2,
  Shield,
  ShieldCheck,
  SlidersHorizontal,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import React, { useCallback, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { api, EstateState, Row, setCsrf } from "./api";
import { Administration } from "./pages/administration";
import { Agents } from "./pages/agents";
import { Automations } from "./pages/automations";
import { Conversation } from "./pages/conversation";
import { Development } from "./pages/development";
import { Devices } from "./pages/devices";
import { Diagnostics } from "./pages/diagnostics";
import { Energy } from "./pages/energy";
import { Environment } from "./pages/environment";
import { Memories } from "./pages/memory";
import { Overview } from "./pages/overview";
import { Research } from "./pages/research";
import { Robotics } from "./pages/robotics";
import { Security } from "./pages/security";
import { DigitalTwin } from "./pages/spatial";
import "./styles.css";
import { Act, Badge, cn, Modal, Orb } from "./ui";
const navigation = [
  {
    group: "WORKSPACE",
    items: [
      ["Home Overview", Home],
      ["AI Conversation", MessageSquare],
      ["Digital Twin", Layers3],
      ["Environment", Leaf],
      ["Devices", CircuitBoard],
      ["Automations", Boxes],
    ],
  },
  {
    group: "ESTATE SYSTEMS",
    items: [
      ["Security", ShieldCheck],
      ["Energy", Zap],
      ["Robotics", Bot],
    ],
  },
  {
    group: "INTELLIGENCE",
    items: [
      ["AI Agents", BrainCircuit],
      ["Memory", MemoryStick],
      ["Research", Compass],
      ["Development Lab", Code2],
    ],
  },
  {
    group: "SYSTEM",
    items: [
      ["System Diagnostics", Activity],
      ["Administration", Settings2],
    ],
  },
] as const;
const subtitles: Record<string, string> = {
  "Home Overview": "Your estate, in sync.",
  "AI Conversation": "A local intelligence. A familiar presence.",
  "Digital Twin": "A living model of your environment.",
  Environment: "Understand the air around you.",
  Devices: "One secure boundary. Every connected system.",
  Automations: "Intentional routines, observable outcomes.",
  Security: "Visibility, verification, and control.",
  Energy: "A clearer picture of your energy.",
  Robotics: "Coordinate the next generation of estate systems.",
  "AI Agents": "Specialist intelligence. Structured collaboration.",
  Memory: "What JARVIS knows, and where it came from.",
  Research: "Explore possibilities. Keep execution separate.",
  "Development Lab": "Better software begins with a reviewed proposal.",
  "System Diagnostics": "Every layer, observable.",
  Administration: "Your intelligence. Your boundaries.",
};
function Login({ onLogin }: { onLogin: (session: Row) => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      onLogin(await api("/login", "POST", { username: "admin", password }));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="login-screen">
      <div className="login-grid" />
      <div className="login-card">
        <div className="brand">
          <div className="brand-mark">
            <CircuitBoard size={23} />
          </div>
          <span>
            JARVIS<span className="brand-os">OS</span>
          </span>
          <small>GENESIS</small>
        </div>
        <Orb />
        <span className="eyebrow">LOCAL INTELLIGENCE, PERSONAL BY DESIGN</span>
        <h1>
          Welcome to your
          <br />
          command center.
        </h1>
        <p>A private connection to your estate.</p>
        <form onSubmit={submit}>
          <label>
            Administrator password
            <input
              type="password"
              autoComplete="current-password"
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          <button className="button primary" disabled={loading}>
            {loading ? "Connecting…" : "Connect to JARVIS"}
            <ArrowRight size={17} />
          </button>
        </form>
        <div className="login-note">
          <LockKeyhole size={14} />
          Local session · Authenticated control
        </div>
        <details>
          <summary>First time here?</summary>
          <p>
            Start the local core, then read <code>.runtime/admin-password</code>{" "}
            on your server. The username is <code>admin</code>. This first
            release operates in simulation.
          </p>
        </details>
      </div>
      <div className="login-footer">
        PROJECT GENESIS <span>v0.2.0 · SIMULATION RELEASE</span>
      </div>
    </div>
  );
}
function App() {
  const [session, setSession] = useState<Row | null>(null);
  const [booted, setBooted] = useState(false);
  const [state, setState] = useState<EstateState | null>(null);
  const [view, setView] = useState("Home Overview");
  const [navOpen, setNavOpen] = useState(false);
  const [tick, setTick] = useState(0);
  const [notice, setNotice] = useState<{ text: string; error: boolean } | null>(
    null,
  );
  const [connection, setConnection] = useState(true);
  const [commandOpen, setCommandOpen] = useState(false);
  const [search, setSearch] = useState("");
  const notify = useCallback(
    (text: string, error = false) => setNotice({ text, error }),
    [],
  );
  useEffect(() => {
    api("/session")
      .then((v) => {
        setSession(v);
        setCsrf(v.csrf);
      })
      .catch(() => {})
      .finally(() => setBooted(true));
  }, []);
  const refresh = useCallback(async () => {
    try {
      setState(await api<EstateState>("/state"));
      setTick((t) => t + 1);
      setConnection(true);
    } catch (e) {
      setConnection(false);
      if ((e as Error).message === "Sign in required") {
        setSession(null);
        setState(null);
      }
    }
  }, []);
  useEffect(() => {
    if (!session) return;
    refresh();
    const timer = setInterval(refresh, 3000);
    return () => clearInterval(timer);
  }, [session, refresh]);
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(null), 6000);
    return () => clearTimeout(t);
  }, [notice]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCommandOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);
  const act: Act = async (
    path,
    body,
    method = "POST",
    success = "Updated successfully",
  ) => {
    try {
      const result = await api(path, method, body);
      await refresh();
      notify(success);
      return result;
    } catch (e) {
      notify((e as Error).message, true);
    }
  };
  function go(next: string) {
    setView(next);
    setNavOpen(false);
    setCommandOpen(false);
    setSearch("");
    window.scrollTo(0, 0);
  }
  async function logout() {
    await act("/logout", undefined, "POST", "Signed out");
    setSession(null);
    setState(null);
  }
  if (!booted)
    return (
      <div className="boot">
        <Orb small />
        <span>Establishing local connection…</span>
      </div>
    );
  if (!session)
    return (
      <Login
        onLogin={(v) => {
          setCsrf(v.csrf);
          setSession(v);
        }}
      />
    );
  if (!state)
    return (
      <div className="boot">
        <Orb small />
        <span>
          {connection
            ? "Synchronizing estate…"
            : "Core unavailable. Reconnecting…"}
        </span>
        <button className="button" onClick={logout}>
          Sign out
        </button>
      </div>
    );
  const allViews = navigation.flatMap((g) => g.items.map((i) => i[0]));
  const activeAlerts = state.alerts.filter((a) => a.status === "active");
  return (
    <div className="app-shell">
      {navOpen && (
        <div className="nav-shade" onClick={() => setNavOpen(false)} />
      )}
      <aside className={cn("sidebar", navOpen && "open")}>
        <div className="brand">
          <div className="brand-mark">
            <CircuitBoard size={23} />
          </div>
          <span>
            JARVIS<span className="brand-os">OS</span>
          </span>
          <small>GENESIS</small>
        </div>
        <div className="estate-switch">
          <div className="estate-avatar">
            <Home size={18} />
          </div>
          <div>
            <strong>The Estate</strong>
            <span>Private local network</span>
          </div>
          <LockKeyhole size={13} />
        </div>
        <nav aria-label="Main navigation">
          {navigation.map((group) => (
            <div className="nav-group" key={group.group}>
              <span className="nav-label">{group.group}</span>
              {group.items.map(([name, Icon]) => (
                <button
                  key={name}
                  className={cn("nav-item", view === name && "active")}
                  aria-label={name}
                  onClick={() => go(name)}
                >
                  <Icon size={17} />
                  <span>{name}</span>
                  {name === "AI Conversation" && (
                    <span className="nav-ai">AI</span>
                  )}
                  {name === "Security" && activeAlerts.length > 0 && (
                    <span className="nav-count">{activeAlerts.length}</span>
                  )}
                </button>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="local-core">
            <span className="status-beacon" />
            <div>
              <strong>
                Local core {connection ? "online" : "disconnected"}
              </strong>
              <span>
                {state.system.model.provider === "mock"
                  ? "Mock inference · Offline capable"
                  : state.system.model.provider + " · Local inference"}
              </span>
            </div>
            <Wifi size={15} />
          </div>
          <button className="profile" onClick={logout} title="Sign out">
            <div className="avatar">A</div>
            <div>
              <strong>Administrator</strong>
              <span>Estate owner</span>
            </div>
            <LogOut size={16} />
          </button>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumbs">
            <button
              className="icon-btn mobile-menu"
              onClick={() => setNavOpen(true)}
              aria-label="Open navigation"
            >
              <Menu size={20} />
            </button>
            <Home size={14} />
            <ChevronRight size={12} />
            <span>{view}</span>
          </div>
          <div className="topbar-right">
            <Badge tone="subtle">SIMULATION MODE</Badge>
            <button
              className="search-trigger"
              onClick={() => setCommandOpen(true)}
            >
              <Search size={15} />
              <span>Quick navigation</span>
              <kbd>⌘ K</kbd>
            </button>
            <span className="topbar-separator" />
            <button
              className="icon-btn notification"
              onClick={() => go("Security")}
              aria-label={`Notifications, ${activeAlerts.length} active alerts`}
            >
              <Bell size={18} />
              {activeAlerts.length > 0 && <i />}
            </button>
            <button
              className="top-avatar"
              onClick={() => go("Administration")}
              aria-label="Administration"
            >
              A
            </button>
          </div>
        </header>
        <main>
          <div className="page-heading">
            <div>
              <div className="eyebrow">
                PROJECT GENESIS <span>/</span> COMMAND CENTER
              </div>
              <h1>{view === "Home Overview" ? "Estate overview" : view}</h1>
              <p>{subtitles[view]}</p>
            </div>
            <div className="page-heading-actions">
              {view === "Home Overview" ? (
                <>
                  <span className="date-label">
                    <Clock3 size={14} />
                    {new Date().toLocaleDateString([], {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                  <button
                    className="button"
                    onClick={() => go("Administration")}
                  >
                    <SlidersHorizontal size={15} />
                    Customize
                  </button>
                </>
              ) : (
                <Badge tone={connection ? "green" : "amber"}>
                  {connection ? "LOCAL CONNECTION" : "RECONNECTING"}
                </Badge>
              )}
            </div>
          </div>
          {!connection && (
            <div className="connection-banner" role="alert">
              The core is unavailable. Displayed values may be stale.
              Reconnecting…
            </div>
          )}
          {view === "Home Overview" && (
            <Overview state={state} tick={tick} go={go} act={act} />
          )}
          {view === "AI Conversation" && (
            <Conversation state={state} refresh={refresh} notify={notify} />
          )}
          {view === "Digital Twin" && (
            <DigitalTwin state={state} act={act} tick={tick} />
          )}
          {view === "Environment" && (
            <Environment state={state} tick={tick} act={act} />
          )}
          {view === "Devices" && <Devices state={state} act={act} />}
          {view === "Automations" && <Automations state={state} act={act} />}
          {view === "Security" && <Security state={state} act={act} />}
          {view === "Energy" && <Energy state={state} tick={tick} />}
          {view === "Robotics" && <Robotics state={state} act={act} />}
          {view === "AI Agents" && <Agents state={state} act={act} />}
          {view === "Memory" && <Memories state={state} act={act} />}
          {view === "Research" && <Research state={state} act={act} />}
          {view === "Development Lab" && (
            <Development state={state} act={act} />
          )}
          {view === "System Diagnostics" && (
            <Diagnostics state={state} act={act} />
          )}
          {view === "Administration" && (
            <Administration state={state} act={act} />
          )}
          <footer className="main-footer">
            <span>
              <ShieldCheck size={12} />
              Local-first. Private by design.
            </span>
            <span>
              JARVIS OS <i />
              GENESIS v0.2.0 <i />
              SIMULATED ESTATE
            </span>
          </footer>
        </main>
      </div>
      {notice && (
        <div className={cn("toast", notice.error && "error")} role="status">
          {notice.error ? <Shield size={17} /> : <CheckCheck size={17} />}
          <span>{notice.text}</span>
          <button
            className="icon-btn"
            onClick={() => setNotice(null)}
            aria-label="Dismiss notification"
          >
            <X size={15} />
          </button>
        </div>
      )}
      {commandOpen && (
        <Modal title="Quick navigation" close={() => setCommandOpen(false)}>
          <div className="command-input">
            <Search size={18} />
            <input
              placeholder="Find a view…"
              aria-label="Search navigation"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="command-list">
            {allViews
              .filter((v) => v.toLowerCase().includes(search.toLowerCase()))
              .map((v) => (
                <button key={v} onClick={() => go(v)}>
                  {v}
                  <ArrowRight size={16} />
                </button>
              ))}
          </div>
        </Modal>
      )}
    </div>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
