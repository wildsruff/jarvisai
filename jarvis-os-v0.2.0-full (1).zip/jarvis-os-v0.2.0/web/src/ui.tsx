import {
  Activity,
  Check,
  ChevronRight,
  Network,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { api, EstateState, Row } from "./api";
export const date = (value: string) =>
  new Date(value).toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
export const number = (value: number, digits = 1) =>
  value.toLocaleString([], { maximumFractionDigits: digits });
export const cn = (...values: (string | boolean | undefined)[]) =>
  values.filter(Boolean).join(" ");
export type Act = (
  path: string,
  body?: unknown,
  method?: string,
  success?: string,
) => Promise<Row | undefined>;
export function Badge({
  children,
  tone = "green",
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return (
    <span className={"badge " + tone}>
      <i />
      {children}
    </span>
  );
}

export function Toggle({
  value,
  onChange,
  label,
}: {
  value: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      className={cn("toggle", value && "on")}
      role="switch"
      aria-checked={value}
      aria-label={label}
      onClick={() => onChange(!value)}
    >
      <span />
    </button>
  );
}

export function Orb({ small = false }: { small?: boolean }) {
  return (
    <div className={cn("orb", small && "small")} aria-hidden="true">
      <div />
      <span />
      <i />
    </div>
  );
}

export function Empty({
  icon: Icon = Sparkles,
  title,
  detail,
  children,
}: {
  icon?: React.ElementType;
  title: string;
  detail: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="empty">
      <Icon size={29} />
      <h3>{title}</h3>
      <p>{detail}</p>
      {children}
    </div>
  );
}

export function Modal({
  title,
  close,
  children,
}: {
  title: string;
  close: () => void;
  children: React.ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const old = document.activeElement as HTMLElement;
    ref.current?.querySelector<HTMLElement>("input,button,select")?.focus();
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "Tab") {
        const list = ref.current?.querySelectorAll<HTMLElement>(
          "button,input,select,textarea,a[href]",
        );
        if (!list?.length) return;
        const first = list[0],
          last = list[list.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.removeEventListener("keydown", handler);
      old?.focus();
    };
  }, []);
  return (
    <div
      className="modal-shade"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div
        className="modal"
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          <button
            className="icon-btn"
            onClick={close}
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}

export function Panel({
  title,
  icon: Icon,
  action,
  children,
  className = "",
}: {
  title: string;
  icon?: React.ElementType;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={"panel " + className}>
      <div className="panel-head">
        <h3>
          {Icon && <Icon size={16} />}
          {title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Chart({
  points,
  color = "#62d9bf",
  height = 160,
  unit = "",
  label = "Sensor readings",
}: {
  points: Row[];
  color?: string;
  height?: number;
  unit?: string;
  label?: string;
}) {
  const id = React.useId().replace(/:/g, "");
  const vals = points.map((p) => p.value);
  const min = Math.min(...vals, 0),
    max = Math.max(...vals, 1) * 1.15;
  const plot = vals
    .map(
      (v, i) =>
        `${42 + (i / Math.max(1, vals.length - 1)) * 558},${height - 28 - ((v - min) / (max - min)) * (height - 48)}`,
    )
    .join(" ");
  if (!points.length)
    return (
      <Empty
        icon={Activity}
        title="Waiting for readings"
        detail="New samples are recorded every six seconds."
      />
    );
  return (
    <svg
      className="chart"
      viewBox={`0 0 620 ${height}`}
      role="img"
      aria-label={label}
    >
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".19" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0, 1, 2, 3].map((i) => (
        <g key={i}>
          <line
            x1="42"
            x2="600"
            y1={20 + (i * (height - 48)) / 3}
            y2={20 + (i * (height - 48)) / 3}
            stroke="#253139"
            strokeDasharray="3 5"
          />
          <text
            x="0"
            y={24 + (i * (height - 48)) / 3}
            fill="#78868e"
            fontSize="10"
          >
            {number(max * (1 - i / 3), 0)}
            {i === 0 ? unit : ""}
          </text>
        </g>
      ))}
      <polygon
        points={`42,${height - 28} ${plot} 600,${height - 28}`}
        fill={`url(#${id})`}
      />
      <polyline
        points={plot}
        stroke={color}
        strokeWidth="2"
        strokeLinejoin="round"
        fill="none"
      />
      {[0, 0.25, 0.5, 0.75, 1].map((v) => (
        <text
          key={v}
          x={42 + v * 558}
          y={height - 5}
          textAnchor={v === 0 ? "start" : v === 1 ? "end" : "middle"}
          fill="#78868e"
          fontSize="10"
        >
          {new Date(
            points[
              Math.min(points.length - 1, Math.floor(v * (points.length - 1)))
            ].timestamp,
          ).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </text>
      ))}
    </svg>
  );
}

export function useHistory(room: string, metric: string, tick: number) {
  const [points, set] = useState<Row[]>([]);
  useEffect(() => {
    let active = true;
    api<Row[]>(`/history?room=${room}&metric=${metric}`)
      .then((v) => active && set(v))
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [room, metric, Math.floor(tick / 3)]);
  return points;
}

export function Twin({
  state,
  selected,
  onSelect,
  fields = false,
  metric = "temperature",
  events,
  playback = -1,
}: {
  state: EstateState;
  selected: string;
  onSelect: (id: string) => void;
  fields?: boolean;
  metric?: string;
  events?: Row[];
  playback?: number;
}) {
  const historical = events && playback >= 0 ? events[playback] : null;
  return (
    <div className="twin-canvas">
      <div className="twin-grid" />
      <svg
        viewBox="0 0 900 540"
        className="floorplan"
        role="img"
        aria-label="Interactive simulated ground floor plan"
      >
        <defs>
          <pattern
            id="floor"
            width="20"
            height="20"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M0 20V0H20"
              fill="none"
              stroke="#26383c"
              strokeWidth=".5"
            />
          </pattern>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" />
          </filter>
        </defs>
        <g>
          {state.rooms.map((room) => {
            const s = state.sensors.find(
              (s) => s.room_id === room.id && s.metric === metric,
            );
            const active = room.id === selected;
            const occ =
              historical && historical.room_id === room.id
                ? historical.count
                : room.occupancy;
            return (
              <g
                key={room.id}
                tabIndex={0}
                role="button"
                aria-label={`Select ${room.name}`}
                onClick={() => onSelect(room.id)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    onSelect(room.id);
                  }
                }}
                className="room-shape"
              >
                <rect
                  x={room.x + 3}
                  y={room.y + 6}
                  width={room.w}
                  height={room.h}
                  fill="#050b0f"
                />
                <rect
                  x={room.x}
                  y={room.y}
                  width={room.w}
                  height={room.h}
                  fill={active ? "#152e32" : "#152126"}
                  stroke={active ? "#72dacb" : "#476066"}
                  strokeWidth={active ? 2 : 1.5}
                />
                <rect
                  x={room.x + 5}
                  y={room.y + 5}
                  width={room.w - 10}
                  height={room.h - 10}
                  fill="url(#floor)"
                />
                {fields && (
                  <path
                    d={`M${room.x + 18} ${room.y + 18} l115 0 a115 115 0 0 1 -115 115 z`}
                    fill="#68d8ca"
                    opacity=".1"
                    stroke="#68d8ca"
                    strokeDasharray="4 5"
                  />
                )}
                <path
                  d={`M${room.x + room.w / 2 - 20},${room.y + room.h} h40`}
                  stroke="#0c151b"
                  strokeWidth="5"
                />
                <path
                  d={`M${room.x + room.w / 2 - 20},${room.y + room.h} v-37 a37 37 0 0 1 37 37`}
                  stroke="#476066"
                  strokeWidth="1"
                  fill="none"
                />
                <text
                  x={room.x + 18}
                  y={room.y + 28}
                  fill={active ? "#a5ede1" : "#becbd0"}
                  fontSize="13"
                  fontWeight="500"
                >
                  {room.name}
                </text>
                <text
                  x={room.x + 18}
                  y={room.y + 48}
                  fill="#718d94"
                  fontSize="10"
                >
                  {s ? `${number(s.value)} ${s.unit}` : ""}
                </text>
                {room.id === "living" && (
                  <g stroke="#567275" fill="#203135">
                    <rect x="60" y="130" width="120" height="48" rx="5" />
                    <path d="M60 146H180M70 146v30M170 146v30" />
                    <rect x="95" y="195" width="63" height="32" rx="8" />
                    <rect x="240" y="107" width="45" height="106" rx="3" />
                    <path d="M250 118v84" />
                  </g>
                )}
                {room.id === "kitchen" && (
                  <g stroke="#547076" fill="#203135">
                    <path d="M395 118h30v95h140v25H395z" />
                    <rect x="473" y="120" width="88" height="54" rx="3" />
                    <circle cx="410" cy="151" r="8" />
                    <path d="M492 227h45" />
                  </g>
                )}
                {room.id === "office" && (
                  <g stroke="#547076" fill="#203135">
                    <rect x="664" y="111" width="140" height="43" rx="3" />
                    <rect x="715" y="161" width="39" height="35" rx="8" />
                    <rect x="700" y="118" width="46" height="23" rx="2" />
                  </g>
                )}
                {room.id === "bedroom" && (
                  <g stroke="#547076" fill="#203135">
                    <rect x="112" y="350" width="112" height="101" rx="4" />
                    <rect x="120" y="357" width="40" height="23" rx="3" />
                    <rect x="174" y="357" width="40" height="23" rx="3" />
                    <path d="M112 390h112" />
                    <rect x="79" y="350" width="23" height="27" />
                    <rect x="234" y="350" width="23" height="27" />
                  </g>
                )}
                {room.id === "hall" && (
                  <g stroke="#3e6061" fill="none">
                    <rect
                      x="420"
                      y="355"
                      width="150"
                      height="65"
                      rx="30"
                      strokeDasharray="3 4"
                    />
                    <circle cx="493" cy="388" r="14" />
                  </g>
                )}
                {room.id === "garage" && (
                  <g stroke="#547076" fill="#203135">
                    <rect x="653" y="364" width="94" height="50" rx="3" />
                    <rect x="797" y="345" width="46" height="110" rx="3" />
                    <path d="M659 380h82M811 352v95" />
                  </g>
                )}
                <circle
                  cx={room.x + room.w - 19}
                  cy={room.y + 20}
                  r="3"
                  fill="#71dac4"
                />
                {occ > 0 && (
                  <g>
                    <circle
                      cx={room.x + room.w - 48}
                      cy={room.y + room.h - 38}
                      r="14"
                      fill="#163d39"
                      stroke="#4a9688"
                    />
                    <circle
                      cx={room.x + room.w - 48}
                      cy={room.y + room.h - 42}
                      r="3.5"
                      fill="#8adcc9"
                    />
                    <path
                      d={`M${room.x + room.w - 54} ${room.y + room.h - 33} q6 -8 12 0`}
                      stroke="#8adcc9"
                      fill="none"
                    />
                    <text
                      x={room.x + room.w - 27}
                      y={room.y + room.h - 34}
                      fill="#9ac4ba"
                      fontSize="10"
                    >
                      {occ}
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </g>
        {state.robots.map((r) => {
          const room = state.rooms.find((q) => q.id === r.room_id)!;
          return (
            <g key={r.id}>
              <rect
                x={room.x + room.w - 39}
                y={room.y + 65}
                width="18"
                height="18"
                rx="5"
                fill="#274d65"
                stroke="#82b7db"
              />
              <circle
                cx={room.x + room.w - 30}
                cy={room.y + 74}
                r="3"
                fill="#82b7db"
              />
            </g>
          );
        })}
        <text x="34" y="526" fill="#647d85" fontSize="10" letterSpacing="2">
          GROUND FLOOR · MAIN RESIDENCE
        </text>
        <path d="M850 520v-22m-5 5 5-5 5 5" stroke="#96aeb5" fill="none" />
        <text x="846" y="536" fontSize="8" fill="#96aeb5">
          N
        </text>
      </svg>
      <div className="twin-legend">
        <span>
          <i className="dot teal" />
          Sensor online
        </span>
        <span>
          <i className="dot blue" />
          Simulated robot
        </span>
        <span>
          <i className="dot pale" />
          Anonymous occupancy
        </span>
      </div>
    </div>
  );
}

export function Stat({
  icon: Icon,
  label,
  value,
  unit,
  detail,
  status,
  color = "teal",
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  unit?: string;
  detail: string;
  status: string;
  color?: string;
}) {
  return (
    <div className="stat">
      <div className="stat-top">
        <span>{label}</span>
        <Icon size={17} className={color + "-text"} />
      </div>
      <div className="stat-value">
        {value}
        <small>{unit}</small>
      </div>
      <div className="stat-bottom">
        <span>{detail}</span>
        <span className={color + "-text"}>
          <i className={"dot " + color} />
          {status}
        </span>
      </div>
    </div>
  );
}

export function TaskList({ tasks, act }: { tasks: Row[]; act: Act }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  return (
    <Panel title="Workflow queue & history" icon={Network}>
      {!tasks.length ? (
        <Empty
          icon={Network}
          title="Ready for a task"
          detail="Start a review, research workflow, diagnostics, or simulated robot mission."
        />
      ) : (
        <div className="task-list">
          {tasks.map((t) => (
            <div className="task" key={t.id}>
              <div className="task-header">
                <button
                  aria-expanded={expanded === t.id}
                  onClick={() => setExpanded(expanded === t.id ? null : t.id)}
                >
                  <ChevronRight
                    size={15}
                    className={expanded === t.id ? "rotated" : ""}
                  />
                  <div>
                    <strong>{t.workflow.replaceAll("-", " ")}</strong>
                    <span>
                      {date(t.created_at)} · {t.id}
                    </span>
                  </div>
                </button>
                <Badge
                  tone={
                    [
                      "failed",
                      "cancelled",
                      "timed_out",
                      "interrupted",
                    ].includes(t.state)
                      ? "amber"
                      : t.state === "completed"
                        ? "green"
                        : "blue"
                  }
                >
                  {t.state}
                </Badge>
                {["queued", "running", "awaiting_approval"].includes(
                  t.state,
                ) && (
                  <button
                    className="button small"
                    onClick={() =>
                      act(
                        `/tasks/${t.id}/cancel`,
                        undefined,
                        "POST",
                        "Cancellation requested",
                      )
                    }
                  >
                    <X size={13} />
                    Cancel
                  </button>
                )}
              </div>
              {expanded === t.id && (
                <div className="task-steps">
                  {t.error && <p className="form-error">{t.error}</p>}
                  {t.state === "awaiting_approval" && (
                    <div className="checkpoint">
                      <h4>Human approval checkpoint</h4>
                      <p>
                        Review the evidence and draft below. Approval publishes
                        this exact routine disabled. It does not execute device
                        commands.
                      </p>
                      <pre>
                        {JSON.stringify(t.context?.draft_rule, null, 2)}
                      </pre>
                      <div className="inline">
                        <button
                          className="button primary"
                          onClick={() =>
                            act(
                              `/tasks/${t.id}/review`,
                              { decision: "approve" },
                              "POST",
                              "Disabled routine approved",
                            )
                          }
                        >
                          Approve disabled routine
                        </button>
                        <button
                          className="button"
                          onClick={() =>
                            act(
                              `/tasks/${t.id}/review`,
                              { decision: "reject" },
                              "POST",
                              "Routine rejected",
                            )
                          }
                        >
                          Reject plan
                        </button>
                      </div>
                    </div>
                  )}
                  {["interrupted", "failed", "timed_out"].includes(t.state) &&
                    t.workflow !== "robot-mission" && (
                      <button
                        className="button"
                        onClick={() =>
                          act(
                            `/tasks/${t.id}/resume`,
                            undefined,
                            "POST",
                            "Replay-safe workflow recovery queued",
                          )
                        }
                      >
                        Resume from checkpoint
                      </button>
                    )}
                  {t.timeline?.length > 0 && (
                    <details className="workflow-timeline">
                      <summary>
                        Execution timeline · {t.timeline.length} events
                      </summary>
                      {t.timeline.map((e: Row, i: number) => (
                        <div className="timeline-event" key={i}>
                          <time>{date(e.timestamp)}</time>
                          <strong>
                            {e.agent} · {e.event}
                          </strong>
                          <p>{e.summary}</p>
                        </div>
                      ))}
                    </details>
                  )}
                  {t.steps.map((s: Row, i: number) => (
                    <div className="task-step" key={i}>
                      <div>
                        <span
                          className={cn(
                            "step-marker",
                            s.state === "completed" && "complete",
                          )}
                        >
                          {s.state === "completed" ? (
                            <Check size={12} />
                          ) : (
                            i + 1
                          )}
                        </span>
                        <strong>{s.agent}</strong>
                        <Badge tone="subtle">{s.state}</Badge>
                      </div>
                      {s.summary && <p className="form-hint">{s.summary}</p>}
                      {s.output && (
                        <pre>{JSON.stringify(s.output, null, 2)}</pre>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}

export function AuditTable({ logs }: { logs: Row[] }) {
  return (
    <Panel
      title="Audit ledger"
      icon={ShieldCheck}
      action={<span className="tiny-label">LATEST {logs.length} EVENTS</span>}
    >
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Sequence</th>
              <th>Time</th>
              <th>Actor</th>
              <th>Action</th>
              <th>Integrity hash</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.seq}>
                <td className="mono">#{log.seq.toString().padStart(4, "0")}</td>
                <td>{date(log.timestamp)}</td>
                <td>{log.actor}</td>
                <td>{log.action}</td>
                <td className="mono muted-text" title={log.hash}>
                  {log.hash.slice(0, 16)}…
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}
