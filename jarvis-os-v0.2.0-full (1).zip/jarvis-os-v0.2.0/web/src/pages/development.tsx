import {
  ArrowRight,
  Check,
  ChevronRight,
  Code2,
  LockKeyhole,
  Plus,
} from "lucide-react";
import React, { useState } from "react";
import { EstateState } from "../api";
import { Act, Badge, Empty, Modal, Panel } from "../ui";
export function Development({ state, act }: { state: EstateState; act: Act }) {
  const [creating, setCreating] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const result = await act(
      "/proposals",
      {
        title: f.get("title"),
        description: f.get("description"),
        components: String(f.get("components"))
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        risk: f.get("risk"),
      },
      "POST",
      "Proposal submitted for plan review",
    );
    if (result) setCreating(false);
  }
  return (
    <>
      <div className="section-toolbar">
        <div className="inline">
          <Badge tone="amber">HUMAN-SUPERVISED</Badge>
          <span className="muted-text">
            Proposals have no execution or deployment privileges.
          </span>
        </div>
        <button className="button primary" onClick={() => setCreating(true)}>
          <Plus size={16} />
          New improvement proposal
        </button>
      </div>
      <Panel title="Controlled improvement pipeline" icon={Code2}>
        <div className="pipeline">
          {[
            ["01", "Propose", "Implemented"],
            ["02", "Plan review", "Implemented"],
            ["03", "Isolated branch", "Manual tooling"],
            ["04", "Code & checks", "Manual tooling"],
            ["05", "Deploy approval", "Future integration"],
            ["06", "Monitor & rollback", "Manual tooling"],
          ].map(([n, t, s], i) => (
            <React.Fragment key={n}>
              <div className={i < 2 ? "available" : ""}>
                <span>{n}</span>
                <strong>{t}</strong>
                <small>{s}</small>
              </div>
              {i < 5 && <ChevronRight size={16} />}
            </React.Fragment>
          ))}
        </div>
        <div className="panel-note">
          Plan approval authorizes further engineering review only. This
          application cannot edit files, create branches, run generated code, or
          deploy. See the documented manual development process and backup
          tooling.
        </div>
      </Panel>
      <div className="proposal-grid">
        {state.proposals.map((p) => (
          <Panel
            key={p.id}
            title={p.title}
            icon={Code2}
            action={
              <Badge tone={p.state === "plan-approved" ? "green" : "amber"}>
                {p.state}
              </Badge>
            }
          >
            <div className="padded-form">
              <p className="pre-wrap">{p.description}</p>
              <div className="chip-list">
                {p.components.map((c: string) => (
                  <span key={c}>{c}</span>
                ))}
                <span>Risk: {p.risk}</span>
              </div>
              <div className="detail-list compact">
                <div>
                  <span>Tests / static / security</span>
                  <strong>Not run</strong>
                </div>
                <div>
                  <span>Branch</span>
                  <strong>Not created</strong>
                </div>
                <div>
                  <span>Deployment</span>
                  <strong>Unavailable</strong>
                </div>
              </div>
              {p.state === "awaiting-plan-review" && (
                <div className="inline">
                  <button
                    className="button primary"
                    onClick={() =>
                      act(
                        `/proposals/${p.id}/review`,
                        { action: "approve-plan" },
                        "POST",
                        "Plan approved for manual engineering review only",
                      )
                    }
                  >
                    <Check size={15} />
                    Approve plan
                  </button>
                  <button
                    className="button"
                    onClick={() =>
                      act(
                        `/proposals/${p.id}/review`,
                        { action: "reject" },
                        "POST",
                        "Proposal rejected",
                      )
                    }
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          </Panel>
        ))}
      </div>
      {!state.proposals.length && (
        <Empty
          icon={Code2}
          title="Make improvement deliberate"
          detail="Document an idea, its affected components, and the risks before beginning implementation."
        />
      )}
      <div className="safety-callout">
        <LockKeyhole size={23} />
        <div>
          <h3>Some boundaries never become autonomous.</h3>
          <p>
            Approval mechanisms, security policies, control boundaries, and
            hardware safeguards are protected. They require a separate human
            engineering process. Production deployment is unavailable to every
            agent.
          </p>
        </div>
      </div>
      {creating && (
        <Modal title="Propose an improvement" close={() => setCreating(false)}>
          <form className="modal-body form-grid" onSubmit={submit}>
            <label className="span-2">
              Title
              <input name="title" required minLength={5} maxLength={120} />
            </label>
            <label className="span-2">
              Problem, plan, tests & rollback
              <textarea
                name="description"
                rows={6}
                required
                minLength={10}
                maxLength={5000}
              />
            </label>
            <label>
              Affected components
              <input
                name="components"
                required
                placeholder="dashboard, environment"
              />
            </label>
            <label>
              Risk estimate
              <select name="risk" defaultValue="medium">
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </label>
            <button className="button primary span-2">
              Submit for plan review
              <ArrowRight size={16} />
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}
