import { Check, Network, ShieldCheck, Sparkles, Square } from "lucide-react";
import React, { useEffect, useState } from "react";
import { EstateState } from "../api";
import { ModelSettings } from "./model-settings";
import { Act, Panel, Toggle } from "../ui";
export function Administration({
  state,
  act,
}: {
  state: EstateState;
  act: Act;
}) {
  const [settings, setSettings] = useState(state.settings);
  useEffect(
    () => setSettings(state.settings),
    [JSON.stringify(state.settings)],
  );
  function update(key: string, value: unknown) {
    setSettings((s) => ({ ...s, [key]: value }));
  }
  async function save(e: React.FormEvent) {
    e.preventDefault();
    const { id: _id, ...body } = settings;
    await act(
      "/settings",
      body,
      "PUT",
      "Personality and governance settings saved",
    );
  }
  return (
    <>
      <form className="two-column" onSubmit={save}>
        <Panel title="Personality & interaction" icon={Sparkles}>
          <div className="padded-form">
            <label>
              Conversational style
              <select
                value={settings.personality}
                onChange={(e) => update("personality", e.target.value)}
              >
                <option value="precise">Precise · composed and direct</option>
                <option value="warm">Warm · friendly and attentive</option>
                <option value="rustic">
                  Rustic · easygoing, plainspoken humor
                </option>
              </select>
            </label>
            <p className="form-hint">
              The rustic style uses friendly, folksy storytelling, without
              copyrighted audio, character assets, or impersonation voices.
            </p>
            <label>
              Humor <span>{settings.humor}%</span>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.humor}
                onChange={(e) => update("humor", +e.target.value)}
              />
            </label>
            <label>
              Proactivity preference <span>{settings.proactivity}%</span>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.proactivity}
                onChange={(e) => update("proactivity", +e.target.value)}
              />
            </label>
            <label>
              Response preference
              <select
                value={settings.response_style || "balanced"}
                onChange={(e) => update("response_style", e.target.value)}
              >
                <option value="concise">Concise</option>
                <option value="balanced">Balanced</option>
                <option value="detailed">Detailed</option>
              </select>
            </label>
            <div className="row-between">
              <span>Extract conversation memory candidates</span>
              <Toggle
                label="Extract memory candidates"
                value={settings.extract_memories ?? true}
                onChange={(v) => update("extract_memories", v)}
              />
            </div>
            <label>
              Default approved-memory retention (days)
              <input
                type="number"
                min="1"
                max="3650"
                value={settings.memory_retention_days || 30}
                onChange={(e) =>
                  update("memory_retention_days", +e.target.value)
                }
              />
            </label>
            <label>
              Voice characteristic · stored preference
              <select
                value={settings.voice}
                onChange={(e) => update("voice", e.target.value)}
              >
                <option value="neutral">Neutral</option>
                <option value="warm">Warm</option>
                <option value="bright">Bright</option>
              </select>
            </label>
            <label>
              Speech rate · stored preference
              <input
                type="number"
                min=".5"
                max="2"
                step=".1"
                value={settings.speech_rate}
                onChange={(e) => update("speech_rate", +e.target.value)}
              />
            </label>
            <p className="form-hint">
              Tone, humor and response preferences guide local inference.
              Proactivity controls evidence-based trend advice; voice
              characteristics remain stored preferences. This application
              captures no audio.
            </p>
          </div>
        </Panel>
        <div>
          <Panel title="Autonomy & governance" icon={ShieldCheck}>
            <div className="padded-form">
              <div className="governance-toggle">
                <div>
                  <h4>Allow autonomous simulation</h4>
                  <p>
                    Enable automatic rules and simulated robot missions. Manual
                    changes take priority for five minutes.
                  </p>
                </div>
                <Toggle
                  label="Allow autonomous simulation"
                  value={settings.autonomous}
                  onChange={(v) => update("autonomous", v)}
                />
              </div>
              <div className="detail-list compact">
                <div>
                  <span>Chat execution access</span>
                  <strong>None</strong>
                </div>
                <div>
                  <span>External content trust</span>
                  <strong>Data only</strong>
                </div>
                <div>
                  <span>Hazardous equipment</span>
                  <strong>Always interlocked</strong>
                </div>
                <div>
                  <span>Software deployment</span>
                  <strong>Unavailable</strong>
                </div>
                <div>
                  <span>Authentication</span>
                  <strong>Local admin session</strong>
                </div>
              </div>
              <button className="button primary full" type="submit">
                <Check size={16} />
                Save preferences & policy
              </button>
            </div>
          </Panel>
          <Panel title="Manual override" icon={Square}>
            <div className="padded-form">
              <p className="muted-text">
                Disable autonomy, cancel workflows, stop simulated robots, and
                mute simulated audio.
              </p>
              <button
                type="button"
                className="button danger full"
                onClick={() =>
                  act(
                    "/emergency-stop",
                    undefined,
                    "POST",
                    "Simulation emergency stop engaged",
                  )
                }
              >
                <Square size={15} />
                Engage simulation emergency stop
              </button>
            </div>
          </Panel>
        </div>
      </form>
      <ModelSettings act={act} />
      <Panel title="Deployment identity" icon={Network}>
        <div className="detail-list">
          <div>
            <span>Project</span>
            <strong>JARVIS OS · Project Genesis</strong>
          </div>
          <div>
            <span>Version</span>
            <strong>0.2.0 · Local intelligence / simulated estate</strong>
          </div>
          <div>
            <span>Primary intelligence</span>
            <strong>Local · no cloud dependency</strong>
          </div>
          <div>
            <span>Users</span>
            <strong>
              Single administrator · multi-user enrollment planned
            </strong>
          </div>
          <div>
            <span>Network exposure</span>
            <strong>
              Loopback default · private TLS proxy required for LAN
            </strong>
          </div>
        </div>
      </Panel>
    </>
  );
}
