import { Activity, Cpu, Gauge, Network, RefreshCw } from "lucide-react";
import { useState } from "react";
import { EstateState, Row } from "../api";
import { Act, AuditTable, Badge, Empty, number, Panel, Stat } from "../ui";
export function Diagnostics({ state, act }: { state: EstateState; act: Act }) {
  const [result, setResult] = useState<Row | null>(null);
  return (
    <>
      <div className="section-toolbar">
        <Badge>CORE ONLINE</Badge>
        <button
          className="button"
          onClick={async () => {
            const r = await act(
              "/diagnostics",
              undefined,
              "GET",
              "Health checks completed",
            );
            if (r) setResult(r);
          }}
        >
          <RefreshCw size={15} />
          Run health checks
        </button>
      </div>
      <div className="stats-grid three">
        <Stat
          icon={Cpu}
          label="CORE UPTIME"
          value={number(state.system.uptime_seconds / 60, 1)}
          unit="min"
          detail="Current process lifetime"
          status="Online"
        />
        <Stat
          icon={Network}
          label="WORKFLOW QUEUE"
          value={String(state.system.queue_depth)}
          detail="50 queued tasks maximum"
          status="Bounded"
          color="blue"
        />
        <Stat
          icon={Activity}
          label="SENSOR CHANNELS"
          value={String(state.sensors.length)}
          detail="20 channels across 6 rooms"
          status="Simulated"
        />
      </div>
      <div className="two-column">
        <Panel title="Service health" icon={Activity}>
          <div className="detail-list">
            <div>
              <span>Local API</span>
              <Badge>ONLINE</Badge>
            </div>
            <div>
              <span>Database</span>
              <strong>SQLite · WAL</strong>
            </div>
            <div>
              <span>Audit consistency</span>
              <strong>
                {state.system.audit_integrity ? "Verified" : "Invalid"}
              </strong>
            </div>
            <div>
              <span>Local inference</span>
              <strong>
                {result?.model?.status || state.system.model.status}
              </strong>
            </div>
            <div>
              <span>Active provider</span>
              <strong>{state.system.model.provider}</strong>
            </div>
            <div>
              <span>External gateway</span>
              <strong>Optional · isolated</strong>
            </div>
            <div>
              <span>Physical adapters</span>
              <strong>0 · simulation only</strong>
            </div>
          </div>
          {result && (
            <div className="panel-note">
              Last explicit check: database {result.database}; model{" "}
              {result.model.status}; audit{" "}
              {result.audit_integrity ? "consistent" : "invalid"}.
            </div>
          )}
        </Panel>
        <Panel title="Inference instrumentation" icon={Gauge}>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Task</th>
                  <th>Provider</th>
                  <th>Latency</th>
                  <th>Tokens / outcome</th>
                </tr>
              </thead>
              <tbody>
                {state.inferences.slice(0, 10).map((i) => (
                  <tr key={i.id}>
                    <td>{i.task}</td>
                    <td>
                      {i.provider}
                      {i.fallback && " · fallback"}
                    </td>
                    <td>{i.latency_ms} ms</td>
                    <td>
                      {i.token_counts === "provider-reported"
                        ? `${i.input_tokens + i.output_tokens} reported`
                        : `~${i.estimated_input_tokens + i.estimated_output_tokens} estimated`}{" "}
                      · {i.status || "legacy"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!state.inferences.length && (
              <Empty
                icon={Gauge}
                title="No inference calls yet"
                detail="Start a conversation to measure local adapter latency and estimated token usage."
              />
            )}
          </div>
        </Panel>
      </div>
      <AuditTable logs={state.audit} />
    </>
  );
}
