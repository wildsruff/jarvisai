import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  Boxes,
  BrainCircuit,
  ChevronRight,
  Home,
  Layers3,
  Leaf,
  Maximize2,
  ShieldCheck,
  Sparkles,
  Thermometer,
  Wind,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { EstateState } from "../api";
import {
  Act,
  Badge,
  Chart,
  number,
  Orb,
  Panel,
  Stat,
  Twin,
  useHistory,
} from "../ui";
export function Overview({
  state,
  tick,
  go,
  act,
}: {
  state: EstateState;
  tick: number;
  go: (s: string) => void;
  act: Act;
}) {
  const [room, setRoom] = useState("living");
  const history = useHistory("living", "energy", tick);
  const readings = (metric: string) =>
    state.sensors.filter((s) => s.metric === metric);
  const average = (metric: string) =>
    readings(metric).reduce((a, b) => a + b.value, 0) / state.rooms.length;
  const occ = state.rooms.reduce((s, r) => s + r.occupancy, 0);
  const alerts = state.alerts.filter((a) => a.status === "active");
  const selected = state.rooms.find((r) => r.id === room)!;
  return (
    <>
      <div className="welcome-banner">
        <div className="banner-grid" />
        <div className="welcome-content">
          <div className="welcome-kicker">
            <span className="status-beacon" />
            YOUR ESTATE INTELLIGENCE IS ONLINE
          </div>
          <h2>Welcome home.</h2>
          <p>
            {alerts.length
              ? `${alerts.length} simulated alert${alerts.length > 1 ? "s" : ""} need your attention.`
              : "Everything is connected. You’re in control."}
            <br />
            <span>
              {state.devices.filter((d) => d.status === "online").length}{" "}
              devices online · {state.rooms.length} rooms monitored · All
              intelligence stays local
            </span>
          </p>
          <button className="text-button" onClick={() => go("AI Conversation")}>
            Let’s talk, JARVIS <ArrowUpRight size={16} />
          </button>
        </div>
        <div className="banner-orb">
          <Orb />
          <div className="orb-label">
            <AudioLines size={13} />
            <span>JARVIS CORE</span>
            <i />
            STANDBY
          </div>
        </div>
      </div>
      <div className="stats-grid">
        <Stat
          icon={Thermometer}
          label="INDOOR CLIMATE"
          value={number(average("temperature"))}
          unit="°C"
          detail="Estate average"
          status="Comfortable"
        />
        <Stat
          icon={Wind}
          label="AIR QUALITY"
          value={number(average("co2"), 0)}
          unit="ppm"
          detail="CO₂ · Estate average"
          status={average("co2") < 900 ? "Good" : "Review"}
        />
        <Stat
          icon={Zap}
          label="POWER DRAW"
          value={number(readings("energy").reduce((a, s) => a + s.value, 0))}
          unit="kW"
          detail="Live simulated load"
          status="Tracking"
          color="amber"
        />
        <Stat
          icon={ShieldCheck}
          label="ESTATE STATUS"
          value={
            alerts.length
              ? `${alerts.length} alert${alerts.length > 1 ? "s" : ""}`
              : "All clear"
          }
          detail={`${occ} anonymous occupancy detections`}
          status={alerts.length ? "Review needed" : "Systems normal"}
          color={alerts.length ? "amber" : "blue"}
        />
      </div>
      <div className="overview-grid">
        <Panel
          title="Your estate, live"
          icon={Layers3}
          className="twin-panel resizable"
          action={
            <div className="inline">
              <Badge>LIVE TWIN</Badge>
              <button
                className="icon-btn"
                onClick={() => go("Digital Twin")}
                aria-label="Expand digital twin"
              >
                <Maximize2 size={15} />
              </button>
            </div>
          }
        >
          <div className="map-toolbar">
            <span>
              <i className="dot teal" />
              Main residence
              <ChevronRight size={12} />
              <strong>Ground floor</strong>
            </span>
            <button className="map-view" onClick={() => go("Digital Twin")}>
              Explore twin
              <ArrowUpRight size={13} />
            </button>
          </div>
          <Twin state={state} selected={room} onSelect={setRoom} />
          <div className="map-room-strip">
            <div>
              <span className="room-icon">
                <Home size={17} />
              </span>
              <div>
                <strong>{selected.name}</strong>
                <span>
                  {selected.occupancy
                    ? `${selected.occupancy} anonymous detections`
                    : "No occupancy detected"}
                </span>
              </div>
            </div>
            <div className="room-strip-metrics">
              <span>
                <Thermometer size={14} />
                {number(
                  state.sensors.find((s) => s.id === room + "-temperature")!
                    .value,
                )}
                °
              </span>
              <span>
                <Wind size={14} />
                {number(
                  state.sensors.find((s) => s.id === room + "-co2")!.value,
                  0,
                )}{" "}
                ppm
              </span>
              <button
                className="icon-btn"
                onClick={() => go("Digital Twin")}
                aria-label="Room details"
              >
                <ArrowUpRight size={16} />
              </button>
            </div>
          </div>
        </Panel>
        <Panel
          title="JARVIS insights"
          icon={Sparkles}
          className="insights-panel"
          action={<span className="tiny-label">PROACTIVE INTELLIGENCE</span>}
        >
          <div className="insight-intro">
            <div className="mini-orb">
              <Sparkles size={20} />
            </div>
            <p>
              A little awareness.
              <br />
              <strong>A better-running home.</strong>
            </p>
          </div>
          {state.recommendations.length > 0 ? (
            state.recommendations.slice(0, 2).map((r) => (
              <div className="insight" key={r.id}>
                <span className="insight-icon amber">
                  <Wind size={17} />
                </span>
                <div>
                  <h4>{r.title}</h4>
                  <p>
                    {r.room} · {number(r.value)} {r.unit}. {r.detail}
                  </p>
                  <button
                    className="text-button"
                    onClick={() => go("Environment")}
                  >
                    Review environment
                    <ArrowRight size={13} />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="insight">
              <span className="insight-icon">
                <Leaf size={17} />
              </span>
              <div>
                <h4>A comfortable environment</h4>
                <p>
                  Current simulated air quality and temperature readings are
                  within advisory thresholds.
                </p>
                <button
                  className="text-button"
                  onClick={() => go("Environment")}
                >
                  View environment
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>
          )}
          <div className="insight">
            <span className="insight-icon blue">
              <Boxes size={17} />
            </span>
            <div>
              <h4>Make good routines effortless</h4>
              <p>
                Your fresh-air workflow is ready to inspect. Preview every
                action before enabling a rule.
              </p>
              <button className="text-button" onClick={() => go("Automations")}>
                Explore automations
                <ArrowRight size={13} />
              </button>
            </div>
          </div>
          <div className="insight-bottom">
            <ShieldCheck size={14} />
            <span>Recommendations never execute on their own.</span>
          </div>
        </Panel>
        <Panel
          title="Energy pulse"
          icon={Zap}
          className="energy-panel resizable"
          action={
            <button className="text-button muted" onClick={() => go("Energy")}>
              View energy
              <ArrowUpRight size={14} />
            </button>
          }
        >
          <div className="energy-summary">
            <div>
              <span className="tiny-label">LIVING ROOM LOAD</span>
              <h3>
                {number(
                  state.sensors.find((s) => s.id === "living-energy")!.value,
                )}{" "}
                <small>kW</small>
              </h3>
            </div>
            <div className="chart-key">
              <i className="dot teal" />
              Consumption<span>Last 30 minutes</span>
            </div>
          </div>
          <Chart
            points={history}
            height={160}
            unit=" kW"
            label="Living room energy consumption history"
          />
        </Panel>
        <Panel
          title="Activity stream"
          icon={Activity}
          className="activity-panel"
          action={
            <button
              className="text-button muted"
              onClick={() => go("System Diagnostics")}
            >
              View all
              <ArrowUpRight size={14} />
            </button>
          }
        >
          <div className="activity-list">
            {state.audit.slice(0, 4).map((log) => (
              <div className="activity-row" key={log.seq}>
                <span className="activity-node">
                  <Activity size={13} />
                </span>
                <div>
                  <strong>
                    {log.action.replaceAll(".", " · ").replaceAll("_", " ")}
                  </strong>
                  <p>
                    {log.actor === "admin" ? "Administrator" : log.actor}{" "}
                    <span>·</span> Local core
                  </p>
                </div>
                <time>
                  {new Date(log.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </time>
              </div>
            ))}
          </div>
          <button
            className="activity-action"
            onClick={() =>
              act(
                "/tasks",
                { workflow: "estate-review", subject: "Estate status review" },
                "POST",
                "Estate review queued",
              )
            }
          >
            <BrainCircuit size={15} />
            <span>Run an estate intelligence review</span>
            <ArrowRight size={15} />
          </button>
        </Panel>
      </div>
    </>
  );
}
