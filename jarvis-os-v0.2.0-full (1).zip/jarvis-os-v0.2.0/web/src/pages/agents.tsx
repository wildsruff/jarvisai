import { Activity, BrainCircuit, LockKeyhole, Network } from "lucide-react";
import { EstateState } from "../api";
import { Act, Badge, TaskList } from "../ui";
export function Agents({ state, act }: { state: EstateState; act: Act }) {
  return (
    <>
      <div className="section-toolbar">
        <div className="inline">
          <Badge>{state.agents.length} REGISTERED SPECIALISTS</Badge>
          <span className="muted-text">
            Bounded handlers · 30-second timeout
          </span>
        </div>
        <div className="inline">
          <button
            className="button primary"
            onClick={() =>
              act(
                "/tasks",
                {
                  workflow: "comfort-plan",
                  subject: "Prepare a reviewed ventilation routine",
                },
                "POST",
                "Cooperating-agent comfort plan queued",
              )
            }
          >
            Prepare comfort plan
          </button>
          <button
            className="button"
            onClick={() =>
              act(
                "/tasks",
                { workflow: "diagnostics" },
                "POST",
                "Diagnostics queued",
              )
            }
          >
            <Activity size={15} />
            Run diagnostics
          </button>
          <button
            className="button primary"
            onClick={() =>
              act(
                "/tasks",
                {
                  workflow: "estate-review",
                  subject: "Estate intelligence review",
                },
                "POST",
                "Estate review queued",
              )
            }
          >
            <BrainCircuit size={16} />
            Run estate review
          </button>
        </div>
      </div>
      <div className="agent-grid">
        {state.agents.map((a) => (
          <div className="agent-card" key={a.id}>
            <div className="row-between">
              <span className="agent-icon">
                <BrainCircuit size={21} />
              </span>
              <Badge tone={a.status === "running" ? "green" : "subtle"}>
                {a.status}
              </Badge>
            </div>
            <h3>{a.name}</h3>
            <p>{a.description}</p>
            <div className="agent-footer">
              <span>
                <LockKeyhole size={12} />
                {a.permission}
              </span>
              <span>{a.runs} step runs</span>
            </div>
          </div>
        ))}
      </div>
      <div className="quiet-note">
        <Network size={20} />
        <p>
          Agents collaborate through registered workflow steps and structured
          records. Estate reviews run policy verification → memory retrieval →
          monitoring → environmental advice → planning. Specialist registration
          does not imply a separate running language model.
        </p>
      </div>
      <TaskList tasks={state.tasks} act={act} />
    </>
  );
}
