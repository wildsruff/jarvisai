import {
  Check,
  Fan,
  Lightbulb,
  LockKeyhole,
  Search,
  ShieldCheck,
  Thermometer,
} from "lucide-react";
import { useEffect, useState } from "react";
import { EstateState, Row } from "../api";
import { Act, Badge, cn, Empty, number } from "../ui";
export function Devices({ state, act }: { state: EstateState; act: Act }) {
  const [room, setRoom] = useState("all");
  const [query, setQuery] = useState("");
  const devices = state.devices.filter(
    (d) =>
      (room === "all" || d.room_id === room) &&
      d.name.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <>
      <div className="section-toolbar">
        <div className="inline">
          <Badge>
            {state.devices.filter((d) => d.status === "online").length} ONLINE
          </Badge>
          <span className="muted-text">3 protected systems interlocked</span>
        </div>
        <div className="inline">
          <div className="input-icon">
            <Search size={15} />
            <input
              aria-label="Search devices"
              placeholder="Search devices…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <select
            aria-label="Filter devices by room"
            value={room}
            onChange={(e) => setRoom(e.target.value)}
          >
            <option value="all">All rooms</option>
            {state.rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="device-grid">
        {devices.map((d) => (
          <DeviceCard key={d.id} device={d} act={act} />
        ))}
      </div>
      {!devices.length && (
        <Empty
          icon={Search}
          title="No matching devices"
          detail="Try another name or room."
        />
      )}
      <div className="quiet-note">
        <ShieldCheck size={18} />
        <p>
          Every command passes through the core control service. Manual changes
          hold a five-minute override. MQTT, Home Assistant, Matter, Zigbee,
          Z-Wave, Bluetooth, and wired drivers are future integrations.
        </p>
      </div>
    </>
  );
}

export function DeviceCard({ device: d, act }: { device: Row; act: Act }) {
  const [value, setValue] = useState(d.value);
  useEffect(() => setValue(d.value), [d.value]);
  const Icon =
    d.kind === "light"
      ? Lightbulb
      : d.kind === "ventilation"
        ? Fan
        : d.kind === "thermostat"
          ? Thermometer
          : LockKeyhole;
  const blocked = d.status !== "online";
  return (
    <div className={cn("device-card", blocked && "interlocked")}>
      <div className="row-between">
        <span className={"device-icon " + (d.kind === "light" ? "amber" : "")}>
          <Icon size={20} />
        </span>
        <Badge tone={blocked ? "amber" : "green"}>
          {blocked ? "INTERLOCKED" : "ONLINE"}
        </Badge>
      </div>
      <h3>{d.name.split(" · ")[1] || d.name}</h3>
      <p>
        {d.name.includes(" · ")
          ? d.name.split(" · ")[0]
          : "Protected equipment"}{" "}
        <span>·</span> {d.adapter}
      </p>
      <div className="device-value">
        {blocked ? (
          <span className="protected-label">Hardware safeguard active</span>
        ) : (
          <>
            {number(value)}
            <small>{d.kind === "thermostat" ? "°C" : "%"}</small>
          </>
        )}
      </div>
      <input
        type="range"
        aria-label={`${d.name} value`}
        min={d.kind === "thermostat" ? 10 : 0}
        max={d.kind === "thermostat" ? 32 : 100}
        step={d.kind === "thermostat" ? 0.5 : 1}
        value={value}
        disabled={blocked}
        onChange={(e) => setValue(+e.target.value)}
      />
      <div className="row-between">
        <span className="tiny-label">
          {blocked
            ? "NO CONTROL ADAPTER"
            : d.manual_until > Date.now() / 1000
              ? "MANUAL OVERRIDE"
              : "SIMULATED CONTROL"}
        </span>
        <button
          className="button small"
          disabled={blocked || value === d.value}
          onClick={() =>
            act(
              `/devices/${d.id}/command`,
              { value },
              "POST",
              "Simulated device updated",
            )
          }
        >
          Apply
          <Check size={13} />
        </button>
      </div>
    </div>
  );
}
