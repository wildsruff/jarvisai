import { Battery, Bot, Compass, Play, ShieldCheck, Square } from "lucide-react";
import { useState } from "react";
import { EstateState } from "../api";
import { Act, Badge, Panel, TaskList } from "../ui";
export function Robotics({ state, act }: { state: EstateState; act: Act }) {
  const [destinations, setDestinations] = useState<Record<string, string>>({});
  return (
    <>
      <div className="section-toolbar">
        <Badge tone={state.settings.autonomous ? "green" : "amber"}>
          MISSION AUTONOMY {state.settings.autonomous ? "ENABLED" : "DISABLED"}
        </Badge>
        <button
          className="button danger"
          onClick={() =>
            act(
              "/emergency-stop",
              undefined,
              "POST",
              "Simulation emergency stop engaged",
            )
          }
        >
          <Square size={15} />
          Stop simulated systems
        </button>
      </div>
      <div className="robot-grid">
        {state.robots.map((r) => (
          <Panel
            key={r.id}
            title={r.name}
            icon={Bot}
            action={
              <Badge tone={r.estop ? "amber" : "green"}>{r.status}</Badge>
            }
          >
            <div className="robot-visual">
              <div className="robot-rings" />
              <Bot size={76} strokeWidth={1} />
              <span>{r.category.toUpperCase()}</span>
            </div>
            <div className="robot-telemetry">
              <div>
                <Battery size={16} />
                <strong>{r.battery}%</strong>
                <span>Battery</span>
              </div>
              <div>
                <Compass size={16} />
                <strong>
                  {state.rooms.find((room) => room.id === r.room_id)?.name}
                </strong>
                <span>Location</span>
              </div>
              <div>
                <ShieldCheck size={16} />
                <strong>{r.interlock ? "Clear" : "Blocked"}</strong>
                <span>Simulated interlock</span>
              </div>
            </div>
            {r.status === "navigating" && (
              <div className="mission-progress">
                <span>Mission progress {r.progress}%</span>
                <progress value={r.progress} max={100} />
              </div>
            )}
            <div className="mission-form">
              <label>
                Mission destination
                <select
                  aria-label={`${r.name} destination`}
                  value={destinations[r.id] || "living"}
                  onChange={(e) =>
                    setDestinations((v) => ({ ...v, [r.id]: e.target.value }))
                  }
                >
                  {state.rooms.map((room) => (
                    <option key={room.id} value={room.id}>
                      {room.name}
                    </option>
                  ))}
                </select>
              </label>
              <button
                className="button primary"
                disabled={
                  r.estop || r.status !== "idle" || !state.settings.autonomous
                }
                onClick={() =>
                  act(
                    "/tasks",
                    {
                      workflow: "robot-mission",
                      subject: "Authorized simulated navigation",
                      robot_id: r.id,
                      room_id: destinations[r.id] || "living",
                    },
                    "POST",
                    "Simulated mission queued",
                  )
                }
              >
                <Play size={15} />
                Assign mission
              </button>
              {r.estop && (
                <button
                  className="button"
                  onClick={() =>
                    act(
                      `/robots/${r.id}/reset`,
                      undefined,
                      "POST",
                      "Simulated robot safety state reset",
                    )
                  }
                >
                  Reset simulated stop
                </button>
              )}
            </div>
          </Panel>
        ))}
      </div>
      <div className="quiet-note">
        <ShieldCheck size={20} />
        <p>
          Robots operate entirely in simulation. Mission handlers check
          autonomy, battery, emergency stop, and simulated interlocks. ROS 2,
          fabrication drivers, real navigation, and physical safety integration
          are roadmap items.
        </p>
      </div>
      <TaskList
        tasks={state.tasks.filter((t) => t.workflow === "robot-mission")}
        act={act}
      />
    </>
  );
}
