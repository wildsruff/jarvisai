import { ArrowUpRight, Clock3, Compass } from "lucide-react";
import { useState } from "react";
import { EstateState, Row } from "../api";
import { Act, Badge, date, Empty, Panel, TaskList, Toggle } from "../ui";
export function Research({ state, act }: { state: EstateState; act: Act }) {
  const [subject, setSubject] = useState("Local-first home intelligence");
  return (
    <>
      <div className="two-column wide-left">
        <Panel title="Explore an idea" icon={Compass}>
          <form
            className="padded-form"
            onSubmit={(e) => {
              e.preventDefault();
              act(
                "/tasks",
                { workflow: "research", subject },
                "POST",
                "Research workflow queued",
              );
            }}
          >
            <p className="muted-text">
              Requests travel through the external data boundary. Returned
              content never becomes a control instruction.
            </p>
            <label>
              Research subject
              <textarea
                rows={3}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                maxLength={500}
              />
            </label>
            <button className="button primary">
              <Compass size={16} />
              Prepare research
            </button>
          </form>
        </Panel>
        <Panel title="Scheduled discovery" icon={Clock3}>
          <div className="padded-form">
            <div className="row-between">
              <div>
                <h4>Daily research workflow</h4>
                <p className="muted-text">Every 24 hours while the core runs</p>
              </div>
              <Toggle
                label="Enable scheduled research"
                value={state.schedule.enabled}
                onChange={(enabled) =>
                  act(
                    "/research/schedule",
                    { enabled },
                    "PUT",
                    "Research schedule updated",
                  )
                }
              />
            </div>
            <p>{state.schedule.subject}</p>
            <div className="panel-note">
              {state.schedule.last_run
                ? "Last queued: " +
                  date(new Date(state.schedule.last_run * 1000).toISOString())
                : "No scheduled run yet."}{" "}
              Offline mode prepares a plan. A configured gateway returns clearly
              labeled fixture references.
            </div>
          </div>
        </Panel>
      </div>
      <Panel
        title="Research library"
        icon={Compass}
        action={<Badge tone="subtle">UNTRUSTED DATA · HUMAN REVIEW</Badge>}
      >
        {!state.research.length ? (
          <Empty
            icon={Compass}
            title="Curiosity, with boundaries"
            detail="Prepare a research workflow to create a persistent report. No live web provider is bundled in this release."
          />
        ) : (
          <div className="research-grid">
            {state.research.map((r) => (
              <div className="research-card" key={r.id}>
                <div className="row-between">
                  <Badge tone="amber">{r.mode}</Badge>
                  <span className="tiny-label">{date(r.timestamp)}</span>
                </div>
                <h3>{r.subject}</h3>
                <p>{r.summary}</p>
                <h4>Suggested next steps</h4>
                <ol>
                  {r.next_steps.map((s: string) => (
                    <li key={s}>{s}</li>
                  ))}
                </ol>
                <div className="source-list">
                  {r.sources.map((s: Row) => (
                    <a
                      key={s.url}
                      href={s.url}
                      rel="noreferrer noopener"
                      target="_blank"
                    >
                      <span>
                        {s.title}
                        <small>{s.evidence}</small>
                      </span>
                      <ArrowUpRight size={15} />
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </Panel>
      <TaskList
        tasks={state.tasks.filter((t) => t.workflow === "research")}
        act={act}
      />
    </>
  );
}
