import {
  Activity,
  CheckCheck,
  Flame,
  FlaskConical,
  LockKeyhole,
  RefreshCw,
  Shield,
  ShieldCheck,
} from "lucide-react";
import { useState } from "react";
import { EstateState } from "../api";
import { Act, AuditTable, Badge, date, Empty, Panel, Stat } from "../ui";
export function Security({ state, act }: { state: EstateState; act: Act }) {
  const [scenario, setScenario] = useState("smoke");
  const [room, setRoom] = useState("kitchen");
  const alerts = state.alerts.filter((a) => a.status === "active");
  return (
    <>
      <div className="stats-grid three">
        <Stat
          icon={ShieldCheck}
          label="POLICY BOUNDARY"
          value="Enforced"
          detail="All simulator commands authorized"
          status="Active"
        />
        <Stat
          icon={LockKeyhole}
          label="PROTECTED EQUIPMENT"
          value="3"
          detail="Locks · pumps · generators"
          status="Interlocked"
          color="amber"
        />
        <Stat
          icon={Activity}
          label="AUDIT CHAIN"
          value={state.system.audit_integrity ? "Verified" : "Invalid"}
          detail="SHA-256 linked event history"
          status={state.system.audit_integrity ? "Consistent" : "Investigate"}
          color="blue"
        />
      </div>
      <div className="two-column wide-left">
        <Panel
          title="Safety event monitor"
          icon={Shield}
          action={
            <Badge tone={alerts.length ? "amber" : "green"}>
              {alerts.length} ACTIVE
            </Badge>
          }
        >
          {alerts.length ? (
            alerts.map((a) => (
              <div className={"alert-card " + a.severity} key={a.id}>
                <div className="row-between">
                  <h3>
                    {a.kind === "smoke" ? (
                      <Flame size={18} />
                    ) : (
                      <Shield size={18} />
                    )}
                    {a.kind.toUpperCase()} ·{" "}
                    {state.rooms.find((r) => r.id === a.room_id)?.name}
                  </h3>
                  <Badge tone="amber">SIMULATED</Badge>
                </div>
                <p>{a.message}</p>
                <ol>
                  {a.response.map((r: string) => (
                    <li key={r}>{r}</li>
                  ))}
                </ol>
                <div className="row-between">
                  <span className="muted-text">{date(a.timestamp)}</span>
                  <button
                    className="button small"
                    disabled={a.acknowledged}
                    onClick={() =>
                      act(
                        `/alerts/${a.id}/acknowledge`,
                        undefined,
                        "POST",
                        "Alert acknowledged; condition remains active until reset",
                      )
                    }
                  >
                    {a.acknowledged ? (
                      <>
                        <CheckCheck size={14} />
                        Acknowledged
                      </>
                    ) : (
                      "Acknowledge"
                    )}
                  </button>
                </div>
              </div>
            ))
          ) : (
            <Empty
              icon={ShieldCheck}
              title="No active simulated events"
              detail="Independent certified alarms and emergency systems remain essential."
            />
          )}
        </Panel>
        <Panel title="Emergency scenario lab" icon={FlaskConical}>
          <form
            className="padded-form"
            onSubmit={(e) => {
              e.preventDefault();
              act(
                "/simulation/scenario",
                { kind: scenario, room_id: room },
                "POST",
                "Simulated event injected",
              );
            }}
          >
            <p className="muted-text">
              Exercise alert workflows using synthetic conditions.
            </p>
            <label>
              Event type
              <select
                value={scenario}
                onChange={(e) => setScenario(e.target.value)}
              >
                {[
                  "smoke",
                  "co",
                  "leak",
                  "heat",
                  "power",
                  "network",
                  "wildfire",
                  "intrusion",
                  "equipment",
                ].map((s) => (
                  <option key={s} value={s}>
                    {s === "co" ? "Carbon monoxide" : s}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Location
              <select value={room} onChange={(e) => setRoom(e.target.value)}>
                {state.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </label>
            <button className="button amber-button">
              <FlaskConical size={15} />
              Inject simulated event
            </button>
            <button
              type="button"
              className="button"
              onClick={() =>
                act(
                  "/simulation/scenario",
                  { kind: "normal" },
                  "POST",
                  "Normal conditions restored; simulated alerts resolved",
                )
              }
            >
              <RefreshCw size={15} />
              Restore normal conditions
            </button>
          </form>
        </Panel>
      </div>
      <div className="safety-callout">
        <ShieldCheck size={23} />
        <div>
          <h3>
            Intelligence supports safety. Certified hardware protects life.
          </h3>
          <p>
            JARVIS does not replace fire alarms, emergency shutoffs, required
            emergency response, or code-compliant systems. Suppression, locks,
            and generators have no actuation adapters in this release. The stop
            button affects this simulator only.
          </p>
        </div>
      </div>
      <AuditTable logs={state.audit} />
    </>
  );
}
