import { Activity, Gauge, Leaf, Sparkles, Wind } from "lucide-react";
import { useState } from "react";
import { ProactiveInsights } from "./proactive-insights";
import { EstateState } from "../api";
import { Badge, Chart, cn, Empty, number, Panel, useHistory } from "../ui";
export function Environment({
  state,
  tick,
  act,
}: {
  state: EstateState;
  tick: number;
  act: import("../ui").Act;
}) {
  const [room, setRoom] = useState("living");
  const [metric, setMetric] = useState("temperature");
  const points = useHistory(room, metric, tick);
  const sensors = state.sensors.filter((s) => s.room_id === room);
  const selected = sensors.find((s) => s.metric === metric)!;
  return (
    <>
      <ProactiveInsights state={state} act={act} />
      <div className="section-toolbar">
        <div className="inline">
          <Badge>LIVE TELEMETRY</Badge>
          <span className="muted-text">
            Simulated · sampled every 6 seconds
          </span>
        </div>
        <select
          aria-label="Environment room"
          value={room}
          onChange={(e) => setRoom(e.target.value)}
        >
          {state.rooms.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </div>
      <div className="sensor-grid">
        {sensors
          .filter((s) =>
            ["temperature", "humidity", "co2", "pm25"].includes(s.metric),
          )
          .map((s) => (
            <button
              key={s.id}
              className={cn("sensor-card", metric === s.metric && "active")}
              onClick={() => setMetric(s.metric)}
            >
              <span>
                {s.metric === "co2"
                  ? "CARBON DIOXIDE"
                  : s.metric === "pm25"
                    ? "PARTICULATES · PM2.5"
                    : s.metric.toUpperCase()}
              </span>
              <strong>
                {number(s.value)}
                <small>{s.unit}</small>
              </strong>
              <span>
                <i className="dot teal" />
                Sensor online
              </span>
            </button>
          ))}
      </div>
      <Panel
        title={`${state.rooms.find((r) => r.id === room)!.name} · ${metric.toUpperCase()} history`}
        icon={Activity}
        action={
          <select
            value={metric}
            onChange={(e) => setMetric(e.target.value)}
            aria-label="Historical sensor metric"
          >
            {sensors.map((s) => (
              <option key={s.metric} value={s.metric}>
                {s.metric.toUpperCase()} · {s.unit}
              </option>
            ))}
          </select>
        }
      >
        <div className="chart-padded">
          <Chart
            points={points}
            height={230}
            unit={" " + selected.unit}
            label={`${metric} historical readings`}
          />
        </div>
      </Panel>
      <div className="two-column">
        <Panel title="All environmental channels" icon={Gauge}>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Channel</th>
                  <th>Reading</th>
                  <th>Reliability</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                {sensors.map((s) => (
                  <tr key={s.id}>
                    <td>{s.metric.replaceAll("_", " ")}</td>
                    <td className="mono">
                      {number(s.value)}{" "}
                      <span className="muted-text">{s.unit}</span>
                    </td>
                    <td>
                      <Badge tone={s.status === "online" ? "green" : "amber"}>
                        {s.status}
                      </Badge>
                    </td>
                    <td>Simulation</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
        <Panel title="Environmental recommendations" icon={Sparkles}>
          {state.recommendations.length ? (
            state.recommendations.map((r) => (
              <div className="recommendation" key={r.id}>
                <Wind size={18} />
                <div>
                  <h4>{r.title}</h4>
                  <p>
                    {r.room}: {number(r.value)} {r.unit}
                  </p>
                  <p>{r.detail}</p>
                </div>
              </div>
            ))
          ) : (
            <Empty
              icon={Leaf}
              title="A balanced environment"
              detail="No advisory thresholds exceeded. Continue reviewing trends and independent alarm systems."
            />
          )}
          <div className="panel-note">
            Threshold-based advice uses simulated telemetry. It does not replace
            certified environmental or life-safety instruments.
          </div>
        </Panel>
      </div>
    </>
  );
}
