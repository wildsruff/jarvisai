import {
  AudioLines,
  Check,
  Clock3,
  Eye,
  Home,
  Layers3,
  Mic,
  MicOff,
  Plus,
  Volume2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { api, EstateState, Row } from "../api";
import { Act, Badge, cn, date, number, Panel, Toggle, Twin } from "../ui";
export function DigitalTwin({
  state,
  act,
  tick,
}: {
  state: EstateState;
  act: Act;
  tick: number;
}) {
  const [room, setRoom] = useState("living");
  const [fields, setFields] = useState(false);
  const [metric, setMetric] = useState("temperature");
  const [events, setEvents] = useState<Row[]>([]);
  const [playback, setPlayback] = useState(-1);
  useEffect(() => {
    api<Row[]>("/spatial/events")
      .then(setEvents)
      .catch(() => {});
  }, [Math.floor(tick / 2)]);
  const selected = state.rooms.find((r) => r.id === room)!;
  return (
    <>
      <div className="section-toolbar">
        <div className="segmented">
          <span className="active">Ground floor</span>
        </div>
        <div className="inline">
          <select
            aria-label="Map overlay"
            value={metric}
            onChange={(e) => setMetric(e.target.value)}
          >
            <option value="temperature">Temperature overlay</option>
            <option value="co2">CO₂ overlay</option>
            <option value="humidity">Humidity overlay</option>
          </select>
          <button
            className={cn("button", fields && "selected")}
            onClick={() => setFields(!fields)}
          >
            <Eye size={16} />
            Sensor fields of view
          </button>
        </div>
      </div>
      <div className="two-column wide-left">
        <Panel
          title="Main residence · Ground floor"
          icon={Layers3}
          action={<Badge>{playback < 0 ? "LIVE" : "EVENT REPLAY"}</Badge>}
        >
          <Twin
            state={state}
            selected={room}
            onSelect={setRoom}
            fields={fields}
            metric={metric}
            events={events}
            playback={playback}
          />
          <div className="playback-bar">
            <Clock3 size={17} />
            <div>
              <strong>Occupancy event history</strong>
              <span>
                {playback < 0
                  ? "Live occupancy · no person identification"
                  : `${date(events[playback]?.timestamp)} · ${events[playback]?.room_id}: ${events[playback]?.count} detections`}
              </span>
            </div>
            <input
              aria-label="Occupancy event playback"
              type="range"
              min={-1}
              max={Math.max(-1, events.length - 1)}
              value={playback}
              onChange={(e) => setPlayback(+e.target.value)}
              disabled={!events.length}
            />
            <button className="button small" onClick={() => setPlayback(-1)}>
              Live
            </button>
          </div>
        </Panel>
        <div>
          <Panel title={selected.name} icon={Home}>
            <div className="detail-list">
              <div>
                <span>Building</span>
                <strong>Main residence</strong>
              </div>
              <div>
                <span>Floor</span>
                <strong>Ground</strong>
              </div>
              <div>
                <span>Occupancy source</span>
                <strong>Anonymous simulator</strong>
              </div>
            </div>
            <form
              className="padded-form"
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                act(
                  `/rooms/${room}/occupancy`,
                  { count: Number(form.get("count")) },
                  "PUT",
                  "Simulated occupancy updated",
                );
              }}
            >
              <label>
                Simulate occupancy
                <input
                  key={room}
                  name="count"
                  type="number"
                  min="0"
                  max="20"
                  defaultValue={selected.occupancy}
                  required
                />
              </label>
              <button className="button" type="submit">
                <Plus size={15} />
                Update detections
              </button>
            </form>
            <div className="room-readings">
              {state.sensors
                .filter(
                  (s) =>
                    s.room_id === room &&
                    ["temperature", "humidity", "co2", "pm25"].includes(
                      s.metric,
                    ),
                )
                .map((s) => (
                  <div key={s.id}>
                    <span>{s.metric.toUpperCase()}</span>
                    <strong>
                      {number(s.value)}
                      <small>{s.unit}</small>
                    </strong>
                  </div>
                ))}
            </div>
          </Panel>
          <div className="quiet-note">
            <Eye size={18} />
            <p>
              Occupancy indicates a count, never an identity. Field-of-view
              cones are illustrative. The first release includes one editable
              occupancy floor; building geometry and furniture are seeded.
            </p>
          </div>
        </div>
      </div>
      <AudioZones state={state} act={act} />
    </>
  );
}

export function AudioZones({ state, act }: { state: EstateState; act: Act }) {
  return (
    <Panel
      title="Whole-home audio"
      icon={AudioLines}
      action={<Badge tone="subtle">SIMULATED · NO AUDIO CAPTURE</Badge>}
    >
      <div className="audio-grid">
        {state.audios.map((zone) => (
          <AudioZone
            key={zone.id}
            zone={zone}
            act={act}
            occupied={state.rooms.find((r) => r.id === zone.id)!.occupancy > 0}
          />
        ))}
      </div>
    </Panel>
  );
}

export function AudioZone({
  zone,
  act,
  occupied,
}: {
  zone: Row;
  act: Act;
  occupied: boolean;
}) {
  const [volume, setVolume] = useState(zone.volume);
  const [playback, setPlayback] = useState(zone.playback);
  const [microphone, setMicrophone] = useState(zone.microphone);
  const [muted, setMuted] = useState(zone.hardware_muted);
  useEffect(() => {
    setVolume(zone.volume);
    setPlayback(zone.playback);
    setMicrophone(zone.microphone);
    setMuted(zone.hardware_muted);
  }, [zone.volume, zone.playback, zone.microphone, zone.hardware_muted]);
  return (
    <div className="audio-zone">
      <div className="row-between">
        <h4>{zone.name}</h4>
        {zone.microphone === "muted" ? (
          <MicOff size={15} className="muted-text" />
        ) : (
          <Mic size={15} className="amber-text" />
        )}
      </div>
      <span className="audio-status">
        {zone.microphone === "muted"
          ? "MICROPHONE MUTED"
          : zone.microphone.toUpperCase()}{" "}
        · {occupied ? "OCCUPIED" : "UNOCCUPIED"}
      </span>
      <label className="range-label">
        <Volume2 size={15} />
        <input
          type="range"
          min="0"
          max="100"
          value={volume}
          onChange={(e) => setVolume(+e.target.value)}
          aria-label={`${zone.name} volume`}
        />
        <span>{volume}%</span>
      </label>
      <select
        aria-label={`${zone.name} playback`}
        value={playback}
        onChange={(e) => setPlayback(e.target.value)}
      >
        <option value="stopped">Playback stopped</option>
        <option value="ambient">Ambient route</option>
        <option value="announcement">Announcement route</option>
      </select>
      <div className="row-between mute-row">
        <span>Hardware mute simulator</span>
        <Toggle
          label={`${zone.name} hardware mute`}
          value={muted}
          onChange={(v) => {
            setMuted(v);
            if (v) setMicrophone("muted");
          }}
        />
      </div>
      <select
        aria-label={`${zone.name} microphone mode`}
        disabled={muted}
        value={microphone}
        onChange={(e) => setMicrophone(e.target.value)}
      >
        <option value="muted">Microphone muted</option>
        <option value="push-to-talk">Push-to-talk simulation</option>
        <option value="always-listening">
          Enable always-listening simulation
        </option>
      </select>
      <button
        className="button small full"
        onClick={() =>
          act(
            `/audio/${zone.id}`,
            { volume, playback, microphone, hardware_muted: muted },
            "PUT",
            "Audio zone settings saved",
          )
        }
      >
        <Check size={14} />
        Apply zone settings
      </button>
    </div>
  );
}
