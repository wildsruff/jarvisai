import {
  Activity,
  ArrowRight,
  Battery,
  CircuitBoard,
  Home,
  Leaf,
  Network,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { EstateState } from "../api";
import { Badge, Chart, number, Panel, Stat, useHistory } from "../ui";
export function Energy({ state, tick }: { state: EstateState; tick: number }) {
  const [room, setRoom] = useState("living");
  const [metric, setMetric] = useState("energy");
  const points = useHistory(room, metric, tick);
  const sum = (m: string) =>
    state.sensors
      .filter((s) => s.metric === m)
      .reduce((a, b) => a + b.value, 0);
  const load = sum("energy"),
    solar = sum("solar");
  return (
    <>
      <div className="stats-grid three">
        <Stat
          icon={Zap}
          label="ESTATE CONSUMPTION"
          value={number(load)}
          unit="kW"
          detail="Sum of simulated room meters"
          status="Live load"
          color="amber"
        />
        <Stat
          icon={Leaf}
          label="SOLAR GENERATION"
          value={number(solar)}
          unit="kW"
          detail="Sum of simulated zone arrays"
          status="Generating"
        />
        <Stat
          icon={Battery}
          label="BATTERY STORAGE"
          value={number(sum("battery") / state.rooms.length, 0)}
          unit="%"
          detail="Average simulated state of charge"
          status="Standby"
          color="blue"
        />
      </div>
      <Panel
        title="Energy history"
        icon={Activity}
        action={
          <div className="inline">
            <select
              aria-label="Energy room"
              value={room}
              onChange={(e) => setRoom(e.target.value)}
            >
              {state.rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
            <select
              aria-label="Energy metric"
              value={metric}
              onChange={(e) => setMetric(e.target.value)}
            >
              <option value="energy">Consumption</option>
              <option value="solar">Solar generation</option>
              <option value="battery">Battery charge</option>
            </select>
          </div>
        }
      >
        <div className="chart-padded">
          <Chart
            points={points}
            height={240}
            unit={metric === "battery" ? "%" : " kW"}
            color={metric === "energy" ? "#dcba77" : "#62d9bf"}
          />
        </div>
      </Panel>
      <div className="two-column">
        <Panel title="Estate energy balance" icon={Network}>
          <div className="energy-flow">
            <div>
              <span className="energy-flow-icon">
                <Leaf size={26} />
              </span>
              <strong>{number(solar)} kW</strong>
              <span>Generation</span>
            </div>
            <ArrowRight size={22} />
            <div>
              <span className="energy-flow-icon">
                <Home size={26} />
              </span>
              <strong>{number(load)} kW</strong>
              <span>Estate demand</span>
            </div>
            <ArrowRight size={22} />
            <div>
              <span className="energy-flow-icon">
                <Battery size={26} />
              </span>
              <strong>{number(Math.max(0, solar - load))} kW</strong>
              <span>Simulated surplus</span>
            </div>
          </div>
          <div className="panel-note">
            Synthetic generation is independent of real weather. This display
            does not operate inverters, batteries, or grid equipment.
          </div>
        </Panel>
        <Panel title="Equipment interfaces" icon={CircuitBoard}>
          <div className="detail-list">
            <div>
              <span>Generator</span>
              <Badge tone="amber">INTERLOCKED</Badge>
            </div>
            <div>
              <span>Independent emergency power</span>
              <strong>Hardware interface planned</strong>
            </div>
            <div>
              <span>Power-failure monitoring</span>
              <strong>Scenario simulation</strong>
            </div>
            <div>
              <span>Efficiency recommendations</span>
              <strong>Advisory only</strong>
            </div>
          </div>
        </Panel>
      </div>
    </>
  );
}
