import {
  ArrowUpRight,
  BrainCircuit,
  Check,
  CheckCheck,
  CircleHelp,
  Download,
  MemoryStick,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import React, { useState } from "react";
import { api, EstateState, Row } from "../api";
import { Act, Badge, date, Empty, Modal } from "../ui";
export function Memories({ state, act }: { state: EstateState; act: Act }) {
  const [history, setHistory] = useState<Row[] | null>(null);
  const [retrieved, setRetrieved] = useState<Row[] | null>(null);
  const [retrievalError, setRetrievalError] = useState("");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const kinds = ["working", "episodic", "semantic", "spatial", "procedural"];
  const items = (retrieved ?? state.memories).filter(
    (m) =>
      (filter === "all" || m.kind === filter) &&
      (retrieved !== null ||
        m.content.toLowerCase().includes(search.toLowerCase())),
  );
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const result = await act(
      "/memories" + (editing?.id ? "/" + editing.id : ""),
      {
        kind: f.get("kind"),
        content: f.get("content"),
        source: f.get("source"),
        confidence: Number(f.get("confidence")),
        verified: f.get("verified") === "on",
        sensitive: f.get("sensitive") === "on",
        retention_days: Number(f.get("retention")),
      },
      editing?.id ? "PUT" : "POST",
      "Memory saved with provenance and retention",
    );
    if (result) setEditing(null);
  }
  return (
    <>
      <div className="section-toolbar">
        <div className="input-icon">
          <Search size={15} />
          <input
            placeholder="Search memory…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setRetrieved(null);
            }}
            aria-label="Search memory"
          />
        </div>
        <div className="inline">
          <a className="button" href="/api/v1/memories/export" download>
            <Download size={15} />
            Export JSON
          </a>
          <button
            className="button primary"
            onClick={() =>
              setEditing({
                kind: "semantic",
                confidence: 1,
                verified: false,
                retention_days: state.settings.memory_retention_days || 30,
                source: "user",
              })
            }
          >
            <Plus size={16} />
            Add memory
          </button>
        </div>
      </div>
      <div className="inline section-toolbar">
        <button
          className="button"
          disabled={!search.trim()}
          onClick={async () => {
            try {
              setRetrieved(
                await api<Row[]>(
                  `/memories/search?q=${encodeURIComponent(search)}`,
                ),
              );
              setRetrievalError("");
            } catch (e) {
              setRetrievalError((e as Error).message);
            }
          }}
        >
          Retrieve relevant memories
        </button>
        {retrievalError && <span role="alert">{retrievalError}</span>}
      </div>
      <section className="panel">
        <div className="panel-head">
          <h3>Candidate memory review</h3>
          <Badge tone="amber">APPROVAL REQUIRED</Badge>
        </div>
        {state.memory_candidates?.filter((c) => c.status === "pending")
          .length ? (
          <div className="research-grid">
            {state.memory_candidates
              .filter((c) => c.status === "pending")
              .map((c) => (
                <article className="memory-candidate research-card" key={c.id}>
                  <Badge tone={c.sensitive ? "amber" : "blue"}>
                    {c.sensitive
                      ? "SENSITIVE / CONSEQUENTIAL"
                      : "UNVERIFIED CANDIDATE"}
                  </Badge>
                  <p>{c.content}</p>
                  <p className="form-hint">
                    {c.source} · confidence {Math.round(c.confidence * 100)}% ·{" "}
                    {c.retention_days} days on approval.{" "}
                    {c.conflicts.length > 0 &&
                      "Potential contradiction; conflicting memories are withheld from retrieval."}
                  </p>
                  <div className="inline">
                    <button
                      className="button primary"
                      onClick={() =>
                        act(
                          `/memory-candidates/${c.id}/review`,
                          { decision: "approve" },
                          "POST",
                          "Candidate approved as unverified memory",
                        )
                      }
                    >
                      Approve memory
                    </button>
                    <button
                      className="button"
                      onClick={() =>
                        act(
                          `/memory-candidates/${c.id}/review`,
                          { decision: "reject" },
                          "POST",
                          "Candidate rejected",
                        )
                      }
                    >
                      Reject candidate
                    </button>
                  </div>
                </article>
              ))}
          </div>
        ) : (
          <div className="panel-note">
            No pending candidates. Conversation extraction recognizes explicit
            first-person statements; every candidate requires your approval.
            Credentials are excluded.
          </div>
        )}
      </section>
      <div className="memory-tabs">
        <button
          className={filter === "all" ? "active" : ""}
          onClick={() => setFilter("all")}
        >
          All memories <span>{state.memories.length}</span>
        </button>
        {kinds.map((k) => (
          <button
            className={filter === k ? "active" : ""}
            onClick={() => setFilter(k)}
            key={k}
          >
            {k}
            <span>{state.memories.filter((m) => m.kind === k).length}</span>
          </button>
        ))}
      </div>
      <div className="memory-grid">
        {items.map((m) => (
          <div className="memory-card" key={m.id}>
            <div className="row-between">
              <Badge tone="blue">{m.kind}</Badge>
              <span className={m.verified ? "teal-text" : "amber-text"}>
                {m.verified ? (
                  <CheckCheck size={16} />
                ) : (
                  <CircleHelp size={16} />
                )}
              </span>
            </div>
            <p className="memory-content">{m.content}</p>
            {m.conflicts?.length > 0 && (
              <p className="form-error">
                Potential contradiction: withheld from chat until corrected or
                removed.
              </p>
            )}
            <div className="memory-provenance">
              <span>
                Source<strong>{m.source}</strong>
              </span>
              <span>
                Confidence
                <strong>
                  {Math.round(m.confidence * 100)}% ·{" "}
                  {m.verified ? "Verified" : "Unverified"}
                </strong>
              </span>
              <span>
                Retention<strong>Until {date(m.expires_at)}</strong>
              </span>
            </div>
            <div className="memory-card-footer">
              <span>{date(m.updated_at)}</span>
              <button className="text-button" onClick={() => setEditing(m)}>
                Inspect / correct
                <ArrowUpRight size={13} />
              </button>
              <button
                className="text-button"
                onClick={async () =>
                  setHistory(await api<Row[]>(`/memories/${m.id}/history`))
                }
              >
                History
              </button>
              <button
                className="icon-btn"
                onClick={() => setDeleting(m)}
                aria-label="Delete memory"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
      {!items.length && (
        <Empty
          icon={MemoryStick}
          title="Room for what matters"
          detail="Add a memory explicitly. Inferred preferences are never silently established as facts."
        />
      )}
      <div className="quiet-note">
        <BrainCircuit size={20} />
        <p>
          Five memory categories share a provenance-aware persistent repository.
          Retrieval uses labeled lexical concepts by default. Configure a local
          embedding model for semantic vectors; failures are reported as lexical
          fallback. Contradiction detection covers supported structured claims,
          not arbitrary natural language. Working conversations are stored
          separately and can be cleared from Conversation.
        </p>
      </div>
      {editing && (
        <Modal
          title={editing.id ? "Inspect & correct memory" : "Add a memory"}
          close={() => setEditing(null)}
        >
          <form className="modal-body form-grid" onSubmit={save}>
            <label>
              Memory system
              <select name="kind" defaultValue={editing.kind}>
                {kinds.map((k) => (
                  <option key={k}>{k}</option>
                ))}
              </select>
            </label>
            <label>
              Source / provenance
              <input
                name="source"
                defaultValue={editing.source}
                required
                maxLength={200}
              />
            </label>
            <label className="span-2">
              Content
              <textarea
                name="content"
                defaultValue={editing.content}
                required
                maxLength={4000}
                rows={4}
              />
            </label>
            <label>
              Confidence (0–1)
              <input
                name="confidence"
                type="number"
                min="0"
                max="1"
                step=".05"
                defaultValue={editing.confidence}
                required
              />
            </label>
            <label>
              Retention (days)
              <input
                name="retention"
                type="number"
                min="1"
                max="3650"
                defaultValue={editing.retention_days}
                required
              />
            </label>
            <label className="checkbox-label span-2">
              <input
                name="verified"
                type="checkbox"
                defaultChecked={editing.verified}
              />
              I have verified this information
            </label>
            <label className="checkbox-label span-2">
              <input
                name="sensitive"
                type="checkbox"
                defaultChecked={editing.sensitive}
              />
              Sensitive or consequential information
            </label>
            <p className="form-hint span-2">
              Saving resets the retention clock. Audit records retain the memory
              ID, not its content. Old server backups must be managed
              separately.
            </p>
            <button className="button primary span-2">
              <Check size={16} />
              Save memory
            </button>
          </form>
        </Modal>
      )}
      {history && (
        <Modal title="Memory correction history" close={() => setHistory(null)}>
          <div className="modal-body">
            {history.length ? (
              history.map((h) => (
                <div className="result-step" key={h.id}>
                  <div>
                    <strong>
                      Revision {h.revision} · {h.actor} · {date(h.timestamp)}
                    </strong>
                    <p>{h.snapshot.content}</p>
                    <span>
                      {h.snapshot.verified ? "Verified" : "Unverified"}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p>Legacy memory has no corrections yet.</p>
            )}
          </div>
        </Modal>
      )}
      {deleting && (
        <Modal title="Delete this memory?" close={() => setDeleting(null)}>
          <div className="modal-body">
            <p>“{deleting.content}”</p>
            <p className="muted-text">
              This removes the live memory. Existing exports and backups are not
              modified.
            </p>
            <button
              className="button danger"
              onClick={async () => {
                const v = await act(
                  `/memories/${deleting.id}`,
                  undefined,
                  "DELETE",
                  "Memory deleted",
                );
                if (v) setDeleting(null);
              }}
            >
              <Trash2 size={16} />
              Delete memory
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
