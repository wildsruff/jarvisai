import {
  ArrowUpRight,
  BrainCircuit,
  Gauge,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
  Square,
  Trash2,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { api, chatStream, EstateState, Row } from "../api";
import { Badge, Orb, Panel } from "../ui";
export function Conversation({
  state,
  refresh,
  notify,
}: {
  state: EstateState;
  refresh: () => Promise<void>;
  notify: (t: string, error?: boolean) => void;
}) {
  const [messages, setMessages] = useState<Row[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [task, setTask] = useState("conversation");
  const [streamInfo, setStreamInfo] = useState<Row>({});
  const [streamError, setStreamError] = useState("");
  const [retrieval, setRetrieval] = useState<Row>({});
  const [metrics, setMetrics] = useState<Row | null>(null);
  const abort = useRef<AbortController | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  useEffect(() => {
    api("/conversation/main").then((v) => setMessages(v.messages));
    return () => abort.current?.abort();
  }, []);
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [messages]);
  async function send(text = input) {
    if (!text.trim() || busy) return;
    setInput("");
    setBusy(true);
    setStreamError("");
    setMetrics(null);
    setMessages((m) => [
      ...m,
      { role: "user", content: text },
      { role: "assistant", content: "" },
    ]);
    const controller = new AbortController();
    abort.current = controller;
    try {
      await chatStream(
        text,
        task,
        controller.signal,
        (token) =>
          setMessages((m) =>
            m.map((item, i) =>
              i === m.length - 1
                ? { ...item, content: item.content + token }
                : item,
            ),
          ),
        setMetrics,
        (event) => {
          if (event.type === "status") {
            setStreamInfo(event);
            setMessages((m) =>
              m.map((item, i) =>
                i === m.length - 1 && item.role === "assistant"
                  ? { ...item, provider: event.provider, model: event.model }
                  : item,
              ),
            );
          }
          if (event.type === "context") setRetrieval(event);
          if (event.type === "error") setStreamError(event.error.message);
        },
      );
    } catch (e) {
      if ((e as Error).name !== "AbortError")
        notify((e as Error).message, true);
    } finally {
      setBusy(false);
      await refresh();
    }
  }
  async function clear() {
    try {
      await api("/conversation/main", "DELETE");
      setMessages([]);
      notify("Conversation history deleted");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  return (
    <div className="conversation-layout">
      <section className="panel chat-panel">
        <div className="panel-head">
          <h3>
            <span className="status-beacon" />
            JARVIS
            <Badge tone="subtle">
              {(
                streamInfo.provider || state.system.model.provider
              ).toUpperCase()}
            </Badge>
          </h3>
          <button
            className="icon-btn"
            onClick={clear}
            disabled={busy}
            aria-label="Clear conversation"
          >
            <Trash2 size={16} />
          </button>
        </div>
        {streamError && (
          <div className="connection-banner" role="alert">
            {streamError} No mock response was substituted.
          </div>
        )}
        <div
          className="chat-messages"
          role="log"
          aria-label="Conversation messages"
        >
          {messages.length === 0 && (
            <div className="chat-welcome">
              <Orb />
              <span className="eyebrow">AT HOME, WITH INTELLIGENCE</span>
              <h2>How can I help?</h2>
              <p>Inspect your estate. Explore an idea. Start a conversation.</p>
              <div className="suggestions">
                {[
                  "Give me an estate status overview",
                  "How is the air quality?",
                  "How does memory work?",
                ].map((s) => (
                  <button key={s} onClick={() => send(s)}>
                    {s}
                    <ArrowUpRight size={15} />
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={"message " + m.role}>
              <div className="message-avatar">
                {m.role === "user" ? "A" : <Sparkles size={16} />}
              </div>
              <div>
                <span className="message-author">
                  {m.role === "user" ? "You" : "JARVIS"}
                  {m.role === "assistant" && (
                    <small className="tiny-label">
                      {" "}
                      ·{" "}
                      {m.provider === "mock"
                        ? "MOCK"
                        : m.provider || "LEGACY · PROVIDER UNRECORDED"}
                    </small>
                  )}
                  {m.interrupted && " · Interrupted"}
                </span>
                <p>
                  {m.error?.message ||
                    m.content ||
                    (busy ? "Thinking locally…" : "Response interrupted.")}
                </p>
              </div>
            </div>
          ))}
          <div ref={bottom} />
        </div>
        <form
          className="chat-compose"
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Ask JARVIS anything…"
            aria-label="Message JARVIS"
            rows={2}
            maxLength={8000}
          />
          <div className="compose-bottom">
            <span>
              <LockKeyhole size={12} />
              Processed locally
            </span>
            <div>
              <select
                aria-label="Model task route"
                value={task}
                onChange={(e) => setTask(e.target.value)}
              >
                <option value="conversation">Conversation model</option>
                <option value="coding">Coding model</option>
                <option value="vision">Vision model · text input</option>
              </select>
              {busy ? (
                <button
                  type="button"
                  className="send-button stop"
                  onClick={async () => {
                    try {
                      await api("/chat/cancel", "POST");
                    } catch {
                      // The response can finish before the cancellation request arrives.
                    } finally {
                      abort.current?.abort();
                    }
                  }}
                  aria-label="Interrupt response"
                >
                  <Square size={15} />
                </button>
              ) : (
                <button
                  className="send-button"
                  disabled={!input.trim()}
                  aria-label="Send message"
                >
                  <ArrowUpRight size={18} />
                </button>
              )}
            </div>
          </div>
        </form>
        <p className="chat-disclosure">
          {state.system.model.provider === "mock"
            ? "Mock inference is active. Responses are deterministic simulation summaries."
            : "Local model output can be incorrect. Verify facts before acting."}{" "}
          Chat cannot control devices.
        </p>
      </section>
      <aside className="chat-side">
        <Panel title="Session context" icon={BrainCircuit}>
          <div className="detail-list">
            <div>
              <span>Intelligence domain</span>
              <strong>Local core</strong>
            </div>
            <div>
              <span>Style</span>
              <strong>{state.settings.personality}</strong>
            </div>
            <div>
              <span>Long-term memories</span>
              <strong>{state.memories.length}</strong>
            </div>
            <div>
              <span>Model task</span>
              <strong>{task}</strong>
            </div>
            <div>
              <span>Hardware privileges</span>
              <strong>None</strong>
            </div>
          </div>
        </Panel>
        {retrieval.memory_ids && (
          <Panel title="Retrieved context">
            <div className="padded-form">
              <p>
                {retrieval.memory_ids.length} relevant memories ·{" "}
                {retrieval.retrieval_method}
              </p>
              <p>
                {retrieval.candidate_count} pending candidates extracted this
                turn.
              </p>
            </div>
          </Panel>
        )}
        {metrics && (
          <Panel title="Inference metrics" icon={Gauge}>
            <div className="detail-list">
              <div>
                <span>Provider</span>
                <strong>{metrics.provider}</strong>
              </div>
              <div>
                <span>Latency</span>
                <strong>{metrics.latency_ms} ms</strong>
              </div>
              <div>
                <span>Input / output tokens</span>
                <strong>
                  {metrics.input_tokens ?? `~${metrics.estimated_input_tokens}`}{" "}
                  /{" "}
                  {metrics.output_tokens ??
                    `~${metrics.estimated_output_tokens}`}
                </strong>
              </div>
              <div>
                <span>Token counts</span>
                <strong>{metrics.token_counts}</strong>
              </div>
              <div>
                <span>Outcome</span>
                <strong>{metrics.status}</strong>
              </div>
            </div>
          </Panel>
        )}
        <div className="quiet-note">
          <ShieldCheck size={18} />
          <p>
            Explicit first-person statements can become pending candidates; they
            enter memory only after your approval. Conversation history stays on
            this server until you clear it.
          </p>
        </div>
      </aside>
    </div>
  );
}
