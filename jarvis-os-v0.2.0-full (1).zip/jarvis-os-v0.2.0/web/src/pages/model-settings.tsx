import { useEffect, useState } from "react";
import { Cpu, RefreshCw } from "lucide-react";
import { api, Row } from "../api";
import { Act, Badge, Panel } from "../ui";

export function ModelSettings({ act }: { act: Act }) {
  const [config, setConfig] = useState<Row | null>(null);
  const [discovery, setDiscovery] = useState<Row | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function discover() {
    setBusy(true);
    try {
      const r = await api("/models");
      setConfig(r.configuration);
      setDiscovery(r.discovery);
      setError("");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    discover();
  }, []);
  function update(key: string, value: unknown) {
    setConfig((c) => (c ? { ...c, [key]: value } : c));
  }
  return (
    <Panel
      title="Local inference configuration"
      icon={Cpu}
      action={
        <button
          className="button small"
          type="button"
          onClick={discover}
          disabled={busy}
        >
          <RefreshCw size={13} />
          Discover configured server
        </button>
      }
    >
      {error && (
        <p className="form-error padded-form" role="alert">
          {error}
        </p>
      )}
      {config && (
        <form
          className="padded-form form-grid"
          onSubmit={async (e) => {
            e.preventDefault();
            const { id: _id, ...body } = config;
            const saved = await act(
              "/models/configuration",
              body,
              "PUT",
              "Local inference configuration saved",
            );
            if (saved) setConfig(saved);
          }}
        >
          <label>
            Inference provider
            <select
              aria-label="Inference provider"
              value={config.provider}
              onChange={(e) => update("provider", e.target.value)}
            >
              <option value="mock">Mock · deterministic simulation</option>
              <option value="ollama">Ollama · real local inference</option>
              <option value="openai-local">
                OpenAI-compatible · local only
              </option>
            </select>
          </label>
          <label>
            Local server URL
            <input
              aria-label="Local model server URL"
              value={config.url}
              onChange={(e) => update("url", e.target.value)}
              required
              maxLength={300}
            />
          </label>
          {["conversation", "coding", "vision"].map((task) => (
            <label key={task}>
              {task} model
              <input
                aria-label={`${task} model selection`}
                value={config.routes[task]}
                list="discovered-models"
                onChange={(e) =>
                  update("routes", { ...config.routes, [task]: e.target.value })
                }
                required
                maxLength={200}
              />
            </label>
          ))}
          <datalist id="discovered-models">
            {discovery?.models?.map((m: Row) => (
              <option key={m.id} value={m.id} />
            ))}
          </datalist>
          {[
            ["context_chars", "Context character budget", 2048, 128000, 1],
            ["max_output_tokens", "Maximum output tokens", 16, 8192, 1],
            ["connect_timeout", "Connection timeout (seconds)", 0.05, 15, 0.05],
            ["idle_timeout", "Idle timeout (seconds)", 0.05, 120, 0.05],
            ["total_timeout", "Total deadline (seconds)", 0.05, 300, 0.05],
            ["connect_retries", "Connection retries", 0, 2, 1],
          ].map(([key, label, min, max, step]) => (
            <label key={String(key)}>
              {label}
              <input
                type="number"
                aria-label={String(label)}
                min={Number(min)}
                max={Number(max)}
                step={Number(step)}
                value={config[String(key)]}
                onChange={(e) => update(String(key), +e.target.value)}
                required
              />
            </label>
          ))}
          <div className="span-2">
            <Badge
              tone={
                discovery?.status === "online"
                  ? "green"
                  : discovery?.status === "mock"
                    ? "blue"
                    : "amber"
              }
            >
              {discovery?.status || "unchecked"}
            </Badge>
            <p className="form-hint">
              {discovery?.error?.message ||
                `${discovery?.models?.length || 0} models discovered from the saved configuration.`}{" "}
              Save changes before discovery. Model selection never downloads a
              model. Real-provider errors never substitute mock text. Context is
              a character budget, not a tokenizer guarantee.
            </p>
          </div>
          <button className="button primary span-2">
            Save inference configuration
          </button>
        </form>
      )}
      {!config && !error && (
        <div className="panel-note">
          Checking the configured local provider…
        </div>
      )}
    </Panel>
  );
}
