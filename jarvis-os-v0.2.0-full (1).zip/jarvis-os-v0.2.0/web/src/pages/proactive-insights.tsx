import { Sparkles } from "lucide-react";
import { EstateState } from "../api";
import { Act, Badge, date, Panel } from "../ui";
export function ProactiveInsights({
  state,
  act,
}: {
  state: EstateState;
  act: Act;
}) {
  const items = state.suggestions?.filter((s) => s.status === "open") || [];
  return (
    <Panel
      title="Proactive trend observations"
      icon={Sparkles}
      action={
        <button
          className="button small"
          onClick={() =>
            act(
              "/proactivity/evaluate",
              undefined,
              "POST",
              "Available sensor trends evaluated",
            )
          }
        >
          Evaluate recorded trends
        </button>
      }
    >
      {items.length ? (
        <div className="research-grid">
          {items.map((s) => (
            <article className="research-card" key={s.id}>
              <Badge tone="amber">EVIDENCE-BASED ADVICE</Badge>
              <h3>{s.title}</h3>
              <p>{s.detail}</p>
              <div className="detail-list compact">
                <div>
                  <span>Evidence source</span>
                  <strong>{s.evidence.source}</strong>
                </div>
                <div>
                  <span>First → latest</span>
                  <strong>
                    {s.evidence.first.value} → {s.evidence.last.value}{" "}
                    {s.evidence.unit}
                  </strong>
                </div>
                <div>
                  <span>Window</span>
                  <strong>
                    {date(s.evidence.first.timestamp)} →{" "}
                    {date(s.evidence.last.timestamp)}
                  </strong>
                </div>
              </div>
              <p className="form-hint">{s.uncertainty}</p>
              <div className="inline">
                {s.can_create_routine && (
                  <button
                    className="button"
                    onClick={() =>
                      act(
                        "/tasks",
                        {
                          workflow: "comfort-plan",
                          subject: `Review recorded ventilation trend in ${s.room_id}`,
                          room_id: s.room_id,
                        },
                        "POST",
                        "Routine planning queued; review it in AI Agents",
                      )
                    }
                  >
                    Prepare reviewed routine
                  </button>
                )}
                <button
                  className="text-button"
                  onClick={() =>
                    act(
                      `/suggestions/${s.id}/dismiss`,
                      undefined,
                      "POST",
                      "Observation dismissed",
                    )
                  }
                >
                  Dismiss
                </button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="panel-note">
          No fresh, sufficiently sampled rising trends meet the configured
          threshold. Missing or offline data is never presented as a finding.
          Proactivity preference: {state.settings.proactivity}%.
        </div>
      )}
    </Panel>
  );
}
