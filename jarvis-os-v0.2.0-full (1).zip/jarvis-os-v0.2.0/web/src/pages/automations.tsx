import {
  ArrowDown,
  Boxes,
  Check,
  Clock3,
  FlaskConical,
  Play,
  Plus,
} from "lucide-react";
import React, { useState } from "react";
import { EstateState, Row } from "../api";
import { Act, Badge, date, Empty, Modal, Panel, Toggle } from "../ui";
export function Automations({ state, act }: { state: EstateState; act: Act }) {
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState<Row | null>(null);
  const [steps, setSteps] = useState(1);
  async function run(id: string, dry: boolean) {
    const value = await act(
      `/rules/${id}/run?dry_run=${dry}`,
      undefined,
      "POST",
      dry ? "Dry-run complete: no device state changed" : "Workflow evaluated",
    );
    if (value) setResult(value);
  }
  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const value = await act(
      "/rules",
      {
        name: f.get("name"),
        room_id: f.get("room"),
        metric: f.get("metric"),
        operator: f.get("operator"),
        threshold: Number(f.get("threshold")),
        priority: Number(f.get("priority")),
        trigger: f.get("trigger"),
        interval_seconds: Number(f.get("interval")),
        enabled: false,
        actions: Array.from({ length: steps }, (_, i) => ({
          device_id: f.get("device" + i),
          value: Number(f.get("value" + i)),
        })),
      },
      "POST",
      "Automation created disabled, ready for a dry-run",
    );
    if (value) setCreating(false);
  }
  return (
    <>
      <div className="section-toolbar">
        <div className="inline">
          <Badge tone={state.settings.autonomous ? "green" : "amber"}>
            AUTONOMY {state.settings.autonomous ? "ENABLED" : "DISABLED"}
          </Badge>
          <span className="muted-text">
            Priority rules · manual overrides · atomic simulation
          </span>
        </div>
        <button className="button primary" onClick={() => setCreating(true)}>
          <Plus size={16} />
          Create automation
        </button>
      </div>
      <div className="automation-grid">
        {state.rules.map((rule) => (
          <Panel
            key={rule.id}
            title={rule.name}
            icon={Boxes}
            action={
              <Toggle
                label={`Enable ${rule.name}`}
                value={rule.enabled}
                onChange={(enabled) =>
                  act(
                    `/rules/${rule.id}/enabled`,
                    { enabled },
                    "PUT",
                    "Rule updated",
                  )
                }
              />
            }
          >
            <div className="rule-flow">
              <div>
                <span>WHEN</span>
                <strong>
                  {rule.trigger === "interval"
                    ? `Every ${rule.interval_seconds / 60} minutes`
                    : `${state.rooms.find((r) => r.id === rule.room_id)?.name} · ${rule.metric}`}
                </strong>
                <p>
                  {rule.metric} {rule.operator} {rule.threshold}
                </p>
              </div>
              <ArrowDown size={16} />
              {rule.actions.map((a: Row, i: number) => (
                <React.Fragment key={i}>
                  <div>
                    <span>THEN · STEP {i + 1}</span>
                    <strong>
                      {state.devices.find((d) => d.id === a.device_id)?.name}
                    </strong>
                    <p>
                      Set to {a.value}
                      {a.device_id.includes("thermostat") ? "°C" : "%"}
                    </p>
                  </div>
                  {i < rule.actions.length - 1 && <ArrowDown size={16} />}
                </React.Fragment>
              ))}
            </div>
            <div className="rule-footer">
              <span className="tiny-label">
                PRIORITY {rule.priority} · 60s COOLDOWN
              </span>
              <div className="inline">
                <button
                  className="button small"
                  onClick={() => run(rule.id, true)}
                >
                  <FlaskConical size={14} />
                  Dry-run
                </button>
                <button
                  className="button small"
                  onClick={() => run(rule.id, false)}
                >
                  <Play size={13} />
                  Run once
                </button>
              </div>
            </div>
          </Panel>
        ))}
      </div>
      <Panel title="Execution history" icon={Clock3}>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Workflow</th>
                <th>Timestamp</th>
                <th>Mode</th>
                <th>Outcome</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {state.runs.map((run) => (
                <tr key={run.id}>
                  <td>{run.name}</td>
                  <td>{date(run.timestamp)}</td>
                  <td>{run.dry_run ? "Dry-run" : "Execute"}</td>
                  <td>
                    <Badge tone={run.status === "blocked" ? "amber" : "green"}>
                      {run.status}
                    </Badge>
                  </td>
                  <td>
                    <div className="inline">
                      <button
                        className="text-button"
                        onClick={() => setResult(run)}
                      >
                        Inspect
                      </button>
                      {!run.dry_run && run.status === "completed" && (
                        <button
                          className="text-button amber-text"
                          onClick={() =>
                            act(
                              `/runs/${run.id}/rollback`,
                              undefined,
                              "POST",
                              "Simulated workflow rolled back",
                            )
                          }
                        >
                          Rollback
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!state.runs.length && (
            <Empty
              icon={FlaskConical}
              title="See before you act"
              detail="Dry-run a workflow to validate its steps without changing device state."
            />
          )}
        </div>
      </Panel>
      {result && (
        <Modal title="Workflow result" close={() => setResult(null)}>
          <div className="modal-body">
            <Badge tone={result.status === "blocked" ? "amber" : "green"}>
              {result.status}
            </Badge>
            {result.error && <p className="form-error">{result.error}</p>}
            <p>
              {result.dry_run
                ? "No devices were changed."
                : "This execution uses simulation adapters."}
            </p>
            {result.steps.map((s: Row, i: number) => (
              <div className="result-step" key={i}>
                <Check size={16} />
                <span>{s.device_id}</span>
                <strong>
                  {s.previous} → {s.value}
                </strong>
              </div>
            ))}
          </div>
        </Modal>
      )}
      {creating && (
        <Modal title="Create an automation" close={() => setCreating(false)}>
          <form className="modal-body form-grid" onSubmit={create}>
            <label className="span-2">
              Workflow name
              <input
                name="name"
                placeholder="Fresh air in the study"
                required
                maxLength={100}
              />
            </label>
            <label>
              Room
              <select name="room">
                {state.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Metric
              <select name="metric">
                {[
                  "co2",
                  "temperature",
                  "humidity",
                  "pm25",
                  "leak",
                  "energy",
                ].map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </label>
            <label>
              Condition
              <select name="operator">
                <option value="above">Above</option>
                <option value="below">Below</option>
              </select>
            </label>
            <label>
              Threshold
              <input
                name="threshold"
                type="number"
                min="0"
                max="10000"
                defaultValue="900"
                required
              />
            </label>
            <label>
              Trigger
              <select name="trigger">
                <option value="event">Telemetry event</option>
                <option value="interval">Interval schedule</option>
              </select>
            </label>
            <label>
              Interval (seconds)
              <input
                name="interval"
                type="number"
                min="30"
                max="86400"
                defaultValue="300"
                required
              />
            </label>
            <label>
              Priority (higher wins)
              <input
                name="priority"
                type="number"
                min="1"
                max="100"
                defaultValue="50"
                required
              />
            </label>
            <label>
              Steps
              <select value={steps} onChange={(e) => setSteps(+e.target.value)}>
                <option value="1">1 action</option>
                <option value="2">2 actions</option>
                <option value="3">3 actions</option>
              </select>
            </label>
            {Array.from({ length: steps }, (_, i) => (
              <React.Fragment key={i}>
                <label>
                  Action {i + 1} · Device
                  <select name={"device" + i}>
                    {state.devices
                      .filter((d) => d.adapter === "simulation")
                      .map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                  </select>
                </label>
                <label>
                  Target value
                  <input
                    name={"value" + i}
                    type="number"
                    min="0"
                    max="100"
                    defaultValue="50"
                    required
                  />
                </label>
              </React.Fragment>
            ))}
            <p className="form-hint span-2">
              Interval triggers also require the condition to hold. New rules
              start disabled. Automatic actions require autonomy to be enabled.
            </p>
            <button className="button primary span-2">
              <Plus size={16} />
              Create disabled rule
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}
