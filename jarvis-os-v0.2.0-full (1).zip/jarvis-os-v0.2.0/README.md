# JARVIS OS · Project Genesis

A new, independent, local-first estate intelligence platform with a persistent local core, a responsive command center, and a working simulated estate. **Version 0.2 adds persistent intelligence foundations; the estate remains simulated and is not a production controller or certified safety system.**

Iteration 2 extends this same repository. See [what changed and demonstrations](docs/iteration-2/README.md), [audit and baseline](docs/iteration-2/audit.md), [verification](docs/iteration-2/verification.md), and [review/upgrade instructions](docs/iteration-2/upgrade.md). The existing v0.1 service/database were left in place; the new release is staged for review, not deployed.

![Command center](docs/screenshots/overview-desktop.png)

## Run locally

Requirements: Python 3.12+, Node.js 22+ and npm. Tested with Python 3.12 and Node 24. Linux, macOS, and Windows through WSL are initial targets. Setup downloads open-source dependencies; normal mock-mode operation needs no internet or cloud credentials. For an existing v0.1 installation, review the upgrade guide before activating the new core.

```bash
cd /path/to/jarvis-os
./scripts/setup.sh
./scripts/run.sh
```

Open **http://127.0.0.1:8000**. Sign in as `admin`. After the first server startup, read the unique local administrator password in another terminal:

```bash
cat .runtime/admin-password
```

The password is never printed in server logs or committed. Alternatively, supply `JARVIS_ADMIN_PASSWORD` of at least 12 characters before startup. The core creates its SQLite database and seeded simulation automatically. Stop with Ctrl+C. Restart preserves data and invalidates browser sessions.

For frontend development, run the core on port 8000 and `npm --prefix web run dev` in another terminal, then open http://127.0.0.1:5173. Vite proxies `/api` to the core. The production command serves the staged `web/dist-next` frontend through the core. Builds preserve the legacy `web/dist` assets used by a separately running v0.1 process.

## What works

| Subsystem | First-release behavior |
| --- | --- |
| Command center | Fifteen responsive views, phone navigation, SVG charts, interactive floor plan, vertically resizable overview panels |
| Persistent core | FastAPI, validated requests, SQLite WAL, transactions, health and response-time instrumentation |
| Estate simulator | Six rooms, 120 sensor channels, 18 controllable devices, 3 protected interfaces, environmental/energy history and emergency scenarios |
| Local intelligence | Streaming mock, Ollama and OpenAI-compatible local text adapters; task routing, context bounds, health, deadlines/cancellation, explicit errors, provider-reported or labeled estimated tokens and latency |
| Conversation | Streaming, interrupt, persisted bounded history and deletion; no execution tools |
| Memory | Five categories; approved candidates, deduplication, contradiction checks, correction history, local embedding adapter, provenance, retrieval and retention |
| Automation | Event/interval conditions, multi-step rules, priorities, conflicts, manual overrides, dry-runs, history and guarded simulator rollback |
| Specialist workflows | Eleven registered roles; five bounded workflows with scoped delegation, shared context, timeline, human checkpoints, cancellation and safe restart recovery |
| Spatial/audio | Anonymous occupancy events, per-event replay, illustrative FOV, six persistent audio-zone/privacy simulations |
| Research | Manual/scheduled research plans, optional signed data-only gateway, labeled fixture references; no live web search |
| Robotics | Two simulated robots, destination missions, progress, battery/interlock/stop gates and twin synchronization |
| Development | Risk/component proposals and explicit plan review; no autonomous code execution or deployment |
| Governance/recovery | Single-admin authentication, CSRF, limits, audit chain, autonomy disable, simulator stop, read-only snapshots and verified restore |

Physical drivers, cameras, local STT/TTS, real embedding/model quality qualification, real 3D editing, live internet research, automatic code generation/deployment, and multi-user administration are **not implemented**. Their contracts, requirements and milestones are documented. The UI labels stored preferences and unavailable capabilities explicitly.

## Local model setup

Install Ollama independently, download an appropriate model, start its local service, then restart JARVIS with:

```bash
export JARVIS_MODEL_PROVIDER=ollama
export JARVIS_MODEL_URL=http://127.0.0.1:11434
export JARVIS_MODEL_CONVERSATION=llama3.2:3b
export JARVIS_MODEL_CODING=qwen2.5-coder:7b
export JARVIS_MODEL_VISION=llava:7b
./scripts/run.sh
```

For an OpenAI-compatible local server, select `openai-local` and a base URL such as `http://127.0.0.1:8080`; the adapter appends `/v1/chat/completions` and `/v1/models`. Only localhost/literal private addresses are accepted. Remote cloud endpoints are rejected. The vision route accepts text only today. No real model was available here; discovery/streaming/usage/recovery/cancellation protocols were tested with deterministic transports. Real-provider errors do not generate mock text. Administration supports discovery and persisted task-model selection. Saved configuration takes precedence over environment defaults. Set `JARVIS_EMBEDDING_MODEL` to a locally installed embedding model to enable real semantic vectors; otherwise retrieval is explicitly lexical.

## Separate external gateway

The core works without the gateway. To exercise it, provision a separate random `JARVIS_GATEWAY_KEY` of at least 32 characters in both processes, then run `./scripts/run-gateway.sh`. Configure `JARVIS_GATEWAY_URL=http://127.0.0.1:8100` on the core and restart it with the same gateway key.

Requests use HMAC signatures, freshness checks, nonces and a research-only schema. The gateway returns explicitly simulated references. It has no device-control route or core client. Actual domain isolation requires separate OS identities/hosts and network ACLs; see [security.md](docs/security.md) and the [Iteration 2 authorization review](docs/iteration-2/upgrade.md).

## Verify

```bash
.venv/bin/python -m pytest -q
npm --prefix web run build
cd web
npx playwright install chromium
npm run test:e2e
```

Browser tests use a temporary database, a test-only credential and loopback port 8001. They do not modify live runtime data. For full engineering checks, install `requirements-dev.txt` and run `./scripts/check.sh`. Executed results and limitations are in [Iteration 2 verification](docs/iteration-2/verification.md).

## Source and documentation

Python/FastAPI/Pydantic/httpx/SQLite core; React 19/TypeScript/Vite/Lucide UI. All fonts/assets are local or system-based. No paid service or proprietary infrastructure is required.

```text
core/          API, policy, migrations, memory/retrieval, providers, workflows, simulator
gateway/       separately run data-only external intelligence service
web/src/pages/ fifteen command-center views; shared components in ui.tsx
tests/         authorization, integration, failure and simulation tests
web/e2e/       real Chromium desktop/phone workflows
scripts/       setup, run, backup/restore, checks and benchmark
docs/          architecture, deployment, simulation, security, milestones
```

Implemented in phases: establish contracts/storage → connect simulator/control/memory/models → build command center/workflows → test boundaries, failures and browser interactions.

- [Architecture and system diagrams](docs/architecture.md)
- [Deployment and environment setup](docs/deployment.md)
- [Simulation walkthrough](docs/simulation.md)
- [Security limitations and recovery](docs/security.md)
- [Hardware roadmap and long-term milestones](docs/roadmap.md)
- [Executed verification](docs/test-results.md)

Keep certified alarms, shutoffs, emergency power and physical interlocks independent of this software. Hazardous equipment is interlocked in the prototype. Real actuators require hardware-specific safeguards and explicit authorization.
