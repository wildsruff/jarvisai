# JARVIS OS v0.2.0 — complete project package

This package contains the complete reviewed source at commit c80501464c517a06a1167bc145d597767350fc1e, the compiled command center, backend and gateway, tests, dependency manifests, architecture, setup/security/upgrade guides, screenshots, and actual verification evidence.

No local credentials, estate databases, model weights, installed dependencies or Git metadata are included. The estate operates in simulation. Real local model/embedding quality was not verified; deterministic protocol tests are included. See docs/iteration-2/verification.md (92 backend tests and six browser suites passed).

## Start with the bundled command center

Requires Python 3.12+; install the open-source Python dependencies once. Node is not required to serve the bundled UI.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./scripts/run.sh
```

Open http://127.0.0.1:8000. Sign in as admin with the unique password created in .runtime/admin-password. Read it locally in another terminal. For a different loopback port, set JARVIS_PORT and the matching JARVIS_ALLOWED_ORIGINS before starting.

For a full source rebuild, install Node.js 22+ and run ./scripts/setup.sh. That script installs dependencies and rebuilds web/dist-next. Local inference configuration and the optional separately deployed gateway are documented in README.md and docs/iteration-2/upgrade.md.

Before upgrading an existing installation, review docs/iteration-2/upgrade.md, stop the old service, and back up its database. This downloaded package does not activate or migrate the existing running service by itself.

## Verify and inspect

- README.md: source layout and setup.
- docs/iteration-2/README.md: architecture changes, functional demonstrations, limitations and Iteration 3 priorities.
- docs/iteration-2/final-checks.txt and final-browser.txt: executed checks.
- RELEASE_MANIFEST.json: per-file SHA-256 hashes, source commit and bundle contents.

The ZIP and TAR.GZ contain the same files. Use the separately supplied SHA256SUMS file to verify the downloaded archives.
