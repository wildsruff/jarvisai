import json
from datetime import datetime, timedelta, timezone
import httpx
import pytest
from core.contracts import Memory


def body(content, **kwargs):
    return Memory(kind="semantic", content=content, source="explicit test", **kwargs)


def test_chat_extracts_candidates_but_never_auto_establishes_facts(signed, app):
    response = signed.post(
        "/api/v1/chat", json={"message": "My preferred study temperature is 22 C."}
    )
    assert response.status_code == 200
    candidate = signed.get("/api/v1/memory-candidates").json()[0]
    assert candidate["status"] == "pending" and candidate["verified"] is False
    assert candidate["requires_approval"] and candidate["source"].startswith(
        "conversation:main:"
    )
    assert not any(
        "preferred study temperature" in m["content"] for m in app.state.memory.active()
    )
    approved = signed.post(
        f"/api/v1/memory-candidates/{candidate['id']}/review",
        json={"decision": "approve"},
    ).json()
    memory = app.state.store.get("memory", approved["memory_id"])
    assert memory["verified"] is False and memory["confidence"] == 0.65
    assert (
        signed.post(
            f"/api/v1/memory-candidates/{candidate['id']}/review",
            json={"decision": "approve"},
        ).status_code
        == 409
    )


def test_sensitive_review_rejection_credential_exclusion_and_optout(signed, app):
    candidates = app.state.memory.extract(
        "I have a medical allergy to peanuts.", "main", "m1"
    )
    assert candidates[0]["sensitive"] and candidates[0]["requires_approval"]
    assert not app.state.memory.extract(
        "My password is a-do-not-store-value.", "main", "m2"
    )
    rejected = signed.post(
        f"/api/v1/memory-candidates/{candidates[0]['id']}/review",
        json={"decision": "reject"},
    ).json()
    assert rejected["status"] == "rejected"
    settings = app.state.store.get("settings", "main")
    settings["extract_memories"] = False
    app.state.store.put("settings", settings)
    assert app.state.memory.extract("I prefer quiet mornings.", "main", "m3") == []


async def test_dedup_contradictions_revisions_and_retrieval(app):
    service = app.state.memory
    one = service.save(body("My preferred study temperature is 22 C."), "first")
    duplicate = service.save(
        body("MY preferred study temperature is 22 C!"), "duplicate"
    )
    assert duplicate["id"] == one["id"] and duplicate["deduplicated"]
    two = service.save(body("My preferred study temperature is 25 C."), "second")
    assert two["conflicts"] == ["first"]
    result = await service.retrieve("What temperature do I prefer in the office?")
    assert not any(m["id"] in ("first", "second") for m in result["memories"])
    service.save(body("My preferred bedroom temperature is 25 C."), "second")
    assert len(service.history("second")) == 2
    result = await service.retrieve("What temperature do I prefer in the office?")
    assert any(m["id"] == "first" for m in result["memories"])


async def test_expired_memories_cannot_leak_without_dashboard_polling(app):
    m = app.state.memory.save(body("I prefer quiet study sessions."), "expired")
    m["expires_at"] = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
    app.state.store.put("memory", m)
    assert not any(
        m["id"] == "expired"
        for m in (await app.state.memory.retrieve("quiet study"))["memories"]
    )


def test_chat_injects_only_approved_relevant_memories(signed, app, monkeypatch):
    m = app.state.memory.save(
        body("My preferred temperature is 22 C.", confidence=0.8), "approved"
    )
    app.state.memory.extract("My preferred temperature is 25 C.", "other", "m2")
    captured = []

    async def stream(messages, task):
        captured.extend(messages)
        yield {"type": "token", "text": "Acknowledged."}
        yield {
            "type": "done",
            "metrics": {
                "status": "completed",
                "provider": "test-local",
                "model": "test",
            },
        }

    monkeypatch.setattr(app.state.models, "stream", stream)
    response = signed.post(
        "/api/v1/chat", json={"message": "What is my preferred temperature?"}
    )
    assert response.status_code == 200
    assert m["content"] in captured[0]["content"]
    assert "25 C" not in captured[0]["content"]
    assistant = app.state.store.get("conversation", "main")["messages"][-1]
    assert assistant["retrieved_memory_ids"] == ["approved"]


async def test_real_embedding_adapter_with_test_vectors_and_cache(app, monkeypatch):
    service = app.state.memory
    service.models.provider = "ollama"
    monkeypatch.setenv("JARVIS_EMBEDDING_MODEL", "test-embedding")
    service.save(body("I prefer a quiet workspace."), "quiet")
    calls = []
    real = httpx.AsyncClient

    def handler(request):
        data = json.loads(request.content)
        calls.append(data)
        return httpx.Response(
            200,
            json={
                "embeddings": [
                    [1.0, 0.0] if "quiet" in text or "peaceful" in text else [0.0, 1.0]
                    for text in data["input"]
                ]
            },
        )

    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real(**kwargs, transport=httpx.MockTransport(handler)),
    )
    first = await service.retrieve("a peaceful room")
    assert (
        first["method"].startswith("ollama:") and first["memories"][0]["id"] == "quiet"
    )
    await service.retrieve("a peaceful room")
    assert len(calls) == 3  # query + batched memories, then cached memories + query
    service.delete("quiet")
    assert not service.history("quiet")
    assert not app.state.store.db.execute(
        "SELECT 1 FROM memory_vectors WHERE memory_id='quiet'"
    ).fetchone()


async def test_embedding_failure_is_explicit_lexical_fallback(app, monkeypatch):
    monkeypatch.setenv("JARVIS_EMBEDDING_MODEL", "missing")
    app.state.memory.save(body("I like the quiet study."), "quiet")
    result = await app.state.memory.retrieve("quiet office")
    assert (
        result["method"] == "lexical-concepts"
        and result["fallback_error"] == "ValueError"
    )
    assert result["memories"][0]["id"] == "quiet"


def test_deletion_removes_revisions_vectors_and_candidate_copy(signed, app):
    c = app.state.memory.extract("I prefer a quiet office.", "main", "m1")[0]
    approved = app.state.memory.review(c["id"], "approve")
    id = approved["memory_id"]
    app.state.memory.save(body("I prefer a quiet office in the morning."), id)
    assert len(signed.get(f"/api/v1/memories/{id}/history").json()) == 2
    assert signed.delete(f"/api/v1/memories/{id}").status_code == 200
    assert not app.state.memory.history(id)
    assert app.state.store.get("memory_candidate", c["id"]) is None


def test_versioned_export_includes_lineage_while_legacy_export_is_compatible(
    signed, app
):
    app.state.memory.save(body("I like a quiet office."), "lineage")
    export = signed.get("/api/v1/memories/export").json()
    assert (
        export["schema"] == 2
        and export["correction_history"]["lineage"][0]["revision"] == 1
    )
    legacy = signed.get("/api/memories/export").json()
    assert legacy["schema"] == 1 and set(legacy) == {
        "schema",
        "exported_at",
        "memories",
    }


@pytest.mark.parametrize("vector", [[0.0, 0.0], [1e-300, 0.0], [1e300, 1.0]])
async def test_unusable_embedding_vectors_are_rejected_without_nan_scores(
    app, monkeypatch, vector
):
    app.state.models.provider = "ollama"
    monkeypatch.setenv("JARVIS_EMBEDDING_MODEL", "invalid-vectors")
    real = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real(
            **kwargs,
            transport=httpx.MockTransport(
                lambda r: httpx.Response(200, json={"embeddings": [vector]})
            ),
        ),
    )
    result = await app.state.memory.retrieve("office")
    assert (
        result["method"] == "lexical-concepts"
        and result["fallback_error"] == "ValueError"
    )
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("action", ["delete", "expire"])
def test_memory_lifecycle_redacts_workflow_copies_and_prevents_resurrection(
    app, action
):
    service = app.state.memory
    memory = service.save(
        body("My private medical preference is confidential."), "private"
    )
    task = {
        "id": "snapshot-task",
        "context": {"outputs": {"memory": {"memories": [memory]}}},
        "steps": [{"output": {"memories": [memory]}}],
        "result": {"findings": [memory]},
    }
    app.state.store.put("task", task)
    if action == "delete":
        service.delete("private")
    else:
        memory = {
            **memory,
            "expires_at": (
                datetime.now(timezone.utc) - timedelta(seconds=1)
            ).isoformat(),
        }
        app.state.store.put("memory", memory)
        app.state.store.prune()
    saved = app.state.store.get("task", "snapshot-task")
    assert "confidential" not in json.dumps(saved)
    assert saved["result"]["findings"][0]["redacted"] is True
    # An in-flight worker holding an old snapshot cannot restore its contents.
    app.state.store.put("task", task)
    assert "confidential" not in json.dumps(
        app.state.store.get("task", "snapshot-task")
    )
