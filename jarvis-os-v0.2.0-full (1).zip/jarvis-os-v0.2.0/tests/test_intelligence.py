"""Local protocol tests: deterministic transports, not real model qualification."""

import asyncio
import json
import httpx
import pytest
from core.models import Models, bounded_context, interruptible
from core.personality import system_prompt, prepare_context


def local(app, monkeypatch, handler, provider="ollama", **options):
    monkeypatch.setenv("JARVIS_MODEL_PROVIDER", provider)
    real = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real(**kwargs, transport=httpx.MockTransport(handler)),
    )
    model = Models(app.state.store)
    model.configure({**model.config, **options}, persist=False)
    return model


@pytest.mark.parametrize("provider", ["ollama", "openai-local"])
async def test_discovery_and_reported_usage(app, monkeypatch, provider):
    seen = []

    def handler(request):
        if request.method == "GET":
            return httpx.Response(
                200,
                json={"models": [{"name": "local-a"}]}
                if provider == "ollama"
                else {"data": [{"id": "local-a"}]},
            )
        seen.append(json.loads(request.content))
        raw = (
            '{"message":{"content":"Measured reply"},"done":true,"prompt_eval_count":31,"eval_count":7}'
            if provider == "ollama"
            else 'data: {"choices":[{"delta":{"content":"Measured reply"},"finish_reason":"stop"}],"usage":{"prompt_tokens":31,"completion_tokens":7}}\n\ndata: [DONE]'
        )
        return httpx.Response(200, content=raw.encode())

    models = local(app, monkeypatch, handler, provider)
    assert (await models.discover())["models"][0]["id"] == "local-a"
    events = [
        e async for e in models.stream([{"role": "user", "content": "hello"}], "coding")
    ]
    metrics = events[-1]["metrics"]
    assert metrics["status"] == "completed" and metrics["provider"] == provider
    assert metrics["input_tokens"] == 31 and metrics["output_tokens"] == 7
    assert (
        metrics["token_counts"] == "provider-reported"
        and metrics["first_token_ms"] is not None
    )
    assert seen[0]["model"] == models.routes["coding"]


async def test_connect_retry_recovers_without_replaying_generated_output(
    app, monkeypatch
):
    requests = []

    def handler(request):
        requests.append(request)
        if len(requests) == 1:
            raise httpx.ConnectError("refused", request=request)
        return httpx.Response(
            200, content=b'{"message":{"content":"Recovered"},"done":true}\n'
        )

    model = local(app, monkeypatch, handler)
    events = [e async for e in model.stream([{"role": "user", "content": "hello"}])]
    assert len(requests) == 2
    assert any(e.get("state") == "reconnecting" for e in events)
    assert "".join(e.get("text", "") for e in events) == "Recovered"
    assert events[-1]["metrics"]["status"] == "completed"


@pytest.mark.parametrize(
    "raw,code",
    [
        (b"not-json\n", "model_protocol_error"),
        (b'{"message":{"content":"Partial"}}\n', "model_protocol_error"),
        (b'{"done":true}\n', "model_empty_response"),
        (
            b'{"message":{"content":"Bad usage"},"done":true,"eval_count":-1}\n',
            "model_protocol_error",
        ),
    ],
)
async def test_stream_failure_never_impersonates_a_working_model(
    app, monkeypatch, raw, code
):
    model = local(app, monkeypatch, lambda r: httpx.Response(200, content=raw))
    events = [e async for e in model.stream([{"role": "user", "content": "status"}])]
    metric = events[-1]["metrics"]
    assert metric["status"] == "failed" and metric["provider"] == "ollama"
    assert metric["error"]["code"] == code and metric["fallback"] is False
    assert "simulated estate" not in "".join(e.get("text", "") for e in events)


async def test_http_errors_are_sanitized_and_not_retried(app, monkeypatch):
    calls = []

    def handler(r):
        calls.append(r)
        return httpx.Response(404, text="private-server-token=secret")

    model = local(app, monkeypatch, handler)
    events = [e async for e in model.stream([{"role": "user", "content": "hello"}])]
    assert len(calls) == 1
    assert events[-1]["metrics"]["error"]["code"] == "model_not_found"
    assert "private-server-token" not in json.dumps(events)


class SlowStream(httpx.AsyncByteStream):
    def __init__(self, partial=True):
        self.closed = False
        self.partial = partial

    async def __aiter__(self):
        if self.partial:
            yield b'{"message":{"content":"First"}}\n'
        await asyncio.sleep(10)
        yield b'{"done":true}\n'

    async def aclose(self):
        self.closed = True


async def test_total_deadline_closes_remote_transport(app, monkeypatch):
    remote = SlowStream()
    model = local(
        app,
        monkeypatch,
        lambda r: httpx.Response(200, stream=remote),
        total_timeout=0.05,
    )
    events = await asyncio.wait_for(collect(model), 1)
    assert remote.closed
    assert events[-1]["metrics"]["status"] == "failed"
    assert events[-1]["metrics"]["error"]["code"] == "inference_timeout"


async def collect(model):
    return [e async for e in model.stream([{"role": "user", "content": "hello"}])]


async def test_cancellation_closes_socket_and_persists_cancelled_metrics(
    app, monkeypatch
):
    remote = SlowStream()
    model = local(app, monkeypatch, lambda r: httpx.Response(200, stream=remote))
    stream = model.stream([{"role": "user", "content": "hello"}])
    assert (await anext(stream))["type"] == "status"
    assert (await anext(stream))["text"] == "First"
    await asyncio.wait_for(stream.aclose(), 1)
    assert remote.closed
    assert app.state.store.latest("inference", 1)[0]["status"] == "cancelled"


def test_model_configuration_is_persistent_local_and_versioned(signed, app):
    info = signed.get("/api/v1/models").json()
    config = info["configuration"]
    config.pop("id")
    config["routes"]["coding"] = "selected-local-coder"
    config["context_chars"] = 4096
    assert signed.put("/api/v1/models/configuration", json=config).status_code == 200
    assert Models(app.state.store).routes["coding"] == "selected-local-coder"
    bad = {**config, "url": "http://169.254.169.254"}
    assert signed.put("/api/v1/models/configuration", json=bad).status_code == 422
    assert (
        signed.put(
            "/api/v1/models/configuration", json={**config, "routes": {"coding": "x"}}
        ).status_code
        == 422
    )
    assert signed.get("/api/v1/health").json()["version"] == "0.2.0"


def test_context_and_personality_preferences(app):
    bounded = bounded_context(
        [
            {"role": "system", "content": "policy" * 500},
            {"role": "user", "content": "latest" * 1000},
        ],
        2048,
    )
    assert (
        sum(len(m["content"]) for m in bounded) <= 2048
        and bounded[-1]["role"] == "user"
    )
    settings = {
        **app.state.store.get("settings", "main"),
        "humor": 70,
        "response_style": "concise",
        "personality": "warm",
    }
    prompt = system_prompt(settings, {"memories": []}, "coding")["content"]
    assert "70/100" in prompt and "concise" in prompt and "Warm" in prompt
    assert "no action tools" in prompt and "no jokes" in prompt
    compact = prepare_context(
        settings,
        {
            "memories": [
                {
                    "id": "long",
                    "content": "x" * 4000,
                    "source": "test",
                    "confidence": 0.6,
                    "verified": False,
                }
            ]
        },
        "coding",
        2048,
    )
    assert len(compact["message"]["content"]) <= 1024
    assert "no action tools" in compact["message"]["content"]
    assert (
        json.loads(compact["message"]["content"].split("Relevant memory data: ", 1)[1])
        == []
    )


async def test_cancel_interrupts_a_pending_token_read(app, monkeypatch):
    remote = SlowStream(partial=False)
    model = local(app, monkeypatch, lambda r: httpx.Response(200, stream=remote))
    cancel = asyncio.Event()
    stream = interruptible(model.stream([{"role": "user", "content": "hello"}]), cancel)
    assert (await anext(stream))["type"] == "status"
    pending = asyncio.create_task(anext(stream))
    await asyncio.sleep(0.01)
    cancel.set()
    with pytest.raises(StopAsyncIteration):
        await asyncio.wait_for(pending, 0.5)
    assert remote.closed
    assert app.state.store.latest("inference", 1)[0]["status"] == "cancelled"


async def test_discovery_does_not_attribute_old_server_health_to_new_configuration(
    app, monkeypatch
):
    started = asyncio.Event()
    release = asyncio.Event()

    async def handler(request):
        started.set()
        await release.wait()
        return httpx.Response(200, json={"models": [{"name": "old-server-model"}]})

    model = local(app, monkeypatch, handler)
    pending = asyncio.create_task(model.discover())
    await started.wait()
    model.configure(
        {**model.config, "provider": "openai-local", "url": "http://127.0.0.1:8080"},
        persist=False,
    )
    release.set()
    discovery = await pending
    assert discovery["provider"] == "ollama" and discovery["status"] == "online"
    assert model.last_health == {"provider": "openai-local", "status": "unchecked"}
