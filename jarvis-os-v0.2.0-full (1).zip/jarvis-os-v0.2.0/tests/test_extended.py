import asyncio
import contextlib
import json
import hashlib
from pathlib import Path
import httpx
import pytest
from core.models import Models, bounded_context
from core.workflows import Orchestrator, ExternalGateway
from gateway.app import create_gateway
from scripts.backup import backup, restore


def test_readonly_snapshot_restore_and_corruption_detection(app, tmp_path):
    source = Path(app.state.store.db.execute("PRAGMA database_list").fetchone()[2])
    snapshot = backup(source, tmp_path / "backups")
    assert snapshot.stat().st_mode & 0o222 == 0
    manifest = json.loads(snapshot.with_suffix(".json").read_text())
    assert manifest["sha256"] == hashlib.sha256(snapshot.read_bytes()).hexdigest()
    assert manifest["audit_head"] == app.state.store.logs(1)[0]["hash"]
    destination = tmp_path / "restored.db"
    restore(snapshot, destination)
    from core.storage import Store

    restored = Store(str(destination))
    assert len(restored.all("room")) == 6 and restored.verify_audit()
    restored.close()
    with pytest.raises(FileExistsError):
        restore(snapshot, destination)
    snapshot.chmod(0o600)
    snapshot.write_bytes(b"corrupt")
    with pytest.raises(ValueError, match="digest"):
        restore(snapshot, tmp_path / "bad.db")


async def test_worker_timeout_has_terminal_state(app):
    o = Orchestrator(app.state.store, Models(app.state.store))
    o.timeout_seconds = 0.01
    task = await o.submit({"workflow": "diagnostics"})
    worker = asyncio.create_task(o.worker())
    await asyncio.wait_for(o.queue.join(), 2)
    worker.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await worker
    assert app.state.store.get("task", task["id"])["state"] == "timed_out"
    assert all(a["status"] == "idle" for a in app.state.store.all("agent"))


@pytest.mark.parametrize("provider", ["ollama", "openai-local"])
async def test_real_adapter_protocols_with_mock_local_server(
    app, monkeypatch, provider
):
    monkeypatch.setenv("JARVIS_MODEL_PROVIDER", provider)
    real_client = httpx.AsyncClient
    seen = []

    def transport(request):
        seen.append(json.loads(request.content))
        if provider == "ollama":
            return httpx.Response(
                200, content=b'{"message":{"content":"Local reply"}}\n{"done":true}\n'
            )
        return httpx.Response(
            200,
            content=b'data: {"choices":[{"delta":{"content":"Local reply"}}]}\n\ndata: [DONE]\n\n',
        )

    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real_client(
            **kwargs, transport=httpx.MockTransport(transport)
        ),
    )
    events = [
        e
        async for e in Models(app.state.store).stream(
            [{"role": "user", "content": "hello"}], "coding"
        )
    ]
    assert next(e["text"] for e in events if e["type"] == "token") == "Local reply"
    assert events[-1]["metrics"]["status"] == "completed"
    assert events[-1]["metrics"]["fallback"] is False
    assert seen[0]["model"] == "qwen2.5-coder:7b" and seen[0]["stream"]


async def test_gateway_client_validates_and_persists_signed_result(app, monkeypatch):
    key = "separate-integration-test-gateway-key-123456"
    monkeypatch.setenv("JARVIS_GATEWAY_KEY", key)
    gateway = create_gateway(key)
    real_client = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real_client(
            **kwargs, transport=httpx.ASGITransport(app=gateway)
        ),
    )
    result = await ExternalGateway().research("Local sensors")
    assert result["mode"] == "simulated" and result["trust"] == "untrusted-data"
    # Prove URL objects are normalized to JSON before entering the core database.
    app.state.store.put("research", {"id": "signed-report", **result})
    assert app.state.store.get("research", "signed-report")["sources"][0][
        "url"
    ].startswith("https://")


async def test_gateway_client_refuses_tampered_response(monkeypatch):
    monkeypatch.setenv(
        "JARVIS_GATEWAY_KEY", "separate-integration-test-gateway-key-123456"
    )
    real_client = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda **kwargs: real_client(
            **kwargs,
            transport=httpx.MockTransport(
                lambda r: httpx.Response(
                    200, json={"command": "unlock"}, headers={"x-signature": "invalid"}
                )
            ),
        ),
    )
    with pytest.raises(ValueError, match="signature"):
        await ExternalGateway().research("hello")


def test_large_memory_context_stays_bounded():
    messages = [
        {"role": "system", "content": "x" * 20000},
        {"role": "user", "content": "latest question"},
    ]
    result = bounded_context(messages, 14000)
    assert sum(len(m["content"]) for m in result) <= 14000
    assert result[-1]["content"] == "latest question"


def test_network_outage_blocks_device_and_rule(signed, app):
    assert (
        signed.post(
            "/api/simulation/scenario", json={"kind": "network", "room_id": "office"}
        ).status_code
        == 200
    )
    assert (
        signed.post("/api/devices/office-light/command", json={"value": 10}).status_code
        == 409
    )
    assert app.state.store.get("sensor", "office-co2")["status"] == "offline"
    run = signed.post("/api/rules/fresh-air/run?dry_run=false").json()
    assert run["status"] == "blocked"
    signed.post("/api/simulation/scenario", json={"kind": "normal"})
    assert (
        signed.post("/api/devices/office-light/command", json={"value": 10}).status_code
        == 200
    )


def test_priority_reservations_persist_during_cooldown(signed, app):
    settings = signed.get("/api/state").json()["settings"]
    settings.pop("id")
    signed.put("/api/settings", json={**settings, "autonomous": True})
    common = {"room_id": "living", "metric": "co2", "threshold": 1, "enabled": True}
    signed.post(
        "/api/rules",
        json={
            **common,
            "name": "Low",
            "priority": 10,
            "actions": [{"device_id": "living-light", "value": 10}],
        },
    )
    signed.post(
        "/api/rules",
        json={
            **common,
            "name": "High",
            "priority": 90,
            "actions": [{"device_id": "living-light", "value": 90}],
        },
    )
    app.state.automation.evaluate()
    app.state.automation.evaluate()
    assert app.state.store.get("device", "living-light")["value"] == 90


def test_duplicate_target_and_driver_exception_are_atomic(signed, app, monkeypatch):
    body = {
        "name": "Atomic rule",
        "room_id": "living",
        "threshold": 1,
        "actions": [
            {"device_id": "living-light", "value": 10},
            {"device_id": "living-light", "value": 20},
        ],
    }
    assert signed.post("/api/rules", json=body).status_code == 422
    body["actions"][1]["device_id"] = "living-ventilation"
    rule = signed.post("/api/rules", json=body).json()
    original = app.state.store.put
    before = app.state.store.get("device", "living-light")["value"]

    def broken(kind, data):
        if kind == "device" and data["id"] == "living-ventilation":
            raise RuntimeError("Simulated driver/storage failure")
        return original(kind, data)

    monkeypatch.setattr(app.state.store, "put", broken)
    with pytest.raises(RuntimeError):
        app.state.automation.run(rule, False)
    assert app.state.store.get("device", "living-light")["value"] == before
