import pytest
from fastapi.testclient import TestClient
from core.app import create_app


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("JARVIS_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setenv("JARVIS_ADMIN_PASSWORD", "test-password-with-length")
    monkeypatch.setenv("JARVIS_MODEL_PROVIDER", "mock")
    monkeypatch.delenv("JARVIS_GATEWAY_KEY", raising=False)
    return create_app(str(tmp_path / "estate.db"), simulation=False)


@pytest.fixture
def client(app):
    with TestClient(app) as client:
        yield client


@pytest.fixture
def signed(client):
    response = client.post(
        "/api/login",
        json={"username": "admin", "password": "test-password-with-length"},
    )
    assert response.status_code == 200
    client.headers["x-csrf-token"] = response.json()["csrf"]
    return client
