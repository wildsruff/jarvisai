import asyncio
import contextlib
import time
import pytest
from fastapi import HTTPException
from core.models import Models
from core.workflows import Orchestrator


def settings(signed, autonomous=True):
    values = signed.get("/api/state").json()["settings"]
    values.pop("id")
    values["autonomous"] = autonomous
    return signed.put("/api/settings", json=values)


def test_automation_dry_run_execute_and_rollback(signed, app):
    before = app.state.store.get("device", "office-ventilation")["value"]
    run = signed.post("/api/rules/fresh-air/run").json()
    assert run["dry_run"] and run["status"] == "simulated"
    assert app.state.store.get("device", "office-ventilation")["value"] == before
    run = signed.post("/api/rules/fresh-air/run?dry_run=false").json()
    assert run["status"] == "completed"
    assert app.state.store.get("device", "office-ventilation")["value"] == 75
    assert (
        signed.post(f"/api/runs/{run['id']}/rollback").json()["status"] == "rolled_back"
    )
    assert app.state.store.get("device", "office-ventilation")["value"] == before
    assert signed.post(f"/api/runs/{run['id']}/rollback").status_code == 409


def test_automation_atomic_failure_and_hazardous_rule(signed, app):
    body = {
        "name": "Two-step rule",
        "room_id": "living",
        "metric": "co2",
        "threshold": 1,
        "actions": [
            {"device_id": "living-light", "value": 10},
            {"device_id": "living-ventilation", "value": 60},
        ],
    }
    rule = signed.post("/api/rules", json=body).json()
    settings(signed)
    # A manual override on the second device must leave the first untouched.
    signed.post("/api/devices/living-ventilation/command", json={"value": 25})
    before = app.state.store.get("device", "living-light")["value"]
    result = app.state.automation.run(rule, False, True)
    assert result["status"] == "blocked"
    assert app.state.store.get("device", "living-light")["value"] == before
    body["actions"] = [{"device_id": "pump", "value": 100}]
    assert signed.post("/api/rules", json=body).status_code == 403


def test_priority_conflicts_manual_overrides_and_autonomy(signed, app):
    assert settings(signed).status_code == 200
    common = {
        "room_id": "living",
        "metric": "co2",
        "threshold": 1,
        "enabled": True,
        "actions": [{"device_id": "living-light", "value": 10}],
    }
    low = signed.post(
        "/api/rules", json={**common, "name": "Low priority", "priority": 10}
    ).json()
    high = signed.post(
        "/api/rules",
        json={
            **common,
            "name": "High priority",
            "priority": 90,
            "actions": [{"device_id": "living-light", "value": 90}],
        },
    ).json()
    app.state.automation.evaluate()
    assert app.state.store.get("device", "living-light")["value"] == 90
    assert app.state.store.get("rule", low["id"])["last_run"] == 0
    signed.post("/api/devices/living-light/command", json={"value": 44})
    for id in (low["id"], high["id"]):
        rule = app.state.store.get("rule", id)
        rule["last_run"] = 0
        app.state.store.put("rule", rule)
    app.state.automation.evaluate()
    assert app.state.store.get("device", "living-light")["value"] == 44
    assert any(r["status"] == "blocked" for r in app.state.store.all("run"))
    settings(signed, False)
    d = app.state.store.get("device", "living-light")
    d["manual_until"] = 0
    app.state.store.put("device", d)
    with pytest.raises(HTTPException):
        app.state.control.check("living-light", 20, "automation", True)


def test_interval_schedule_does_not_run_early(signed, app):
    settings(signed)
    rule = app.state.store.get("rule", "evening-light")
    rule.update(enabled=True, last_run=time.time() - 61, interval_seconds=1800)
    app.state.store.put("rule", rule)
    before = len(app.state.store.all("run"))
    app.state.automation.evaluate()
    assert len(app.state.store.all("run")) == before
    rule["last_run"] = time.time() - 1801
    app.state.store.put("rule", rule)
    app.state.automation.evaluate()
    assert len(app.state.store.all("run")) == before + 1


def test_stale_rollback_never_overwrites_new_manual_value(signed):
    run = signed.post("/api/rules/fresh-air/run?dry_run=false").json()
    signed.post("/api/devices/office-ventilation/command", json={"value": 45})
    assert signed.post(f"/api/runs/{run['id']}/rollback").status_code == 409


def test_estate_review_and_research_workflows(signed, app):
    task = signed.post("/api/tasks", json={"workflow": "estate-review"}).json()
    # Execute in the TestClient event loop without timing sleeps.
    signed.portal.call(app.state.orchestrator.queue.join)
    record = app.state.store.get("task", task["id"])
    assert record["state"] == "completed"
    assert all(s["state"] == "completed" for s in record["steps"])
    assert record["result"]["proposals_only"] is True
    assert record["timeout_seconds"] == 30
    research = signed.post(
        "/api/tasks", json={"workflow": "research", "subject": "Indoor air filtration"}
    ).json()
    signed.portal.call(app.state.orchestrator.queue.join)
    report = app.state.store.all("research")[-1]
    assert report["mode"] == "offline" and report["sources"] == []
    assert report["trust"] == "untrusted-data"
    assert app.state.store.get("task", research["id"])["state"] == "completed"


def test_robot_mission_safety_and_completion(signed, app):
    request = {"workflow": "robot-mission", "robot_id": "rover", "room_id": "office"}
    assert signed.post("/api/tasks", json=request).status_code == 409
    settings(signed)
    task = signed.post("/api/tasks", json=request).json()
    signed.portal.call(app.state.orchestrator.queue.join)
    assert app.state.store.get("task", task["id"])["state"] == "completed"
    robot = app.state.store.get("robot", "rover")
    assert robot["room_id"] == "office" and robot["progress"] == 100
    assert robot["mission_id"] is None and robot["status"] == "idle"
    signed.post("/api/emergency-stop")
    settings(signed)
    assert signed.post("/api/tasks", json=request).status_code == 409
    assert signed.post("/api/robots/rover/reset").json()["estop"] is False


def test_cancel_task_releases_robot_and_mutes_audio(signed, app):
    settings(signed)
    task = signed.post(
        "/api/tasks",
        json={"workflow": "robot-mission", "robot_id": "rover", "room_id": "living"},
    ).json()
    assert signed.post("/api/tasks/" + task["id"] + "/cancel").status_code == 200
    signed.portal.call(app.state.orchestrator.queue.join)
    assert app.state.store.get("task", task["id"])["state"] == "cancelled"
    assert app.state.store.get("robot", "rover")["mission_id"] is None
    assert signed.post("/api/tasks/" + task["id"] + "/cancel").status_code == 409


async def test_queue_bounds_and_cancel_queued_task(app):
    o = Orchestrator(app.state.store, Models(app.state.store))
    for _ in range(50):
        await o.submit({"workflow": "diagnostics"})
    with pytest.raises(HTTPException) as exc:
        await o.submit({"workflow": "diagnostics"})
    assert exc.value.status_code == 429


async def test_worker_failure_is_recorded_and_next_job_runs(app):
    o = Orchestrator(app.state.store, Models(app.state.store))
    original = o.step

    async def failing(agent, task, results):
        if task["subject"] == "fail":
            raise RuntimeError("synthetic failure")
        return await original(agent, task, results)

    o.step = failing
    failed = await o.submit({"workflow": "diagnostics", "subject": "fail"})
    good = await o.submit({"workflow": "diagnostics", "subject": "good"})
    worker = asyncio.create_task(o.worker())
    await asyncio.wait_for(o.queue.join(), 5)
    worker.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await worker
    assert app.state.store.get("task", failed["id"])["state"] == "failed"
    assert app.state.store.get("task", good["id"])["state"] == "completed"


def test_research_schedule_toggle(signed):
    assert signed.put("/api/research/schedule", json={"enabled": True}).json()[
        "enabled"
    ]
    assert (
        signed.put("/api/research/schedule", json={"enabled": False}).json()["enabled"]
        is False
    )
