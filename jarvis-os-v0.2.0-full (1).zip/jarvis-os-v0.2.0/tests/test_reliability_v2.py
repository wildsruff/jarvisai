import asyncio
import contextlib
import sqlite3
from datetime import datetime, timedelta, timezone
import pytest
from fastapi import HTTPException
from core.models import Models
from core.storage import Store
from core.memory import MemoryService
from core.workflows import Orchestrator


def test_versioned_errors_preserve_compatibility_and_redact_secrets(signed):
    old = signed.get("/api/health")
    new = signed.get("/api/v1/health")
    assert old.json() == new.json() and old.headers["deprecation"] == "true"
    assert new.headers["x-api-version"] == "1" and new.headers["x-request-id"]
    invalid = signed.post(
        "/api/v1/login", json={"username": "admin", "password": "private" * 100}
    )
    assert invalid.status_code == 422
    assert invalid.json()["error"]["code"] == "invalid_input"
    assert "private" not in invalid.text
    assert invalid.json()["error"]["fields"][0]["location"] == ["body", "password"]


def test_viewer_cannot_read_private_context_or_expand_agent_privileges(signed, app):
    token = signed.cookies.get("jarvis_session")
    app.state.auth.sessions[token]["role"] = "viewer"
    state = signed.get("/api/v1/state").json()
    assert state["memories"] == [] and state["tasks"] == [] and state["audit"] == []
    assert signed.get("/api/v1/conversation/main").status_code == 403
    assert signed.get("/api/v1/memory-candidates").status_code == 403
    assert signed.get("/api/v1/models").status_code == 403
    assert (
        signed.post("/api/v1/tasks", json={"workflow": "comfort-plan"}).status_code
        == 403
    )
    assert (
        signed.post(
            "/api/v1/devices/living-light/command", json={"value": 10}
        ).status_code
        == 403
    )


def test_cooperating_agents_approval_checkpoint_and_verifiable_outputs(signed, app):
    before = app.state.store.all("device")
    task = signed.post(
        "/api/v1/tasks",
        json={
            "workflow": "comfort-plan",
            "subject": "Prepare a ventilation routine for the study",
            "room_id": "office",
        },
    ).json()
    signed.portal.call(app.state.orchestrator.queue.join)
    waiting = signed.get("/api/v1/tasks/" + task["id"]).json()
    assert waiting["state"] == "awaiting_approval"
    assert len(waiting["plan"]) == 6
    assert waiting["steps"][2]["delegated_by"] == "planner"
    assert waiting["context"]["draft_rule"]["room_id"] == "office"
    evidence = waiting["context"]["outputs"]["environment"]["evidence"]
    assert (
        evidence["id"] == "office-co2"
        and evidence["value"] == app.state.store.get("sensor", "office-co2")["value"]
    )
    assert not app.state.store.get("rule", "task-" + task["id"])
    assert app.state.store.all("device") == before
    assert (
        signed.post(
            "/api/v1/tasks/" + task["id"] + "/review", json={"decision": "approve"}
        ).status_code
        == 200
    )
    signed.portal.call(app.state.orchestrator.queue.join)
    completed = app.state.store.get("task", task["id"])
    assert (
        completed["state"] == "completed" and completed["result"]["device_actions"] == 0
    )
    assert (
        app.state.store.get("rule", completed["result"]["rule_id"])["enabled"] is False
    )
    assert any(e["event"] == "approval_required" for e in completed["timeline"])
    assert app.state.store.all("device") == before
    assert (
        signed.post(
            "/api/v1/tasks/" + task["id"] + "/review", json={"decision": "approve"}
        ).status_code
        == 409
    )


def test_reject_and_cancel_waiting_checkpoints(signed, app):
    for decision in ("reject", "cancel"):
        task = signed.post("/api/v1/tasks", json={"workflow": "comfort-plan"}).json()
        signed.portal.call(app.state.orchestrator.queue.join)
        path = f"/api/v1/tasks/{task['id']}/" + (
            "review" if decision == "reject" else "cancel"
        )
        assert (
            signed.post(
                path, json={"decision": "reject"} if decision == "reject" else None
            ).status_code
            == 200
        )
        assert app.state.store.get("task", task["id"])["state"] == (
            "rejected" if decision == "reject" else "cancelled"
        )
        assert not app.state.store.get("rule", "task-" + task["id"])


async def test_delegation_and_approval_permissions_cannot_be_promoted(app):
    o = app.state.orchestrator
    for role in ("viewer", "research", "planner", "memory", "automation"):
        with pytest.raises(HTTPException):
            await o.submit({"workflow": "comfort-plan"}, actor="scheduler", role=role)
    task = await o.submit({"workflow": "comfort-plan"})
    task["steps"][2]["delegated_by"] = "research"
    with pytest.raises(HTTPException):
        await o.step("memory", task, [])
    with pytest.raises(HTTPException):
        o.review(task["id"], "approve", role="automation")
    with pytest.raises(HTTPException):
        await o.submit(
            {"workflow": "robot-mission"}, actor="scheduler", role="scheduler"
        )


async def test_restart_preserves_shared_context_and_resumes_only_unfinished_safe_stages(
    app,
):
    o = app.state.orchestrator
    reached = asyncio.Event()
    original = o.step

    async def slow(agent, task, results):
        if agent == "environment":
            reached.set()
            await asyncio.sleep(20)
        return await original(agent, task, results)

    o.step = slow
    task = await o.submit({"workflow": "comfort-plan", "subject": "Office ventilation"})
    worker = asyncio.create_task(o.worker())
    await asyncio.wait_for(reached.wait(), 2)
    worker.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await worker
    path = app.state.store.db.execute("PRAGMA database_list").fetchone()[2]
    retained = app.state.store.get("task", task["id"])
    assert retained["state"] == "interrupted"
    assert retained["steps"][2]["state"] == "completed"
    runs = app.state.store.get("agent", "memory")["runs"]
    app.state.store.close()
    reopened = Store(path)
    recovered = Orchestrator(reopened, Models(reopened))
    recovered.recover()
    recovered.resume(task["id"])
    worker = asyncio.create_task(recovered.worker())
    await asyncio.wait_for(recovered.queue.join(), 3)
    worker.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await worker
    record = reopened.get("task", task["id"])
    assert record["state"] == "awaiting_approval"
    assert reopened.get("agent", "memory")["runs"] == runs
    assert (
        record["context"]["outputs"]["monitor"]
        == retained["context"]["outputs"]["monitor"]
    )
    assert any(e["event"] == "resumed" for e in record["timeline"])
    reopened.close()


def test_migrations_preserve_legacy_rows_and_reject_future_versions(tmp_path):
    path = str(tmp_path / "legacy.db")
    with sqlite3.connect(path) as db:
        db.execute(
            "CREATE TABLE entities(kind TEXT,id TEXT,data TEXT,PRIMARY KEY(kind,id))"
        )
        db.execute(
            "INSERT INTO entities VALUES(?,?,?)",
            ("legacy", "one", '{"id":"one","content":"preserved"}'),
        )
    store = Store(path)
    assert store.get("legacy", "one")["content"] == "preserved"
    assert store.db.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0] == 2
    store.db.execute("INSERT INTO schema_migrations VALUES(99,'future')")
    store.close()
    with pytest.raises(RuntimeError, match="newer"):
        Store(path)


async def test_memory_and_configuration_survive_database_reopen(app):
    memory = app.state.memory
    candidate = memory.extract("I prefer a quiet workspace.", "main", "m1")[0]
    approved = memory.review(candidate["id"], "approve")
    model = app.state.models
    model.configure({**model.config, "context_chars": 8192})
    path = app.state.store.db.execute("PRAGMA database_list").fetchone()[2]
    app.state.store.close()
    reopened = Store(path)
    models = Models(reopened)
    service = MemoryService(reopened, models)
    assert models.config["context_chars"] == 8192
    assert reopened.get("memory_candidate", candidate["id"])["status"] == "approved"
    assert any(
        m["id"] == approved["memory_id"]
        for m in (await service.retrieve("quiet office"))["memories"]
    )
    assert len(service.history(approved["memory_id"])) == 1
    reopened.close()


def test_trends_have_real_evidence_cooldown_and_offline_gates(app):
    store = app.state.store
    store.db.execute("DELETE FROM readings WHERE room='office' AND metric='co2'")
    for index, value in enumerate([800, 900, 1000, 1100]):
        timestamp = (
            datetime.now(timezone.utc) - timedelta(seconds=(3 - index) * 30)
        ).isoformat()
        store.reading("office", "co2", value, timestamp)
    suggestions = app.state.proactive.evaluate()
    target = next(
        s for s in suggestions if s["room_id"] == "office" and s["metric"] == "co2"
    )
    assert (
        target["evidence"]["delta"] == 300 and target["evidence"]["sample_count"] == 4
    )
    assert target["evidence"]["source"] == "simulated"
    assert not app.state.proactive.evaluate()
    sensor = store.get("sensor", "office-co2")
    sensor["status"] = "offline"
    store.put("sensor", sensor)
    store.delete("suggestion", target["id"])
    assert not any(
        s["room_id"] == "office" and s["metric"] == "co2"
        for s in app.state.proactive.evaluate()
    )


def test_rollback_refuses_aba_change_and_full_integrity_remains_available(signed, app):
    run = signed.post("/api/v1/rules/fresh-air/run?dry_run=false").json()
    signed.post("/api/v1/devices/office-ventilation/command", json={"value": 30})
    signed.post("/api/v1/devices/office-ventilation/command", json={"value": 75})
    assert signed.post("/api/v1/runs/" + run["id"] + "/rollback").status_code == 409
    assert app.state.store.verify_audit()
    app.state.store.db.execute("UPDATE audit SET actor='tampered' WHERE seq=1")
    assert signed.get("/api/v1/diagnostics").json()["audit_integrity"] is False
