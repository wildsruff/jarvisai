# Current architecture

Iteration 2 extends this foundation; see [current architecture and implementation](iteration-2/README.md) and [migration/authorization changes](iteration-2/upgrade.md). The v0.1 description below is retained as the original design record. New behavior supersedes its fallback, memory, workflow recovery and unversioned-API descriptions.

# System architecture · Genesis 0.1

JARVIS OS is a new application in this repository. It does not depend on an existing Jarvis codebase. The first release implements an end-to-end simulation, with an architecture that can be incrementally separated into services. It is not a replacement operating-system kernel.

## Domains and trust

```mermaid
flowchart LR
  U[Authenticated operator] --> UI[React command center]
  subgraph A[Domain A · Local core · no internet required]
    API[FastAPI API / session + CSRF] --> Policy[Authorization and control policy]
    API --> Chat[Conversation / bounded context]
    Chat --> Models[Mock / Ollama / OpenAI local]
    API --> Queue[Bounded workflow queue]
    Queue --> Handlers[Registered specialist handlers]
    Handlers --> Read[Memory / telemetry / recommendations]
    Policy --> Sim[Simulation controls / rules / robots / audio]
    API --> DB[(SQLite WAL)]
    Sim --> DB
    Handlers --> DB
    Read --> DB
    DB --> Audit[SHA-256 linked audit ledger]
    Handlers --> Client[Data-only gateway client]
  end
  subgraph B[Domain B · Separately deployed gateway]
    G[HMAC / timestamp / nonce / strict schema] --> Research[Curated research fixture]
    Research -. future .-> Web[Approved web providers]
  end
  Client <-- authenticated data --> G
```

There is no incoming gateway command endpoint on the core. Domain B has no core session credentials, device-control client, or execution route. Its key authenticates research envelopes only. Retrieved data remains untrusted even after its signature is verified. Model output is rendered as plain text, never parsed into commands. This removes the model-to-actuator path from the prototype.

The services are separate processes, not a tested hardened isolation boundary. Production requires separate operating-system identities, hosts or sandboxes, network ACLs, TLS, and independently enforced hardware authority. Running both services under the same privileged user does not isolate them.

## Core modules

| Module | Implemented responsibility |
| --- | --- |
| `core/app.py` | Versioned application, HTTP contracts, session/CSRF checks, body/origin/host limits, lifecycle, UI assets, typed endpoints |
| `core/security.py` | Scrypt password verification, random sessions, permission matrix, login/API limits, hazardous equipment restrictions |
| `core/storage.py` | SQLite WAL repository, atomic transactions, readings, retention, linked audit events |
| `core/models.py` | Local endpoint validation, task routing, bounded context, streaming parsing, health, mock fallback, estimated usage and latency |
| `core/simulation.py` | Six-room estate, 120 sensor channels, device policy, automation scheduling/conflicts/rollback, environmental recommendations, scenarios |
| `core/workflows.py` | Bounded queue, registered steps, cancellation, timeouts, failure states, simulated navigation, signed research client |
| `core/contracts.py` | Strict Pydantic request schemas, extra fields denied, numeric bounds |
| `core/interfaces.py` | Future typed telemetry, device, speech and robotics contracts; no physical drivers |
| `gateway/` | Separate data-only service, strict response contract, replay resistance, explicitly simulated research |
| `web/src/pages/` | Fifteen functional command-center views, shared components in `ui.tsx`, authenticated API client in `api.ts` |

## Data and memory

SQLite uses three primary stores: JSON entities keyed by kind/ID, indexed timestamped sensor readings, and an ordered audit ledger. This is a single-node schema at version 1. Tables are created idempotently; subsequent releases need explicit migrations. Do not run multiple core workers: sessions, the queue, cancellation state, and simulation clocks are process-local.

Five memory kinds are independently inspectable: working, episodic, semantic, spatial, and procedural. All records carry provenance, confidence, verification, creation/update time, and expiration. Explicit operator entry is required. Lexical retrieval preserves uncertainty and selects a small context subset; no embeddings or inference-to-fact conversion are performed. Conversation history is separate working context, capped at 40 messages per conversation. Clearing it deletes live history. Audit entries omit message and memory contents, but chat/inference records still contain sensitive local data.

Sensor readings are sampled every six seconds and retained for seven days. Seeded trends contain 30 minutes of synthetic history. The simulator clock advances every two seconds. Entity history and audit logs currently require operator-managed archival; only sensor readings and expired memories have automatic pruning. This matters for long-running installations.

## Agent execution

```mermaid
stateDiagram-v2
  [*] --> queued
  queued --> running
  queued --> cancelled
  queued --> interrupted: service restart
  running --> completed
  running --> failed
  running --> timed_out: 30 seconds
  running --> cancelled: operator / stop
  running --> interrupted: shutdown / restart
```

The queue holds at most 50 tasks, with one worker. Four workflows are implemented: estate review, diagnostics, research, and robot navigation simulation. Eleven specialists are registered. They are bounded handler roles, not eleven unconstrained chatbots. Each step records timestamps, states, output, and an audit entry. The software-development specialist currently corresponds to the proposal interface; it cannot generate or execute filesystem changes. No runtime shell tool, arbitrary Python evaluation, dynamically downloaded agent, or model-authored workflow step exists.

## Automations and control

Rules have a room/metric condition, an event or interval trigger, up to eight actions, priority, enable flag, and cooldown. Matching high-priority rules reserve overlapping devices before lower-priority rules. Manual commands hold a five-minute override against automatic rules. Autonomy starts disabled; disabling it cancels robot missions. Dry-runs validate and record the proposed transitions without changing devices.

Simulated multi-step changes, execution records and audit events commit in one SQLite transaction. Rollback refuses to overwrite a device whose value changed since the run. This is only a simulator rollback guarantee: irreversible physical actions require driver-specific compensation, state versions, idempotency, acknowledgements, and safety review.

Locks, suppression and generators are always rejected. Only the simulation adapter is allowed. Robot missions check battery, autonomy, stop state, destination and simulated interlock. The simulator stop cancels work, disables autonomy, stops simulated robots, and mutes simulated audio. It is not a physical emergency-stop system.

## Model and audio boundaries

The local adapters implement Ollama NDJSON and OpenAI-compatible SSE text streaming. Model selection is explicit by conversation/coding/vision task. The vision route currently accepts text only. Context is limited by a character budget; token figures are estimates, not provider billing counters. Real model quality, GPU performance and actual model context capacities have not been verified here. Local failure uses a labeled deterministic mock; it never silently switches to a cloud provider.

Audio-zone volume, playback routing and microphone modes are persistent simulation controls. Always-listening requires the operator to release simulated hardware mute and explicitly select that mode. No microphone is opened and no audio is recorded or synthesized. Wake word, VAD, AEC, real hardware mute, local STT/TTS, room handoff and synchronized multi-speaker playback are interface/roadmap work.

## Release phases

The architecture covers the full requested platform; implementation depth is concentrated in the local simulator, governance and command center. Hardware integration, deep multimodal intelligence, 3D world editing, isolated software generation/deployment, autonomous research providers and multi-user administration are not represented as completed features. See [roadmap.md](roadmap.md) for verifiable next milestones.
