# Iteration 2 activation

Read [review and upgrade](iteration-2/upgrade.md) before activation. New builds stage in `web/dist-next` and do not replace v0.1 assets. `JARVIS_WEB_ASSETS` can select an approved static build directory. Persisted inference configuration takes precedence over environment model defaults after administrator selection. Canonical APIs use `/api/v1`; legacy routes remain compatible.

# Portable local deployment

## Baseline and setup

Use Python 3.12+, Node 22+, and storage for sensor history. Mock mode needs no GPU; real-model requirements depend on model size and RAM/VRAM. Run `scripts/setup.sh` and `scripts/run.sh` as documented in the README. Setup requires dependency downloads; built mock operation is offline.

The topology is one uvicorn process serving API and built UI on loopback port 8000. **Do not run multiple workers:** sessions, queues and the simulator clock are process-local. Runtime data is created automatically. Keep `.runtime` private and out of source control, public shares and unapproved cloud synchronization. Use a dedicated unprivileged service user and a restrictive umask such as `077`.

## Configuration

Environment variables are read directly. `.env` files are not loaded automatically; provision secrets through your OS/service manager.

| Variable | Default | Purpose |
| --- | --- | --- |
| `JARVIS_RUNTIME` | repository `.runtime` | Data/password location |
| `JARVIS_ADMIN_PASSWORD` | unique generated secret | Optional password; minimum 12 characters |
| `JARVIS_BIND` / `JARVIS_PORT` | `127.0.0.1` / `8000` | run.sh bind/port |
| `JARVIS_ALLOWED_HOSTS` | `127.0.0.1,localhost,testserver` | Comma-separated permitted HTTP hosts |
| `JARVIS_ALLOWED_ORIGINS` | localhost/127.0.0.1 ports 8000/5173 and test origin | Exact browser origins, no trailing slash |
| `JARVIS_SECURE_COOKIE` | unset | Set `1` when using HTTPS |
| `JARVIS_MODEL_PROVIDER` | `mock` | `mock`, `ollama`, `openai-local` |
| `JARVIS_MODEL_URL` | `http://127.0.0.1:11434` | Local inference base URL |
| `JARVIS_MODEL_CONVERSATION` | `llama3.2:3b` | Conversation route |
| `JARVIS_MODEL_CODING` | `qwen2.5-coder:7b` | Coding route |
| `JARVIS_MODEL_VISION` | `llava:7b` | Vision model route; text only today |
| `JARVIS_GATEWAY_URL` | `http://127.0.0.1:8100` | Optional private gateway |
| `JARVIS_GATEWAY_KEY` | unset | Separate HMAC secret; minimum 32 characters on gateway |

For frontend development, run `npm --prefix web run dev` alongside the core and open http://127.0.0.1:5173. Production uses the staged `web/dist-next`, without a Vite daemon. If that directory is absent, the backend API still runs; build the UI and restart to serve it.

## Private LAN access

Use a private TLS reverse proxy under your control, with API and UI on the same origin. Disable buffering for `/api/chat` to stream tokens. Preserve `Host`/`Origin`, set explicit allowed values and secure cookies. Do not enable wildcard CORS or directly expose the development server.

For a private proxy at `https://jarvis.home.arpa`:

```bash
export JARVIS_ALLOWED_HOSTS=jarvis.home.arpa,127.0.0.1,localhost
export JARVIS_ALLOWED_ORIGINS=https://jarvis.home.arpa
export JARVIS_SECURE_COOKIE=1
./scripts/run.sh
```

No TLS proxy, certificates, public DNS or firewall were installed here. Login limiting sees the direct peer address: a proxy shares that bucket across clients. Implement per-client limits at the trusted proxy rather than accepting untrusted forwarding headers.

## Domain separation

Run Domain B with `scripts/run-gateway.sh` after provisioning its separate key in both service environments. Keep the core password and database entirely out of the gateway. The fixture needs no outbound internet. Future providers need an outbound destination allowlist and no access to core/device networks. HMAC authenticates but does not encrypt reports: use TLS or a private tunnel across untrusted links.

For real deployment, use different OS identities/hosts and enforce network ACLs. Keep source/assets read-only and grant the core writes only to its runtime directory. Apply resource limits, `NoNewPrivileges`, restricted filesystem access and private temporary storage through your service manager. Never expose a Docker socket or host root to an agent runner. Container deployment is not included or tested in this release.

## Backup and recovery

```bash
.venv/bin/python scripts/backup.py backup .runtime/jarvis.db .runtime/backups
```

This uses SQLite's online backup API, verifies integrity, records SHA-256 plus the audit head, refuses to overwrite existing content and creates read-only artifacts. Copy the snapshot and manifest to independent offline/WORM storage for true host-administrator-resistant immutability. Local file permissions alone do not provide it.

Stop the core before restoring. Restore requires a new destination:

```bash
.venv/bin/python scripts/backup.py restore /path/to/snapshot.sqlite3 /path/to/new-runtime/jarvis.db
```

Protect the destination directory and supply/rotate credentials as appropriate. Verify the audit head against an independently trusted manifest. Point `JARVIS_RUNTIME` at the new directory and review restored autonomy and rule settings before running. Snapshots may contain enabled rules; restore is not a safety reset. See [security.md](security.md) for credential recovery.

## Supervised software changes

Write/review a proposal → create a separate Git branch/worktree → edit and run checks in an isolated environment → review diff, risks and backup → obtain explicit deployment approval → deploy through a separate authorized identity → verify health → revert the release/restore a verified snapshot if necessary. Approval policies and hardware safeguards remain outside any generated-code runner. The application has no deployment or source-editing endpoint.
