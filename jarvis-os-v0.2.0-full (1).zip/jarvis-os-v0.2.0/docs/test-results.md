# Historical v0.1 verification

For current results, see [Iteration 2 verification](iteration-2/verification.md). The original executed evidence is preserved below.

# Executed verification · 2026-11-01

These checks were executed in the development workspace, using Python 3.12.14 and Node 24.19.0 on Linux. They verify a simulation prototype, not physical estate hardware or production security.

| Check | Executed result |
| --- | --- |
| `python -m pytest -q` | **54 passed**; final full check run 10.42 seconds |
| TypeScript strict compile + Vite production build | **Passed**; 1,595 modules transformed |
| Chromium Playwright suites | **4 passed**, final run 9.4 seconds |
| Ruff static checks and Python format checks | **Passed** |
| Bandit scan of core, gateway and scripts | **No unsuppressed findings**; two narrowly reviewed simulation/test exclusions |
| `pip-audit -r requirements.txt` | **No known vulnerabilities** in the resolved runtime/test requirement set |
| `npm audit` | **0 vulnerabilities** in the frontend lockfile at scan time |
| Database snapshot/restore verification | Covered by the passing backend suite: integrity, digest, audit head, no overwrite, corruption rejection |
| API latency sample | 40 in-process `/api/state` requests: median **4.89 ms**, p95 **19.25 ms**, maximum **21.39 ms** |

The latency sample uses the seeded six-room/120-channel estate in FastAPI TestClient. It includes no network hop, real model or physical device. It is a basic instrumentation sample, not a capacity or deployment benchmark. Raw numbers are in [performance.json](performance.json); rerun with `python scripts/benchmark.py`.

## Backend coverage

- Authentication, eight-attempt login limiting, session cookie attributes, logout, authorization by role, CSRF, host/origin enforcement, payload caps and extra-field rejection.
- Mandatory hazardous-equipment interlocks, device bounds, missing/offline devices, manual overrides, availability/recovery scenarios and non-finite input rejection.
- Memory creation, provenance, uncertain versus verified data, correction, lexical search, export, deletion and expiration.
- Mock streaming chat, persistent conversation history/deletion, refusal to execute injected device requests, context bounds, estimated metrics and local-model failure fallback.
- Ollama NDJSON and OpenAI-compatible SSE protocol parsing against test transports. These are protocol tests, not real model inference qualification.
- Sensor histories, anonymous occupancy with null identity, simulated CO alerts, acknowledgement/resolution and microphone/hardware-mute consistency.
- Automation dry-run/execution/rollback, multi-step atomic failure, protected targets, duplicate-target rejection, scheduling, stale rollback refusal and priority reservations across cooldown ticks.
- Bounded queue, observable estate-review/research steps, workflow failures with worker recovery, cancellation, task timeouts, robot mission progress/completion and emergency-stop gates.
- Gateway HMAC authentication, signed responses, stale/replayed request refusal, strict research-only schemas, untrusted-content labeling, JSON normalization, tampered-response refusal and absence of control routes.
- Audit tamper detection, durable database reopening, transaction rollback, proposal approval/rejection, protected proposals and absence of deployment endpoints.
- Content-addressed snapshots, digest/integrity verification, audit-head manifests, read-only copies, restore to new paths and corruption/no-overwrite checks.

## Browser coverage

Real headless Chromium rendered all fifteen views without page errors. The suite exercised streamed chat, memory creation/correction/verification/deletion, an automation dry-run, a manual device change, anonymous occupancy, a smoke alert and reset, offline research, and proposal plan approval. The phone suite verified navigation and no horizontal overflow at 390px. Screenshots are in [screenshots/](screenshots/).

The suite uses an ephemeral loopback server and disposable credentials. It does not use the operator's live runtime directory. Device missions and stop behavior are verified through backend integration tests; physical navigation/audio are not tested.

## Findings fixed during implementation

A planner result referenced its own mutable findings list; it now snapshots prior results. Signed gateway URL fields are serialized before persistence. Automation priority reservations now survive cooldowns, and duplicate target actions are rejected. Offline devices block control and rules. A chat scroll effect now returns no cleanup value. Navigation has explicit accessible names. Browser tests use accessible textbox roles and a fresh database to avoid persisted-value interference.

The initial dependency scan identified outdated Starlette/pytest versions. They were upgraded and rescanned; the final dependency reports have no findings. Bandit's two reviewed exclusions are non-security pseudo-random sensor noise (`B311`) and an isolated loopback-only test password (`B106`), each annotated at the relevant line. [security-scan.json](security-scan.json), [python-dependency-audit.json](python-dependency-audit.json), and [frontend-dependency-audit.json](frontend-dependency-audit.json) preserve scan evidence.

## Limits and warnings

Pytest reports two upstream deprecation warnings: Starlette's transitional httpx TestClient support and an AnyIO BlockingPortal alias. Tests pass; neither warning is hidden. Playwright reports an environment `NO_COLOR`/`FORCE_COLOR` warning with no test impact.

Not executed: real Ollama/other model inference, GPU qualification, microphone/speaker capture, STT/TTS, real home/robotics protocols, physical interlocks or safety equipment, live web research, TLS/proxy provisioning, multi-user flows, container deployment, long-duration soak/load testing, independent penetration testing, or actual code deployment/rollback. The included CI workflow has not been run on a remote CI service. See [security.md](security.md) and [roadmap.md](roadmap.md) before connecting hardware.
