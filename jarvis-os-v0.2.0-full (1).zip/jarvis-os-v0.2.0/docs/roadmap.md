# Iteration 2 status

The candidate/revision/retrieval foundation, model lifecycle, scoped workflows, approval checkpoints and trend advice are implemented. Real inference/embedding qualification remains unverified. See [Iteration 3 priorities](iteration-2/README.md#limits-and-iteration-3-priorities). The original long-term hardware milestones remain below.

# Hardware integration and development milestones

Each milestone requires acceptance evidence before presenting the capability as operational.

| Phase | Deliverable | Acceptance gate |
| --- | --- | --- |
| 0.1 · Genesis | Persistent local simulator, command center, controlled automation, memory, workflows and proposals | Backend authorization/failure tests, browser workflows, production UI build |
| 0.2 · Intelligence | Real-model qualification, complexity routing, measured context budgets, per-user consent, vector retrieval and correction lineage | Offline evaluation corpus, uncertainty and context-overflow checks, latency targets on owned hardware |
| 0.3 · Speech | Local STT/TTS, VAD, wake word, echo cancellation, push-to-talk and interruption | Capture consent, physical mute/LED feedback, retention policy, real-room false-wake and echo tests |
| 0.4 · Connectivity | Read-only MQTT/Home Assistant, then noncritical device writes | Enrollment/revocation, scoped capabilities, ACLs, stale/replay/disconnect tests, manual overrides |
| 0.5 · Spatial | Editable buildings, floors, outdoors, furniture and calibrated sensors; 3D renderer | Coordinate migrations, uncertainty overlays, anonymous snapshot replay and calibration validation |
| 0.6 · Environment | Qualified sensors, reliability scoring, learned anomaly baselines and HVAC/energy optimization | Reference calibration, fault tests, safe recommendations and measured savings before control |
| 0.7 · Robotics | ROS 2 bridge, mission lab, navigation maps and fabrication status | Separate authority, restricted DDS, physical stop/interlock evidence, collision/exclusion and loss-of-link tests |
| 0.8 · Research | Approved providers, source credibility/dates, provenance and offline cache | Isolated egress, SSRF/redirect/size limits, malicious-content corpus and source-quality evaluation |
| 0.9 · Supervised evolution | Disposable development runner, branches, patch/test artifacts and independent approval | No core/device secrets, immutable artifact binding, protected guards, operator-only deployment and rollback proof |
| 1.0 · Private release | Multi-user enrollment, durable events, migrations, encrypted backups, external audit anchoring and recovery | Independent review, chaos/power-loss/recovery tests, sustained hardware trials and operational runbooks |

## Hardware sequence

Start with **read-only telemetry** on an isolated IoT network. `core/interfaces.py` declares future contracts. Keep adapters behind a dedicated control authority; do not give them directly to language-model agents.

1. **MQTT / wired sensors:** unique device credentials, topic ACLs, pinned broker trust, schema versions, sequence/time validity and room enrollment. Missing/stale readings must not drive unsafe decisions.
2. **Home Assistant:** allowlisted read-only bridge first, then explicit service/device scopes with operator-reviewed control envelopes. Never forward free-form model service names or whole-estate credentials.
3. **Matter / Zigbee / Z-Wave / Bluetooth:** use maintained local controllers, rather than reimplementing radio stacks. Test pairing, keys, revocation, topology loss, duplicates and reliable state reconciliation.
4. **Environment:** qualify CO₂, particulate, temperature/humidity, leak, weather, soil and meter hardware against references. Certified smoke/CO/heat alarms remain independently functional. AI cannot silence or replace them.
5. **Energy:** read inverter, battery, meter and generator telemetry first. Generator starts, transfer gear and high-power loads require reviewed electrical safeguards and explicit approval.
6. **Audio:** physical microphone mute circuits and privacy LEDs must work when the core is compromised/off. Keep samples local/transient by default. Test room handoff, speaker/subwoofer delays, synchronization and echo cancellation before always-listening.
7. **Robotics/fabrication:** isolated ROS 2 network, mission allowlists, speed/exclusion limits, battery thresholds and physical stop/interlock feedback. Mobile robots, arms, CNC and printers need separate safety cases. AI-generated motion code cannot bypass safety PLCs or stop chains.
8. **Outdoor safety:** map zones and read pump, water pressure/availability and independent emergency-power telemetry. Suppression actuation requires professional engineering, certified controllers, independent power, manual access and separate authorization. No generic AI activation command is acceptable.

## Platform evolution

Before scaling past one server, add durable authenticated queues/sessions, explicit migrations, versioned events, idempotency keys, optimistic state versions and device-specific compensation. Independently administer user identity, agent capability issuance, audit anchoring, hardware authority and deployment approval.

Natural conversation, adaptive personality, proactive maintenance and multimodal reasoning require evaluation sets and measured outcomes. Consent, confidence, provenance, visible microphone state and offline capability are acceptance criteria for every phase.
