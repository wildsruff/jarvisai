# Executed evidence · Iteration 2 · 2026-11-01

All commands ran in the existing repository on Linux, Python 3.12.14 and Node 24.19.0. Tests and demonstrations use temporary databases/loopback services. No physical device or public deployment was involved.

| Check | Baseline 8ee3d6b | Final v0.2 |
| --- | --- | --- |
| `./scripts/check.sh` / pytest | 54 passed (10.40s) | **92 passed (15.62s)** |
| `npm --prefix web run test:e2e` | 4 passed (9.0s) | **6 passed**; includes original four suites |
| TypeScript strict compile + Vite | Passed | **Passed**, 1,597 modules; staged `web/dist-next` |
| Ruff / Python formatting | Passed | **Passed** |
| Prettier source/config checks | Baseline source formatted | **Passed** |
| Bandit core/gateway/scripts | No unsuppressed findings | **No unsuppressed findings**; original two narrowly scoped simulation/test exclusions retained |
| `pip-audit -r requirements.txt` | No known vulnerabilities | **No known vulnerabilities** at scan time |
| `npm --prefix web audit` | 0 vulnerabilities | **0 vulnerabilities** at scan time |
| SQLite persistence/restart | Basic reopen tests | **Approved memories, candidates, corrections, model config and interrupted workflow context verified across close/reopen** |
| Scripted cooperating-agent demo | Not present | **Executed**; checkpoint reached, disabled rule published, device states unchanged, approved memory retrieved after reopen |

## Commands and retained evidence

```bash
./scripts/check.sh
cd web
npx prettier --check src e2e vite.config.ts playwright.config.ts tsconfig.json package.json index.html
npm run test:e2e
cd ..
.venv/bin/python scripts/demo_intelligence.py
.venv/bin/python scripts/benchmark.py
.venv/bin/bandit -r core gateway scripts -f json -o docs/iteration-2/security-scan.json
```

[baseline-checks.txt](baseline-checks.txt) and [baseline-browser.txt](baseline-browser.txt) predate changes. [final-checks.txt](final-checks.txt) and [final-browser.txt](final-browser.txt) retain final output. [demonstration.json](demonstration.json), [performance.json](performance.json) and [security-scan.json](security-scan.json) contain executed artifacts. The [generated canonical API contract](api-v1.json) contains 43 versioned paths and excludes frontend/legacy aliases. CI configuration is provided but was not run on a remote CI service.

## What the new tests verify

- Discovery and model selection/config persistence; local-only URL rejection; Ollama/OpenAI-compatible streams; completion markers and EOF errors; actual provider usage fields versus estimates; connection recovery without replaying partial output; HTTP error sanitization; total deadline and HTTP transport stream closure; cancellation during a pending token read.
- Complete system guard and well-formed quoted memory at the minimum context budget; task-specific model routing and persistent tone/humor/response guidance.
- Candidate-only extraction from user input; sensitive approval/rejection; credential exclusion; opt-out; normalized deduplication; structured claim conflicts and resolution; revision lineage; TTL filtering without dashboard polling; approved/relevant context injection; vector cache invalidation/deletion and explicit lexical fallback; invalid/zero/extreme vectors without non-finite scores; workflow-copy redaction on deletion/expiry with prevention of resurrection from in-flight snapshots.
- Canonical versioned routes and legacy compatibility, including original schema-1 exports; schema-2 export lineage; request IDs and errors that do not echo invalid secret values; read-only role privacy and denied mutations.
- Concrete six-stage cooperating-agent workflow; planner delegation/capability checks; shared timestamped telemetry; human checkpoint and exact draft approval; publication of a disabled routine with no actuation; rejection/cancellation; saved checkpoint recovery without rerunning completed specialist stages.
- Adoption of an unversioned v0.1 database without losing rows; rejection of unknown future schemas; approved memory/model persistence after reopen; trend sample evidence, cooldown/offline gates; rollback refusal after intervening same-value changes; explicit full audit validation.

The six Chromium suites render all fifteen views without page errors, verify phone navigation/overflow, retain original device/safety/research/proposal flows, approve a candidate and inspect its revision, review the cooperating-agent timeline, publish a disabled routine and save model context configuration. Browser approvals are automated operator actions in a test identity, not actual approval to deploy this release.

## Measurements and limits

The 40-request in-process state sample measured median **3.91 ms**, p95 **4.52 ms**, maximum **6.86 ms** on the seeded estate. This is a small TestClient sample without network/GPU load. The structural performance changes are SQL-bounded recent-history reads and a timestamped ten-second integrity cache; explicit diagnostics still performs full verification. No capacity, scaling or long-duration availability claim is made.

Real probes to localhost:11434 `/api/tags`, localhost:8080 `/v1/models` and localhost:1234 `/v1/models` returned connection errors. **Real LLM inference and real embedding quality were not verified.** Transport tests return deterministic fixtures and are labeled accordingly; mock summaries are never used as evidence of a working real model.

Two existing upstream pytest deprecation warnings remain (Starlette httpx TestClient transition and AnyIO BlockingPortal alias). Playwright's color-environment warning is cosmetic. Neither was hidden. Tests fixed a mistaken expectation that expired-memory retrieval should also exclude unrelated valid seed memory, and a browser assertion that confused a completed substep with a completed parent workflow; the corrected assertions check the intended behavior.

Not tested: physical sensors/robots/safety hardware, real audio capture, live web research, cloud inference, real model quality/throughput, TLS/proxy deployment, multi-user enrollment, OS-isolated generated-code execution, long-duration soak/load, or independent penetration testing. Current limitations and Iteration 3 priorities are in [README.md](README.md).
