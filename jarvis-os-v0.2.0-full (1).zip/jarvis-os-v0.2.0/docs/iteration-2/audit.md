# Iteration 2 audit · baseline 8ee3d6b

Before implementation, `./scripts/check.sh` passed: 54 pytest tests (10.40s), strict TypeScript/Vite build, Ruff/format, Bandit (two scoped exclusions), Python dependency audit and npm audit. `npm run test:e2e` passed all four Chromium suites (9.0s). Logs are retained beside this file. The source inventory covers the backend, frontend, scripts, tests, configuration and documentation; generated artifacts and dependencies were excluded.

Local probes to 127.0.0.1 ports 11434 (`/api/tags`), 8080 and 1234 (`/v1/models`) returned connection errors. No real inference was available at baseline. No model download or external inference service is substituted.

| Finding | Impact / Iteration 2 treatment |
| --- | --- |
| Model failures append mock text; no completion-marker validation | Separate configured/actual provider, explicit error events, no implicit fallback for real inference; validate completion |
| No discovery, context configuration, total deadline, usage parsing or retry | Persist model routing/configuration; discovery, connect-only retry, end-to-end deadline, cancellation, provider usage with honest estimates |
| Memory is flat JSON; no candidates, dedup, revisions or contradiction checks | Add a memory service, approval queue, correction lineage, conservative claim conflicts and retrieval adapter |
| Chat may inject expired memory unless state polling prunes it | Retrieval always filters expiry and unresolved conflicts independently of polling |
| Read-only state includes private memory/task results and conversations | Restrict sensitive routes/sections to explicit permissions before agent expansion |
| Agent roles are descriptive, not checked at each step | Enforce registered roles, allowed delegations, workflow scopes, bounded plans and explicit human checkpoints |
| In-flight tasks are interrupted with no checkpoint resume | Persist plan/context/timeline; resume only replay-safe stages on explicit operator request; never replay robot operations |
| HTTP routes unversioned and error shapes inconsistent | Add canonical `/api/v1`, retain compatibility routes, stable error codes/request IDs and sanitized validation errors |
| No schema migration history | Transactional numbered migrations, reject unknown future schemas, preserve v0.1 data |
| State loads all history and verifies the entire ledger each poll | SQL-bounded recent reads and explicitly timestamped cached integrity checks; full checks remain available |
| Humor/proactivity preferences mostly stored-only | Apply prompt preferences; evidence-based local trend engine, cooldown and explicit routine approval |
| Rollback compares values only (ABA changes) | Compare applied state timestamp as well as value |
| Global chat lock and model stream error cleanup need stronger tests | Verify cancellation, transport closure, failure records and restart behavior |

Retained limitations: one administrator, process-local sessions/worker queue, trusted SQLite owner, synchronous DB operations in the core process, single-server deployment, no OS agent sandbox, no real hardware/STT/TTS/3D editor/live web research/code deployment. Existing docs generally disclose simulations correctly; specialist registration is not proof of an independent reasoning model, voice controls are preferences, and curated research is not a web search. Iteration 2 will keep those labels.

This audit is a code and test review, not an independent penetration test. Real-device safeguards, approval policies and external domain isolation remain unchanged.
