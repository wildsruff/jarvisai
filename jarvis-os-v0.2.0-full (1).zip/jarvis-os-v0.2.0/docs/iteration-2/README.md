# Genesis Iteration 2 · intelligence and reliability

This release evolves the existing v0.1 repository. It preserves its fifteen command-center views, estate simulation, device controls, automation, audio/robotics simulations, research fixture, development proposals, audit trail and recovery tooling. It does not deploy generated code or integrate physical devices.

## Delivered changes

**Inference:** persistent administrator-selected local provider and task routes; model discovery; Ollama NDJSON/OpenAI-compatible SSE; validated completion and usage frames; bounded context; connection-only retry; independent connect/idle/total deadlines; transport cancellation; first-token/total latency; explicit outcome and provider identity. Real-provider failures emit errors and partial-response status. They never append mock intelligence. Provider token counts are labeled reported; estimates remain separate when counts are absent. History preserves per-response provenance, including an “unrecorded provider” label for legacy messages.

**Memory:** explicit first-person statements generate review candidates, never established facts. Every candidate requires operator approval, covering sensitive/consequential information even when the heuristic classifier misses it. Credential-like candidates are excluded. Approved candidates remain unverified at a heuristic confidence of 0.65 unless explicitly corrected/verified. Candidates retain conversation/message provenance and expire after seven days. Approved retention is configurable. Normalized deduplication, structured-claim contradiction checks, correction history, export and deletion are implemented. Conflicting claims are withheld from retrieval. The semantic adapter can request real embeddings from a configured local engine; default lexical concept retrieval and embedding fallback are labeled.

**Agent workflows:** code-owned plans now include dependencies, delegated specialist, capability and replay safety. The new comfort-plan workflow verifies policy, decomposes the task, delegates memory/telemetry/environment review, shares typed JSON outputs, and pauses for review. The approved digest binds the exact plan and routine draft. Approval publishes a **disabled** routine, with zero device operations. Timelines and factual decision summaries are visible. Restart preserves completed evidence and marks unfinished work interrupted; explicit recovery resumes safe stages at most twice. Robot missions must be resubmitted rather than replayed.

**Personality/proactivity:** tone, humor and response preferences form persistent inference guidance. Safety context suppresses joking. Preference extraction is configurable. A local trend engine requires sufficient fresh, online samples, measures a rise, stores its evidence/source/window, and applies cooldown. It makes advisory observations, not causal diagnoses. A proposed routine still goes through the human checkpoint and existing autonomy controls.

**Engineering:** transactional migrations adopt v0.1 data and reject future schemas; canonical `/api/v1` with legacy compatibility; structured errors/request IDs without echoed secret inputs; sensitive state redaction; bounded recent-history SQL reads and timestamped audit verification caching; rollback rejects intervening changes even if values return to the same number. Builds stage in `web/dist-next`, protecting the separately running v0.1 frontend assets.

## Architecture

```mermaid
flowchart LR
  UI[Command center] --> API[Authenticated /api/v1]
  API --> Chat[Conversation / cancellation controller]
  Chat --> Retrieval[Memory service / bounded retrieval]
  Retrieval --> Lex[Lexical concept adapter]
  Retrieval --> Emb[Optional real local embedding adapter]
  Chat --> Prompt[Complete guard / personality / quoted context]
  Prompt --> Local[Mock or real local inference adapter]
  Chat --> Candidates[Pending memory candidates]
  Candidates --> Review[Explicit operator review]
  Review --> Facts[Persistent unverified/verified memory + revisions]
  API --> Plan[Registered bounded plans]
  Plan --> Specialists[Scoped cooperating specialist stages]
  Specialists --> Checkpoint[Digest-bound human approval]
  Checkpoint --> Disabled[Publish disabled routine]
  Sensors[Simulated history] --> Trends[Evidence-based trend advice]
  Trends --> Plan
  Facts --> DB[(SQLite / numbered migrations)]
  Specialists --> DB
```

New modules are `core/migrations.py`, `memory.py`, `personality.py` and `proactivity.py`. `models.py`, `workflows.py`, storage and API services extend the existing core. The external gateway remains data-only and optional. No shell, plugin-code runner, production deploy endpoint, cloud-model fallback or hazardous driver was added.

## Functional demonstrations

Run the isolated scripted demonstration:

```bash
.venv/bin/python scripts/demo_intelligence.py
```

It uses a temporary SQLite database, creates/reviews an unverified candidate, executes the cooperating comfort plan, pauses for approval, publishes a disabled rule, verifies unchanged device state, closes/reopens the database and retrieves the approved memory. Approvals are explicitly **scripted administrator actions**, not a claim that a person reviewed a production deployment. [demonstration.json](demonstration.json) records an actual run.

In the UI, send “My preferred study temperature is 22 C.” in Conversation. Open Memory, inspect the pending candidate and approve it. Inspect its correction history. In AI Agents, choose **Prepare comfort plan**, expand the workflow, inspect evidence/draft/timeline, then approve or reject the disabled routine. Administration exposes local-model discovery/routing/context/timeouts and persistent personality controls. Environment exposes trend observations with their exact sample evidence.

Screenshots: [memory review](memory-review.png) and [agent checkpoint](agent-checkpoint.png). [Verification](verification.md) records baseline/final commands and limits. [Audit](audit.md) records the original findings. [Upgrade](upgrade.md) describes review and activation; no live migration or deployment was performed.

## Limits and Iteration 3 priorities

No real inference server responded on the probed local endpoints. Real model quality, embedding quality, GPU behavior and context-token accuracy are **unverified**. Protocols use deterministic test transports. Character budgeting is not tokenizer-aware context accounting. Vision remains a text-only route. Personality is guidance, not a guarantee of model behavior.

Extraction is a bounded pattern-based candidate generator, not open-ended semantic understanding. Contradiction detection covers supported claim slots; it can miss paraphrases or flag benign differences. Similarity scores and extraction confidence are not calibrated probabilities. Retrieval considers up to 500 nonconflicting memories, returns at most 100 matches (five for chat), and reports truncation. Embeddings are optional; no fabricated vectors stand in for a model. Vector cache and correction/candidate copies are removed on live deletion/expiry. Structured memory copies in saved workflows are redacted, and later writes from an in-flight worker cannot resurrect deleted, expired or superseded snapshots. Active generations can retain already supplied RAM context until stopped; chat history, existing exports and backups have separate lifecycles. The dashboard projects the latest 100 candidates and 60 workflows; full retained candidate data is in the schema-2 export, with pagination left for Iteration 3.

Plans and delegation are registered, deterministic workflows, not unrestricted LLM agents. Agent capabilities are logical checks inside a trusted process, not OS isolation. Existing one-admin, single-worker, plaintext-storage, local-session and private-TLS-proxy constraints remain. The trend engine uses simulated readings and thresholds; it is not a certified alarm, learned causal model or real energy optimization controller.

Priorities for Iteration 3:

1. Qualify an owned local inference/embedding server with an offline evaluation set, real streaming disconnects, model-specific token budgets, retrieval recall and long-duration fault tests.
2. Replace heuristic extraction/claim matching with evaluated local structured extraction, calibrated uncertainty, richer provenance and user-reviewed entity/relationship resolution.
3. Introduce durable worker leases, per-device capabilities and separate OS identities before distributed agents or any real control integration.
4. Add authenticated model-server secret/TLS support, multi-user consent scopes and encrypted backup operations; commission independent security review.
5. Add read-only qualified sensor adapters and richer trend validation before real writes, speech capture, ROS integration or supervised code execution.
