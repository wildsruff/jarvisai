# Review and activation

v0.2 is implemented and tested in the same repository. The existing loopback v0.1 service on port 8000 and its runtime database have **not** been activated/migrated to v0.2. No hazardous device, public endpoint or generated-code deployment was configured.

## Review first

Review the diff from `8ee3d6b`, [audit](audit.md), [verification](verification.md), security notes below, and [demonstration](demonstration.json). The ordinary setup/check commands build into **`web/dist-next`**, so they do not replace the v0.1 assets in `web/dist`. The new core uses the staged directory; `JARVIS_WEB_ASSETS` can select an explicit approved build directory. No test server uses the live runtime database.

To inspect v0.2 interactively without altering v0.1, use a **new private runtime directory**, a different loopback port, and matching origin. Start only after reviewing the change:

```bash
./scripts/setup.sh
JARVIS_RUNTIME=/path/to/private/genesis-v02-review \
JARVIS_PORT=8002 \
JARVIS_ALLOWED_ORIGINS=http://127.0.0.1:8002 \
./scripts/run.sh
```

Read that directory's generated `admin-password` locally and sign in at http://127.0.0.1:8002. Keep the directory private. This uses fresh synthetic data, not a copy of real estate credentials. The run script's banner describes its default port; use the configured port shown by uvicorn when overriding it.

## Approved upgrade of the existing runtime

1. Obtain explicit operator deployment approval after reviewing code, artifacts and checks.
2. Stop the v0.1 process using its service manager or known process identity. Do not run both cores against one database.
3. Create and externally protect a verified v0.1 database backup using `scripts/backup.py`. Record the source Git release and audit head.
4. Install dependencies/build the approved v0.2 artifact. Startup adopts existing tables through numbered transactional migrations 1 and 2. It adds revisions, vector cache, workflow events and migration history without deleting legacy data. Unknown future schemas fail startup.
5. Keep autonomy disabled during review. Interrupted old tasks are not silently replayed; legacy tasks without a replay-safe plan and all robot missions require resubmission. New interrupted plans can resume explicitly, preserving completed timestamped evidence. Waiting approvals remain waiting across restart.
6. Verify API health/version, full diagnostic audit integrity, model configuration, memories, candidates, rules and manual controls. Test the simulation stop before enabling autonomous simulation.

Rollback requires the old source/build **and its pre-upgrade database snapshot**. Never point v0.1 at a v0.2 database and assume downgrade safety: v0.1 predates schema checks and correction/vector semantics. Restore to a new path; retain the upgraded copy for investigation.

## API and configuration compatibility

`/api/v1` is canonical. Legacy `/api` routes remain authenticated aliases with a Deprecation header. Legacy memory export remains schema 1; `/api/v1/memories/export` is schema 2 and includes candidates/correction history. Validation errors expose stable codes, request IDs and field locations, without echoing submitted passwords or other values.

Real inference failure behavior intentionally changes: it emits an error and marks partial/failed output, rather than generating mock text. SSE now includes status/context/error events in addition to tokens/done. Clients must inspect completion status. Per-response provider identity is retained; legacy history without it is labeled unknown rather than attributed to a real model.

Environment model settings are defaults until an administrator saves a model configuration. Persisted provider/routes/deadlines/context settings then take precedence, including across restart. No model is downloaded by discovery/selection. Optional `JARVIS_EMBEDDING_MODEL` selects a locally installed embedding model using the saved local provider endpoint; absence/failure is labeled lexical retrieval. Embedding calls have an eight-second overall retrieval deadline and bounded batches/cache validation.

## Authorization review

Only an administrator can sign in in this release. Viewer state no longer includes memory, candidate, conversation, private task output, inference or audit contents. Chat, memory, administration, task execution and device writes retain separate endpoint permissions. Agents have no authentication tokens and cannot promote themselves through request bodies.

Registered stages enforce their role/capability and workflow membership. In the new comfort plan, the planner's declared delegation must authorize downstream stages. The memory specialist has `memory.read`, not memory approval/write access. Research cannot control devices. Scheduler capability permits research only. Automation can publish only the reviewed disabled routine, with the approval digest bound to its draft/plan. Human approval endpoints require operator authority; no agent role can approve the routine. No role gains shell or production deployment rights.

These are application checks inside one trusted process. Malicious arbitrary code with the host identity could bypass them. No arbitrary code runner was added. Production isolation, certificate/secret management, durable session limits and multi-user enrollment remain future work. Model HTTP clients stay local-only and do not follow redirects; external research remains behind its existing signed data-only gateway. Existing physical safeguards and approval policies remain independently necessary.
