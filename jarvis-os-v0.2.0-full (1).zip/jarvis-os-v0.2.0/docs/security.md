# Iteration 2 security update

Read the [authorization and upgrade review](iteration-2/upgrade.md) and [audit](iteration-2/audit.md) alongside the original controls below. v0.2 restricts private memory/task/conversation state, validates scoped delegation and human checkpoints, sanitizes structured errors, and never substitutes mock text for real-provider failures. It adds no public exposure, arbitrary execution or physical actuation.

# Security model and current limitations

This is a single-administrator local simulation prototype. Do not expose it directly to the public internet or connect it to critical equipment.

## Implemented controls

- The core binds to loopback by default. Allowed hosts and origins are explicit. No wildcard CORS is enabled.
- A unique administrator password is generated in a directory with mode `0700`, in a file with mode `0600`. Password verification uses scrypt with a per-process random salt. An environment-supplied password must contain at least 12 characters. There is no default shared login.
- Sessions contain random bearer secrets in HttpOnly, SameSite=Strict cookies and expire after eight hours. Mutations require a session-specific CSRF header. Session state is in memory and invalidates on restart. Set secure cookies behind TLS.
- Login attempts are limited to eight per client address per 15 minutes. Authenticated API calls are limited to 120 per minute per session; chat to 20 per minute. Limits are process-local, not a distributed defense.
- Pydantic rejects unknown input fields, invalid identifiers and non-finite/out-of-range numbers. Request bodies are bounded. The UI renders model and research text without raw HTML. Security headers restrict scripts, framing, references and same-origin connections.
- Device access is centrally authorized. Research, monitoring and conversation roles have no control permission. Hazardous/non-simulated equipment is denied independently of model text. Autonomy starts disabled; manual control overrides automatic rules.
- The optional gateway uses separate HMAC credentials, a 60-second request freshness window, bounded nonce tracking, signed responses and a strict data-only schema. No external instruction is executed. Replay state is in memory; restarting the gateway invalidates its nonce cache, so protect the transport and do not reuse requests.
- Model URLs accept localhost or literal private addresses only, with no userinfo, query strings or redirects. No arbitrary user URL fetcher is exposed. Local HTTP clients bypass environment proxies so estate telemetry is not accidentally sent to a cloud proxy.
- Audit records form a SHA-256 chain. Backups capture its latest head. Memory and chat contents are excluded from audit events. Secret values are not logged.
- The application never invokes a shell, runs generated code, modifies its source, grants new privileges, or deploys a proposal. Proposed security-policy and approval changes are refused, and no agent has filesystem modification tools.

## Limits that matter before real deployment

Authentication supports one administrator; there is no user enrollment, MFA, recovery email, per-occupant access, durable session registry, or credential rotation UI. Permission roles are enforced for internal code and available for future identities; only the admin role can sign in today.

The process and SQLite owner are trusted. An administrator can rewrite the database, audit chain, code, or backup permissions. A linked audit trail detects inconsistency, not malicious full-chain recomputation; save signed/remote heads externally for stronger evidence. Read-only, content-addressed snapshots are application-immutable but need offline/WORM copies for host-administrator-resistant immutability.

The database and HTTP loopback transport are not encrypted. Use encrypted host disks and an authenticated private TLS reverse proxy for LAN clients. Filesystem deletion does not erase existing backups, exports, disk snapshots, or every WAL/disk remnant. SQLite secure deletion is enabled for live pages, but no forensic erasure guarantee is made.

Logical agent permissions run inside the core process; they are not OS sandboxing. There is no arbitrary code runner to isolate in this release. Before adding code generation execution, use disposable offline containers/VMs with no core keys, no device network, no host socket, read-only base images, CPU/memory/time quotas, explicit artifact review, and a different deployment identity. Approval and hardware policy must remain outside that sandbox.

The gateway fixture does not browse the web. Adding research providers requires outbound destination allowlists, private-address/redirect protection, source provenance and publication-time records, content size/time limits, credentials isolated from the core, and tests for malicious retrieved content. HMAC authentication does not make retrieved text trustworthy.

The environment simulator is not a calibrated sensor, alarm, person identifier, energy meter, or physical safety controller. It does not contact emergency services. Hardware stop buttons, independent detectors, certified suppression/shutoff controls, lock safeguards and code-compliant procedures must continue to work when the server is off, corrupted, or disconnected.

## Recommended network layout

```mermaid
flowchart TB
  User[Trusted client VLAN] --> TLS[Private TLS proxy]
  TLS --> Core[Core server VLAN]
  Core --> Models[Local model service]
  Core --> Authority[Future dedicated control authority]
  Authority --> IoT[Isolated device VLAN]
  Core --> Gateway[Separate gateway VLAN / host]
  Gateway --> Internet[Approved internet destinations]
  Independent[Certified safety controllers] --> Hardware[Physical safeguards]
```

Allow only core → gateway research and the approved gateway responses; deny gateway → core/device VLAN initiation. Give the gateway no core password, session cookie, database mount or device credentials. Future drivers need individual enrollment keys, read/control capability scopes, pinned peer identity, replay protection, command TTL, hardware interlock feedback and an operator-tested revocation mechanism.

## Recovery

1. Stop the local core. Physical emergency procedures remain independent.
2. Take a forensic copy of the runtime directory if appropriate; protect it as private data.
3. Restore a verified snapshot to a **new** path with `scripts/backup.py restore`. Preserve the original. Verify database integrity and audit head against a trusted backup manifest.
4. Reset local credentials by replacing the environment secret or, when the core is stopped, deleting `.runtime/admin-password` to generate a new one. Do not delete the database merely to reset a password.
5. Rotate the separate gateway key on both services if compromised. Restart both to invalidate sessions and replay state. Keep autonomy disabled during verification.
6. Run backend tests and browser checks, then review device/automation state before resuming simulation. A future production recovery flow must force hardware systems to their independently defined safe state.

See [deployment.md](deployment.md) for exact configuration. Dependency scans are point-in-time evidence, not a security certification.
