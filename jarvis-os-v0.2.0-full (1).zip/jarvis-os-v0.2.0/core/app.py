import asyncio
import contextlib
import json
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.routing import APIRoute
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .contracts import (
    Login,
    Chat,
    Memory,
    DeviceCommand,
    Rule,
    Toggle,
    AudioCommand,
    Settings,
    Scenario,
    Occupancy,
    TaskRequest,
    Proposal,
    ProposalAction,
    ModelConfiguration,
    Review,
)
from .models import Models, interruptible
from .security import Auth, PERMISSIONS
from .memory import MemoryService
from .personality import prepare_context
from .proactivity import Proactivity
from .simulation import Automation, Control, Simulator, recommendations, seed
from .storage import Store, now, uid
from .workflows import Orchestrator, REQUIRED

ROOT = Path(__file__).resolve().parent.parent


def create_app(db_path=None, simulation=True):
    runtime = Path(os.getenv("JARVIS_RUNTIME", str(ROOT / ".runtime")))
    runtime.mkdir(parents=True, exist_ok=True)
    runtime.chmod(0o700)
    store = Store(str(db_path or runtime / "jarvis.db"))
    seed(store)
    saved_settings = store.get("settings", "main")
    store.put(
        "settings",
        {
            "id": "main",
            **Settings.model_validate(
                {k: v for k, v in saved_settings.items() if k != "id"}
            ).model_dump(),
        },
    )
    auth = Auth(runtime)
    models = Models(store)
    memory = MemoryService(store, models)
    proactive = Proactivity(store)
    control = Control(store)
    automation = Automation(store, control)
    simulator = Simulator(store, automation)
    orchestrator = Orchestrator(store, models)
    started = time.monotonic()
    chat_lock = asyncio.Lock()
    active_chat = {}
    if not store.get("schedule", "research"):
        store.put(
            "schedule",
            {
                "id": "research",
                "enabled": False,
                "interval_seconds": 86400,
                "last_run": 0,
                "subject": "Local-first home intelligence and sensor reliability",
            },
        )

    async def clock():
        while True:
            await asyncio.sleep(2)
            try:
                simulator.tick()
                if simulator.ticks % 15 == 0:
                    proactive.evaluate()
                schedule = store.get("schedule", "research")
                if (
                    schedule["enabled"]
                    and time.time() - schedule["last_run"]
                    > schedule["interval_seconds"]
                ):
                    await orchestrator.submit(
                        {"workflow": "research", "subject": schedule["subject"]},
                        "scheduler",
                        "scheduler",
                    )
                    schedule["last_run"] = time.time()
                    store.put("schedule", schedule)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                store.audit("system", "simulation.error", {"error": type(exc).__name__})

    @asynccontextmanager
    async def lifespan(app):
        orchestrator.recover()
        for inference in store.latest("inference", 100):
            if inference.get("status") == "running":
                inference.update(
                    status="interrupted",
                    error={
                        "code": "core_restarted",
                        "message": "Core restarted during inference.",
                    },
                )
                store.put("inference", inference)
        worker = asyncio.create_task(orchestrator.worker())
        ticker = asyncio.create_task(clock()) if simulation else None
        yield
        for job in [ticker, worker]:
            if job:
                job.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await job
        store.close()

    app = FastAPI(
        title="JARVIS OS · Local Core",
        version="0.2.0",
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
    )
    app.state.store, app.state.control, app.state.automation = (
        store,
        control,
        automation,
    )
    app.state.simulator, app.state.orchestrator, app.state.auth = (
        simulator,
        orchestrator,
        auth,
    )
    app.state.memory, app.state.models, app.state.proactive = memory, models, proactive
    allowed_hosts = os.getenv(
        "JARVIS_ALLOWED_HOSTS", "127.0.0.1,localhost,testserver"
    ).split(",")
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)
    allowed_origins = set(
        os.getenv(
            "JARVIS_ALLOWED_ORIGINS",
            "http://127.0.0.1:8000,http://localhost:8000,http://127.0.0.1:5173,http://localhost:5173,http://testserver",
        ).split(",")
    )

    def problem(request, status, message, code=None, fields=None):
        codes = {
            400: "bad_request",
            401: "authentication_required",
            403: "permission_denied",
            404: "not_found",
            409: "state_conflict",
            413: "payload_too_large",
            422: "invalid_input",
            429: "rate_limited",
            500: "internal_error",
        }
        return JSONResponse(
            {
                "detail": message,
                "error": {
                    "code": code or codes.get(status, "request_failed"),
                    "message": message,
                    "request_id": getattr(request.state, "request_id", "unassigned"),
                    "fields": fields or [],
                },
            },
            status_code=status,
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request, exc):
        return problem(request, exc.status_code, str(exc.detail))

    @app.exception_handler(RequestValidationError)
    async def invalid_input(request, exc):
        fields = [
            {"location": list(e["loc"]), "message": e["msg"], "type": e["type"]}
            for e in exc.errors()
        ]
        return problem(
            request, 422, "Check the request fields.", "invalid_input", fields
        )

    @app.middleware("http")
    async def security_headers(request, call_next):
        start = time.monotonic()
        request.state.request_id = uid()
        origin = request.headers.get("origin")
        response = None
        if origin and origin not in allowed_origins:
            response = problem(request, 403, "Origin not allowed", "origin_denied")
        if response is None and request.method not in ("GET", "HEAD", "OPTIONS"):
            content = bytearray()
            async for chunk in request.stream():
                content.extend(chunk)
                if len(content) > 65536:
                    response = problem(request, 413, "Request too large")
                    break
            request._body = bytes(content)
        if response is None:
            try:
                response = await call_next(request)
            except Exception as exc:
                store.audit(
                    "system",
                    "request.failed",
                    {
                        "request_id": request.state.request_id,
                        "error": type(exc).__name__,
                    },
                )
                response = problem(
                    request, 500, "The core could not complete this request."
                )
        response.headers.update(
            {
                "X-Request-ID": request.state.request_id,
                "X-API-Version": "1",
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "DENY",
                "Referrer-Policy": "no-referrer",
                "Cache-Control": "no-store"
                if request.url.path.startswith("/api")
                else "no-cache",
                "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
                "X-Response-Time-Ms": str(round((time.monotonic() - start) * 1000, 2)),
            }
        )
        if request.url.path.startswith("/api/") and not request.url.path.startswith(
            "/api/v1/"
        ):
            response.headers["Deprecation"] = "true"
        return response

    def permit(permission):
        def dependency(request: Request):
            return auth.authenticate(request, permission)

        return dependency

    read = permit("read")

    def entity(kind, id):
        item = store.get(kind, id)
        if not item:
            raise HTTPException(404, f"{kind.capitalize()} not found")
        return item

    @app.get("/api/health")
    async def health():
        return {
            "status": "online",
            "version": "0.2.0",
            "mode": "simulation",
            "domain": "local-core",
        }

    @app.post("/api/login")
    async def login(body: Login, request: Request, response: Response):
        try:
            token, session = auth.login(
                body.username, body.password, request.client.host
            )
        except HTTPException:
            store.audit("anonymous", "auth.login_denied", {})
            raise
        response.set_cookie(
            "jarvis_session",
            token,
            httponly=True,
            samesite="strict",
            secure=os.getenv("JARVIS_SECURE_COOKIE") == "1",
            max_age=28800,
        )
        store.audit("admin", "auth.login", {})
        return {
            "actor": session["actor"],
            "role": session["role"],
            "csrf": session["csrf"],
        }

    @app.get("/api/session")
    async def session(user=Depends(read)):
        return {"actor": user["actor"], "role": user["role"], "csrf": user["csrf"]}

    @app.post("/api/logout")
    async def logout(request: Request, response: Response, user=Depends(read)):
        auth.sessions.pop(request.cookies.get("jarvis_session"), None)
        response.delete_cookie("jarvis_session")
        return {"signed_out": True}

    @app.get("/api/state")
    async def state(user=Depends(read)):
        store.prune()
        kinds = [
            "room",
            "sensor",
            "device",
            "audio",
            "rule",
            "robot",
            "agent",
            "memory",
            "alert",
        ]
        result = {
            ("memories" if kind == "memory" else kind + "s"): store.all(kind)
            for kind in kinds
        }
        for kind in ["task", "run", "research", "proposal", "inference"]:
            result["research" if kind == "research" else kind + "s"] = store.latest(
                kind, 60
            )
        result.update(
            settings=store.get("settings", "main"),
            schedule=store.get("schedule", "research"),
            recommendations=recommendations(store),
            audit=store.logs(40),
            system={
                "uptime_seconds": round(time.monotonic() - started),
                "mode": "simulation",
                "version": "0.2.0",
                "model": models.last_health,
                "schema_version": 2,
                "queue_depth": orchestrator.queue.qsize(),
                "audit_integrity": store.cached_integrity()["valid"],
                "audit_check": store.cached_integrity(),
            },
        )
        permissions = PERMISSIONS.get(user["role"], set())
        result["agents"] = [
            {**agent, "permission": REQUIRED.get(agent["id"], agent["permission"])}
            for agent in result["agents"]
        ]
        result["memories"] = memory.annotated() if "memory" in permissions else []
        result.update(
            memory_candidates=store.latest("memory_candidate", 100)
            if "memory" in permissions
            else [],
            suggestions=store.latest("suggestion", 30),
        )
        if "memory" not in permissions:
            result["memories"] = []
        if "tasks" not in permissions:
            result["tasks"] = []
            result["research"] = []
        if "admin" not in permissions:
            result["audit"] = []
            result["inferences"] = []
            result["proposals"] = []
        return result

    @app.get("/api/history")
    async def history(
        room: str = "living", metric: str = "temperature", user=Depends(read)
    ):
        entity("room", room)
        if not store.get("sensor", f"{room}-{metric}"):
            raise HTTPException(404, "Sensor not found")
        return store.history(room, metric)

    @app.get("/api/conversation/{id}")
    async def conversation(id: str, user=Depends(permit("chat"))):
        return store.get("conversation", id) or {"id": id, "messages": []}

    @app.delete("/api/conversation/{id}")
    async def clear_conversation(id: str, user=Depends(permit("chat"))):
        if chat_lock.locked():
            raise HTTPException(
                409, "Interrupt the active response before clearing history"
            )
        store.delete("conversation", id)
        store.audit(user["actor"], "conversation.deleted", {"id": id})
        return {"deleted": id}

    @app.post("/api/chat")
    async def chat(body: Chat, request: Request, user=Depends(permit("chat"))):
        auth.limit("chat:" + user["actor"], 20, 60)
        if chat_lock.locked():
            raise HTTPException(
                409,
                "A response is already running; interrupt it before sending another",
            )
        await chat_lock.acquire()
        cancel_event = asyncio.Event()
        active_chat.update(actor=user["actor"], cancel_event=cancel_event)
        try:
            record = store.get("conversation", body.conversation_id) or {
                "id": body.conversation_id,
                "messages": [],
            }
            message_id = uid()
            record["messages"].append(
                {
                    "id": message_id,
                    "role": "user",
                    "content": body.message,
                    "timestamp": now(),
                }
            )
            record["messages"] = record["messages"][-39:]
            store.put("conversation", record)
            candidates = memory.extract(body.message, body.conversation_id, message_id)
            retrieval = await memory.retrieve(body.message)
            prepared = prepare_context(
                store.get("settings", "main"),
                retrieval,
                body.task,
                models.config["context_chars"],
            )
            system = prepared["message"]
        except BaseException:
            active_chat.clear()
            chat_lock.release()
            raise

        async def events():
            answer = ""
            completed = False
            metrics = None
            error = None

            async def watch_disconnect():
                while not cancel_event.is_set():
                    if await request.is_disconnected():
                        cancel_event.set()
                        return
                    await asyncio.sleep(0.1)

            watcher = asyncio.create_task(watch_disconnect())
            try:
                yield (
                    "data: "
                    + json.dumps(
                        {
                            "type": "context",
                            "retrieval_method": retrieval["method"],
                            "omitted_memories": prepared["omitted_memories"],
                            "memory_ids": prepared["memory_ids"],
                            "candidate_count": len(candidates),
                            "retrieval_fallback_error": retrieval["fallback_error"],
                        }
                    )
                    + "\n\n"
                )
                stream = models.stream(
                    [system]
                    + [
                        {"role": m["role"], "content": m["content"]}
                        for m in record["messages"]
                    ],
                    body.task,
                )
                async with contextlib.aclosing(
                    interruptible(stream, cancel_event)
                ) as cancellable:
                    async for event in cancellable:
                        if event["type"] == "token":
                            answer += event["text"]
                        if event["type"] == "error":
                            error = event["error"]
                        if event["type"] == "done":
                            metrics = event["metrics"]
                            completed = metrics["status"] == "completed"
                        yield "data: " + json.dumps(event) + "\n\n"
            finally:
                watcher.cancel()
                try:
                    if answer or error:
                        record["messages"].append(
                            {
                                "id": uid(),
                                "role": "assistant",
                                "content": answer,
                                "timestamp": now(),
                                "interrupted": not completed,
                                "error": error,
                                "provider": (metrics or {}).get(
                                    "provider", models.provider
                                ),
                                "model": (metrics or {}).get("model"),
                                "retrieved_memory_ids": prepared["memory_ids"],
                            }
                        )
                        record["messages"] = record["messages"][-40:]
                        store.put("conversation", record)
                    store.audit(
                        user["actor"],
                        "chat.completed" if completed else "chat.interrupted",
                        {
                            "conversation_id": body.conversation_id,
                            "task": body.task,
                            "error_code": error["code"] if error else None,
                        },
                    )
                finally:
                    active_chat.clear()
                    chat_lock.release()
                    with contextlib.suppress(asyncio.CancelledError):
                        await watcher

        return StreamingResponse(
            events(),
            media_type="text/event-stream",
            headers={"X-Accel-Buffering": "no"},
        )

    @app.get("/api/memories/export")
    async def export_memory(request: Request, user=Depends(permit("memory"))):
        store.prune()
        payload = {
            "schema": 2,
            "exported_at": now(),
            "memories": memory.annotated(),
            "candidates": store.all("memory_candidate"),
            "correction_history": {
                m["id"]: memory.history(m["id"]) for m in memory.active()
            },
        }
        if not request.url.path.startswith("/api/v1/"):
            payload = {
                key: payload[key] for key in ("schema", "exported_at", "memories")
            }
            payload["schema"] = 1
        return Response(
            json.dumps(payload, indent=2),
            media_type="application/json",
            headers={
                "Content-Disposition": 'attachment; filename="jarvis-memories.json"'
            },
        )

    @app.post("/api/chat/cancel")
    async def interrupt_chat(user=Depends(permit("chat"))):
        if not active_chat:
            raise HTTPException(409, "No response is running")
        if active_chat["actor"] != user["actor"] and user["role"] != "admin":
            raise HTTPException(403, "Cannot interrupt another operator session")
        active_chat["cancel_event"].set()
        return {"cancellation_requested": True}

    @app.get("/api/memories/search")
    async def search_memory(q: str = "", user=Depends(permit("memory"))):
        return (
            (await memory.retrieve(q, 100))["memories"]
            if q.strip()
            else memory.active()[:100]
        )

    def save_memory(body, id, actor):
        return memory.save(body, id, actor)

    @app.post("/api/memories")
    async def add_memory(body: Memory, user=Depends(permit("memory"))):
        return save_memory(body, uid(), user["actor"])

    @app.put("/api/memories/{id}")
    async def update_memory(id: str, body: Memory, user=Depends(permit("memory"))):
        entity("memory", id)
        return save_memory(body, id, user["actor"])

    @app.delete("/api/memories/{id}")
    async def delete_memory(id: str, user=Depends(permit("memory"))):
        entity("memory", id)
        memory.delete(id, user["actor"])
        return {"deleted": id}

    @app.post("/api/devices/{id}/command")
    async def device_command(
        id: str, body: DeviceCommand, user=Depends(permit("control"))
    ):
        return control.command(id, body.value, user["actor"], user["role"])

    @app.post("/api/rules")
    async def create_rule(body: Rule, user=Depends(permit("automate"))):
        data = {**body.model_dump(), "id": uid(), "last_run": 0, "cooldown_seconds": 60}
        automation.validate(data)
        store.put("rule", data)
        store.audit(user["actor"], "automation.created", {"id": data["id"]})
        return data

    @app.put("/api/rules/{id}/enabled")
    async def rule_enabled(id: str, body: Toggle, user=Depends(permit("automate"))):
        rule = entity("rule", id)
        rule["enabled"] = body.enabled
        store.put("rule", rule)
        store.audit(
            user["actor"], "automation.toggled", {"id": id, "enabled": body.enabled}
        )
        return rule

    @app.post("/api/rules/{id}/run")
    async def rule_run(id: str, dry_run: bool = True, user=Depends(permit("automate"))):
        return automation.run(entity("rule", id), dry_run=dry_run)

    @app.post("/api/runs/{id}/rollback")
    async def rollback(id: str, user=Depends(permit("automate"))):
        run = entity("run", id)
        if run["dry_run"] or run["status"] != "completed":
            raise HTTPException(409, "Only completed executions can be rolled back")
        with store.transaction():
            for step in run["steps"]:
                d = control.check(step["device_id"], step["previous"])
                if d["value"] != step["value"] or (
                    step.get("applied_at") and d["updated_at"] != step["applied_at"]
                ):
                    raise HTTPException(
                        409, "Device changed since execution; review it manually"
                    )
            for step in run["steps"]:
                d = store.get("device", step["device_id"])
                d.update(
                    value=step["previous"],
                    updated_at=now(),
                    manual_until=time.time() + 300,
                )
                store.put("device", d)
            run["status"] = "rolled_back"
            store.put("run", run)
            store.audit(user["actor"], "automation.rolled_back", {"id": id})
        return run

    @app.put("/api/audio/{id}")
    async def audio(id: str, body: AudioCommand, user=Depends(permit("control"))):
        zone = entity("audio", id)
        if body.hardware_muted and body.microphone != "muted":
            raise HTTPException(
                409, "Release the simulated hardware mute before enabling a microphone"
            )
        zone.update(body.model_dump())
        store.put("audio", zone)
        store.audit(
            user["actor"], "audio.updated", {"room_id": id, **body.model_dump()}
        )
        return zone

    @app.put("/api/rooms/{id}/occupancy")
    async def occupancy(id: str, body: Occupancy, user=Depends(permit("control"))):
        room = entity("room", id)
        room.update(occupancy=body.count, updated_at=now())
        store.put("room", room)
        event = {
            "id": uid(),
            "room_id": id,
            "count": body.count,
            "timestamp": now(),
            "source": "anonymous simulation",
            "identity": None,
        }
        store.put("spatial_event", event)
        store.audit(user["actor"], "spatial.occupancy", event)
        return room

    @app.get("/api/spatial/events")
    async def spatial_events(user=Depends(read)):
        return store.all("spatial_event")[-100:]

    @app.post("/api/simulation/scenario")
    async def scenario(body: Scenario, user=Depends(permit("admin"))):
        return simulator.scenario(body.kind, body.room_id)

    @app.post("/api/alerts/{id}/acknowledge")
    async def acknowledge(id: str, user=Depends(permit("admin"))):
        alert = entity("alert", id)
        alert.update(acknowledged=True, acknowledged_at=now())
        store.put("alert", alert)
        store.audit(user["actor"], "alert.acknowledged", {"id": id})
        return alert

    @app.put("/api/settings")
    async def settings(body: Settings, user=Depends(permit("admin"))):
        store.put("settings", {"id": "main", **body.model_dump()})
        if not body.autonomous:
            for task in store.all("task"):
                if task["workflow"] == "robot-mission" and task["state"] in (
                    "queued",
                    "running",
                ):
                    orchestrator.cancel(task["id"])
        store.audit(user["actor"], "settings.updated", body.model_dump())
        return store.get("settings", "main")

    @app.post("/api/emergency-stop")
    async def emergency_stop(user=Depends(permit("admin"))):
        settings = store.get("settings", "main")
        settings["autonomous"] = False
        store.put("settings", settings)
        for robot in store.all("robot"):
            robot.update(estop=True, status="emergency-stop")
            store.put("robot", robot)
        for task in store.all("task"):
            if task["state"] in ("queued", "running", "awaiting_approval"):
                orchestrator.cancel(task["id"])
        for zone in store.all("audio"):
            zone.update(microphone="muted", hardware_muted=True, playback="stopped")
            store.put("audio", zone)
        store.audit(user["actor"], "system.emergency_stop", {"simulated": True})
        return {
            "stopped": True,
            "scope": "simulated robots, autonomy, audio and workflows",
        }

    @app.post("/api/robots/{id}/reset")
    async def reset_robot(id: str, user=Depends(permit("control"))):
        robot = entity("robot", id)
        if robot["mission_id"]:
            raise HTTPException(409, "Wait for mission cancellation before resetting")
        robot.update(estop=False, status="idle", interlock=True)
        store.put("robot", robot)
        store.audit(user["actor"], "robot.reset", {"id": id, "simulated": True})
        return robot

    @app.post("/api/tasks")
    async def submit_task(body: TaskRequest, user=Depends(permit("tasks"))):
        return await orchestrator.submit(body.model_dump(), user["actor"], user["role"])

    @app.post("/api/tasks/{id}/cancel")
    async def cancel_task(id: str, user=Depends(permit("tasks"))):
        return orchestrator.cancel(id)

    @app.put("/api/research/schedule")
    async def schedule(body: Toggle, user=Depends(permit("admin"))):
        item = store.get("schedule", "research")
        item["enabled"] = body.enabled
        store.put("schedule", item)
        store.audit(user["actor"], "research.schedule", {"enabled": body.enabled})
        return item

    @app.post("/api/proposals")
    async def proposal(body: Proposal, user=Depends(permit("propose"))):
        data = {
            **body.model_dump(),
            "id": uid(),
            "state": "awaiting-plan-review",
            "created_at": now(),
            "branch": None,
            "checks": {"tests": "not-run", "static": "not-run", "security": "not-run"},
            "deployment": "unavailable",
            "protected_components": [
                "approval mechanism",
                "security policy",
                "hardware safeguards",
                "gateway boundary",
            ],
        }
        if any(
            any(
                term in component.lower()
                for term in ("policy", "approval", "safeguard", "security", "gateway")
            )
            for component in body.components
        ):
            raise HTTPException(
                403,
                "Protected components require a separate manual engineering process",
            )
        store.put("proposal", data)
        store.audit(
            user["actor"], "proposal.created", {"id": data["id"], "risk": body.risk}
        )
        return data

    @app.post("/api/proposals/{id}/review")
    async def review_proposal(
        id: str, body: ProposalAction, user=Depends(permit("admin"))
    ):
        data = entity("proposal", id)
        if data["state"] != "awaiting-plan-review":
            raise HTTPException(409, "Proposal was already reviewed")
        data.update(
            state="plan-approved" if body.action == "approve-plan" else "rejected",
            reviewed_at=now(),
            reviewed_by=user["actor"],
        )
        store.put("proposal", data)
        store.audit(
            user["actor"], "proposal.reviewed", {"id": id, "state": data["state"]}
        )
        return data

    @app.get("/api/diagnostics")
    async def diagnostics(user=Depends(read)):
        return {
            "database": "online",
            "audit_integrity": store.verify_audit(),
            "model": await models.health(),
            "queue_depth": orchestrator.queue.qsize(),
            "uptime_seconds": round(time.monotonic() - started),
            "storage": "SQLite WAL",
            "sensors": len(store.all("sensor")),
            "mode": "simulation",
            "physical_adapters": 0,
        }

    @app.get("/api/models")
    async def model_info(user=Depends(permit("admin"))):
        return {"configuration": models.config, "discovery": await models.discover()}

    @app.put("/api/models/configuration")
    async def model_config(body: ModelConfiguration, user=Depends(permit("admin"))):
        if chat_lock.locked():
            raise HTTPException(
                409, "Interrupt the active response before reconfiguring inference"
            )
        try:
            result = models.configure(body.model_dump())
        except ValueError:
            raise HTTPException(
                422, "Model endpoint must be a valid local URL"
            ) from None
        store.audit(
            user["actor"],
            "models.configured",
            {"provider": body.provider, "routes": body.routes},
        )
        return result

    @app.get("/api/memories/{id}/history")
    async def memory_history(id: str, user=Depends(permit("memory"))):
        entity("memory", id)
        return memory.history(id)

    @app.get("/api/memory-candidates")
    async def memory_candidates(user=Depends(permit("memory"))):
        return [
            c for c in store.latest("memory_candidate", 100) if c["expires_at"] > now()
        ]

    @app.post("/api/memory-candidates/{id}/review")
    async def review_candidate(id: str, body: Review, user=Depends(permit("memory"))):
        return memory.review(id, body.decision, user["actor"])

    @app.delete("/api/memory-candidates/{id}")
    async def delete_candidate(id: str, user=Depends(permit("memory"))):
        entity("memory_candidate", id)
        store.delete("memory_candidate", id)
        store.audit(user["actor"], "memory.candidate_deleted", {"id": id})
        return {"deleted": id}

    @app.get("/api/tasks/{id}")
    async def task_detail(id: str, user=Depends(permit("tasks"))):
        return entity("task", id)

    @app.post("/api/tasks/{id}/resume")
    async def resume_task(id: str, user=Depends(permit("tasks"))):
        return orchestrator.resume(id, user["actor"], user["role"])

    @app.post("/api/tasks/{id}/review")
    async def review_task(id: str, body: Review, user=Depends(permit("admin"))):
        return orchestrator.review(id, body.decision, user["actor"], user["role"])

    @app.post("/api/proactivity/evaluate")
    async def proactive_evaluate(user=Depends(permit("admin"))):
        return {"created": proactive.evaluate()}

    @app.post("/api/suggestions/{id}/dismiss")
    async def dismiss_suggestion(id: str, user=Depends(permit("admin"))):
        suggestion = entity("suggestion", id)
        suggestion["status"] = "dismissed"
        store.put("suggestion", suggestion)
        store.audit(user["actor"], "suggestion.dismissed", {"id": id})
        return suggestion

    # Canonical versioned routes retain dependency and validation contracts.
    for route in list(app.routes):
        if isinstance(route, APIRoute) and route.path.startswith("/api/"):
            route.include_in_schema = False
            app.add_api_route(
                "/api/v1" + route.path[4:],
                route.endpoint,
                methods=route.methods,
                name=route.name,
                include_in_schema=True,
            )

    assets = Path(os.getenv("JARVIS_WEB_ASSETS", str(ROOT / "web" / "dist-next")))
    if (assets / "assets").is_dir() and (assets / "index.html").is_file():
        app.mount("/assets", StaticFiles(directory=assets / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        async def frontend(path: str):
            if path.startswith("api/"):
                raise HTTPException(404, "API route not found")
            return FileResponse(assets / "index.html")

    return app
