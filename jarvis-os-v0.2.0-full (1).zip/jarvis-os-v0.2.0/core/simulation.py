"""Deterministic-shape, stochastic-value estate simulator. No hardware drivers."""

import math
import random
import time
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException
from .security import HAZARDOUS, require_permission
from .storage import now, uid

METRICS = {
    "temperature": ("°C", 22.4),
    "humidity": ("%", 44),
    "co2": ("ppm", 610),
    "co": ("ppm", 0),
    "pm1": ("µg/m³", 3),
    "pm25": ("µg/m³", 5),
    "pm10": ("µg/m³", 9),
    "voc": ("ppb", 95),
    "pressure": ("hPa", 1013),
    "smoke": ("state", 0),
    "heat": ("state", 0),
    "leak": ("state", 0),
    "soil": ("%", 42),
    "energy": ("kW", 1.2),
    "solar": ("kW", 4.8),
    "battery": ("%", 78),
    "wind": ("km/h", 8),
    "wind_direction": ("°", 240),
    "rainfall": ("mm", 0),
    "outdoor_temperature": ("°C", 18.3),
}
AGENTS = [
    ("conversation", "Conversation", "Local conversation and context", "chat"),
    ("planner", "Planning", "Bounded task decomposition", "read"),
    ("memory", "Memory retrieval", "Provenance-aware retrieval", "read"),
    ("monitor", "Home monitoring", "Telemetry and anomaly review", "read"),
    ("environment", "Environment", "Ventilation and efficiency advice", "read"),
    ("automation", "Automation", "Approved simulated workflows", "control"),
    ("robotics", "Robotics", "Simulated missions and interlocks", "control"),
    ("research", "Research", "Data-only external gateway", "research"),
    ("development", "Development", "Human-reviewed improvement proposals", "propose"),
    ("diagnostics", "Diagnostics", "Service and database health", "read"),
    ("security", "Security policy", "Authorization and audit verification", "read"),
]


def seed(store):
    if store.get("settings", "main"):
        return
    with store.transaction():
        store.put(
            "settings",
            {
                "id": "main",
                "autonomous": False,
                "personality": "precise",
                "proactivity": 35,
                "humor": 20,
                "voice": "neutral",
                "speech_rate": 1,
            },
        )
        rooms = [
            ("living", "Living room", 30, 35, 330, 235, 2),
            ("kitchen", "Kitchen", 370, 35, 250, 235, 1),
            ("office", "Study", 630, 35, 240, 235, 1),
            ("bedroom", "Primary suite", 30, 280, 330, 210, 0),
            ("hall", "Gallery", 370, 280, 250, 210, 0),
            ("garage", "Workshop", 630, 280, 240, 210, 0),
        ]
        for i, (id, name, x, y, w, h, occ) in enumerate(rooms):
            store.put(
                "room",
                {
                    "id": id,
                    "name": name,
                    "x": x,
                    "y": y,
                    "w": w,
                    "h": h,
                    "floor": 0,
                    "building": "Main residence",
                    "occupancy": occ,
                    "occupancy_source": "anonymous simulator",
                    "updated_at": now(),
                },
            )
            for metric, (unit, base) in METRICS.items():
                value = round(
                    base
                    + (
                        i * 0.3
                        if metric == "temperature"
                        else i * 27
                        if metric == "co2"
                        else 0
                    ),
                    1,
                )
                store.put(
                    "sensor",
                    {
                        "id": f"{id}-{metric}",
                        "room_id": id,
                        "metric": metric,
                        "unit": unit,
                        "value": value,
                        "base": value,
                        "status": "online",
                        "updated_at": now(),
                        "source": "simulated",
                    },
                )
                if metric in (
                    "temperature",
                    "co2",
                    "energy",
                    "solar",
                    "humidity",
                    "pm25",
                ):
                    for n in range(60):
                        stamp = (
                            datetime.now(timezone.utc)
                            - timedelta(seconds=(60 - n) * 30)
                        ).isoformat()
                        store.reading(
                            id,
                            metric,
                            max(0, round(value * (1 + 0.08 * math.sin(n / 8 + i)), 2)),
                            stamp,
                        )
            for kind, label, value in [
                ("light", "Lighting", 65),
                ("ventilation", "Ventilation", 30),
                ("thermostat", "Climate setpoint", 22),
            ]:
                store.put(
                    "device",
                    {
                        "id": f"{id}-{kind}",
                        "name": f"{name} · {label}",
                        "room_id": id,
                        "kind": kind,
                        "value": value,
                        "status": "online",
                        "adapter": "simulation",
                        "manual_until": 0,
                        "updated_at": now(),
                    },
                )
            store.put(
                "audio",
                {
                    "id": id,
                    "name": name,
                    "volume": 35,
                    "playback": "stopped",
                    "microphone": "muted",
                    "hardware_muted": True,
                    "route": "occupancy-aware",
                    "echo_cancellation": "interface-only",
                    "source": "simulated",
                },
            )
        for id, name, kind in [
            ("front-lock", "Front entrance lock", "lock"),
            ("pump", "Suppression pump", "suppression"),
            ("generator", "Backup generator", "generator"),
        ]:
            store.put(
                "device",
                {
                    "id": id,
                    "name": name,
                    "room_id": "garage",
                    "kind": kind,
                    "value": 0,
                    "status": "interlocked",
                    "adapter": "unavailable",
                    "manual_until": 0,
                    "updated_at": now(),
                },
            )
        store.put(
            "rule",
            {
                "id": "fresh-air",
                "name": "Fresh air, clear thinking",
                "room_id": "office",
                "metric": "co2",
                "operator": "above",
                "threshold": 900,
                "actions": [{"device_id": "office-ventilation", "value": 75}],
                "priority": 70,
                "trigger": "event",
                "interval_seconds": 300,
                "enabled": False,
                "last_run": 0,
                "cooldown_seconds": 60,
            },
        )
        store.put(
            "rule",
            {
                "id": "evening-light",
                "name": "A softer evening",
                "room_id": "living",
                "metric": "temperature",
                "operator": "above",
                "threshold": 0,
                "actions": [{"device_id": "living-light", "value": 35}],
                "priority": 40,
                "trigger": "interval",
                "interval_seconds": 1800,
                "enabled": False,
                "last_run": 0,
                "cooldown_seconds": 60,
            },
        )
        store.put(
            "memory",
            {
                "id": "welcome-memory",
                "kind": "spatial",
                "content": "The study is on the ground floor, east of the kitchen.",
                "source": "seeded digital twin",
                "confidence": 1,
                "verified": True,
                "created_at": now(),
                "updated_at": now(),
                "expires_at": (
                    datetime.now(timezone.utc) + timedelta(days=365)
                ).isoformat(),
                "retention_days": 365,
            },
        )
        for id, name, category, room in [
            ("rover", "Atlas · AMR", "mobile robot", "garage"),
            ("scout", "Scout · inspection", "inspection robot", "hall"),
        ]:
            store.put(
                "robot",
                {
                    "id": id,
                    "name": name,
                    "category": category,
                    "room_id": room,
                    "battery": 87 if id == "rover" else 64,
                    "status": "idle",
                    "progress": 0,
                    "estop": False,
                    "interlock": True,
                    "adapter": "simulation",
                    "mission_id": None,
                },
            )
        for id, name, description, permission in AGENTS:
            store.put(
                "agent",
                {
                    "id": id,
                    "name": name,
                    "description": description,
                    "permission": permission,
                    "status": "idle",
                    "runs": 0,
                },
            )
        store.audit("system", "system.initialized", {"mode": "simulation", "schema": 1})


class Control:
    def __init__(self, store):
        self.store = store

    def check(self, device_id, value, role="admin", automatic=False):
        require_permission(role, "control")
        d = self.store.get("device", device_id)
        if not d:
            raise HTTPException(404, "Device not found")
        if d["kind"] in HAZARDOUS or d["adapter"] != "simulation":
            raise HTTPException(
                403,
                "Hardware safeguard: hazardous or non-simulated equipment cannot be controlled",
            )
        if d["status"] != "online":
            raise HTTPException(409, "Device is unavailable")
        if automatic and not self.store.get("settings", "main")["autonomous"]:
            raise HTTPException(409, "Autonomous actions are disabled")
        if automatic and d["manual_until"] > time.time():
            raise HTTPException(409, "Manual override is active")
        if not 0 <= value <= 100 or (
            d["kind"] == "thermostat" and not 10 <= value <= 32
        ):
            raise HTTPException(422, "Value outside device operating bounds")
        return d

    def command(self, device_id, value, actor="admin", role="admin", automatic=False):
        with self.store.transaction():
            d = self.check(device_id, value, role, automatic)
            previous = d["value"]
            d.update(value=value, updated_at=now())
            if not automatic:
                d["manual_until"] = time.time() + 300
            self.store.put("device", d)
            self.store.audit(
                actor,
                "device.command",
                {
                    "device_id": device_id,
                    "previous": previous,
                    "value": value,
                    "simulated": True,
                },
            )
        return d


class Automation:
    def __init__(self, store, control):
        self.store, self.control = store, control

    def validate(self, rule):
        if not self.store.get("room", rule["room_id"]):
            raise HTTPException(404, "Room not found")
        ids = [a["device_id"] for a in rule["actions"]]
        if len(ids) != len(set(ids)):
            raise HTTPException(422, "A workflow may target each device only once")
        # Static validity, even when a manual override currently applies.
        for a in rule["actions"]:
            self.control.check(a["device_id"], a["value"])

    def run(self, rule, dry_run=True, automatic=False):
        record = {
            "id": uid(),
            "rule_id": rule["id"],
            "name": rule["name"],
            "timestamp": now(),
            "dry_run": dry_run,
            "steps": [],
            "status": "simulated" if dry_run else "completed",
        }
        try:
            self.validate(rule)
            # Single atomic transaction for simulator state + logs. Physical rollback
            # would need driver-specific compensation; never assume reversibility.
            with self.store.transaction():
                before = []
                for a in rule["actions"]:
                    d = self.control.check(
                        a["device_id"], a["value"], "automation", automatic
                    )
                    before.append({"device_id": d["id"], "value": d["value"]})
                    record["steps"].append({**a, "previous": d["value"]})
                if not dry_run:
                    for a in rule["actions"]:
                        d = self.store.get("device", a["device_id"])
                        d.update(value=a["value"], updated_at=now())
                        for step in record["steps"]:
                            if step["device_id"] == d["id"]:
                                step["applied_at"] = d["updated_at"]
                        if not automatic:
                            d["manual_until"] = time.time() + 300
                        self.store.put("device", d)
                    rule["last_run"] = time.time()
                    self.store.put("rule", rule)
                record["rollback"] = before
                self.store.put("run", record)
                self.store.audit(
                    "automation" if automatic else "admin",
                    "automation.dry_run" if dry_run else "automation.executed",
                    record,
                )
        except HTTPException as error:
            record.update(status="blocked", error=error.detail)
            self.store.put("run", record)
            self.store.audit(
                "automation",
                "automation.blocked",
                {"rule_id": rule["id"], "reason": error.detail},
            )
        return record

    def evaluate(self):
        claimed = set()
        for rule in sorted(self.store.all("rule"), key=lambda r: -r["priority"]):
            if not rule["enabled"]:
                continue
            s = self.store.get("sensor", f"{rule['room_id']}-{rule['metric']}")
            condition = (
                s
                and s["status"] == "online"
                and (
                    (s["value"] > rule["threshold"])
                    if rule["operator"] == "above"
                    else (s["value"] < rule["threshold"])
                )
            )
            due = (
                rule["trigger"] == "event"
                or time.time() - rule["last_run"] >= rule["interval_seconds"]
            )
            ids = {a["device_id"] for a in rule["actions"]}
            if not condition or ids & claimed:
                continue
            if time.time() - rule["last_run"] < rule["cooldown_seconds"]:
                claimed |= ids
                continue
            if due:
                # Reserve priority even if blocked; lower-priority rules must not
                # bypass this decision on this tick or during its cooldown.
                claimed |= ids
                self.run(rule, dry_run=False, automatic=True)
                # Back off blocked rules too, avoiding audit floods.
                rule["last_run"] = time.time()
                self.store.put("rule", rule)


def recommendations(store):
    result = []
    for room in store.all("room"):
        for metric, threshold, title, action in [
            (
                "co2",
                900,
                "Fresh air recommended",
                "Increase ventilation after checking outdoor air quality.",
            ),
            (
                "pm25",
                15,
                "Particle levels elevated",
                "Inspect filtration and indoor sources.",
            ),
            (
                "humidity",
                65,
                "Humidity is high",
                "Check ventilation and moisture sources.",
            ),
            ("temperature", 27, "Room is warm", "Review cooling and shading."),
        ]:
            s = store.get("sensor", f"{room['id']}-{metric}")
            if s["status"] == "online" and s["value"] > threshold:
                result.append(
                    {
                        "id": s["id"],
                        "room": room["name"],
                        "title": title,
                        "detail": action,
                        "value": s["value"],
                        "unit": s["unit"],
                        "source": "threshold rule; simulated telemetry",
                    }
                )
    return result


class Simulator:
    def __init__(self, store, automation):
        self.store, self.automation = store, automation
        self.ticks = 0

    def tick(self):
        self.ticks += 1
        with self.store.transaction():
            for s in self.store.all("sensor"):
                if s.get("scenario") or s["status"] != "online":
                    continue
                metric = s["metric"]
                device = self.store.get("device", f"{s['room_id']}-ventilation")
                adjustment = (
                    -max(0, device["value"] - 40) * 0.8 if metric == "co2" else 0
                )
                # Synthetic sensor noise only; never used for security material.
                noise = random.uniform(-0.008, 0.008)  # nosec B311
                variation = math.sin(self.ticks / 9 + len(s["id"])) * 0.025 + noise
                s.update(
                    value=round(max(0, s["base"] * (1 + variation) + adjustment), 2),
                    updated_at=now(),
                )
                self.store.put("sensor", s)
                if self.ticks % 3 == 0:
                    self.store.reading(s["room_id"], metric, s["value"])
            if self.ticks % 120 == 0:
                self.store.prune()
        self.automation.evaluate()

    def scenario(self, kind, room_id):
        if not self.store.get("room", room_id):
            raise HTTPException(404, "Room not found")
        if kind == "normal":
            for s in self.store.all("sensor"):
                s.pop("scenario", None)
                s.update(value=s["base"], status="online", updated_at=now())
                self.store.put("sensor", s)
            for d in self.store.all("device"):
                if d["adapter"] == "simulation":
                    d.update(status="online", updated_at=now())
                    self.store.put("device", d)
            for alert in self.store.all("alert"):
                if alert["status"] == "active":
                    alert.update(status="resolved", resolved_at=now())
                    self.store.put("alert", alert)
        else:
            if kind in ("network", "power"):
                for s in self.store.all("sensor"):
                    if s["room_id"] == room_id:
                        s.update(status="offline", scenario=kind)
                        self.store.put("sensor", s)
            if kind in ("network", "power", "equipment"):
                devices = [
                    d
                    for d in self.store.all("device")
                    if d["room_id"] == room_id and d["adapter"] == "simulation"
                ]
                for d in devices[:1] if kind == "equipment" else devices:
                    d.update(status="offline", updated_at=now())
                    self.store.put("device", d)
            metric, value = {
                "smoke": ("smoke", 1),
                "co": ("co", 85),
                "leak": ("leak", 1),
                "heat": ("temperature", 58),
                "wildfire": ("pm25", 150),
            }.get(kind, ("temperature", 22))
            if kind in ("smoke", "co", "leak", "heat", "wildfire"):
                s = self.store.get("sensor", f"{room_id}-{metric}")
                s.update(value=value, scenario=kind, updated_at=now())
                self.store.put("sensor", s)
                self.store.reading(room_id, metric, value)
            alert = {
                "id": uid(),
                "kind": kind,
                "room_id": room_id,
                "severity": "critical"
                if kind in ("smoke", "co", "heat")
                else "warning",
                "status": "active",
                "timestamp": now(),
                "source": "simulation",
                "message": f"Simulated {kind} event. Verify independently; follow the applicable emergency procedure.",
                "response": [
                    "Notify operator in command center",
                    "Require independent verification",
                    "No hardware actuation or emergency dispatch",
                ],
            }
            self.store.put("alert", alert)
        self.store.audit(
            "admin", "simulation.scenario", {"kind": kind, "room_id": room_id}
        )
        return {"kind": kind, "room_id": room_id, "simulated": True}
