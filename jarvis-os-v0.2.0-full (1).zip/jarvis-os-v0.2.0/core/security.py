import hashlib
import hmac
import os
import secrets
import time
from collections import defaultdict, deque
from pathlib import Path
from fastapi import HTTPException, Request


PERMISSIONS = {
    "admin": {
        "read",
        "chat",
        "memory",
        "control",
        "automate",
        "tasks",
        "admin",
        "propose",
    },
    "viewer": {"read"},
    "conversation": {"read", "chat"},
    "monitor": {"read"},
    "automation": {"read", "control"},
    "research": {"read", "research"},
    "planner": {"read"},
    "memory": {"memory.read"},
    "environment": {"read"},
    "diagnostics": {"read"},
    "security": {"read"},
    "robotics": {"read", "control"},
    "scheduler": {"schedule.research"},
}
PERMISSIONS["automation"].add("propose")
HAZARDOUS = {"lock", "suppression", "generator", "cnc", "robot-arm"}


def require_permission(role, permission):
    if permission not in PERMISSIONS.get(role, set()):
        raise HTTPException(403, "Permission denied")


class Auth:
    def __init__(self, runtime: Path):
        runtime.mkdir(parents=True, exist_ok=True)
        runtime.chmod(0o700)
        password = os.getenv("JARVIS_ADMIN_PASSWORD")
        path = runtime / "admin-password"
        if not password:
            if not path.exists():
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "w") as f:
                    f.write(secrets.token_urlsafe(24))
            password = path.read_text().strip()
        if len(password) < 12:
            raise RuntimeError(
                "JARVIS_ADMIN_PASSWORD must contain at least 12 characters"
            )
        self.salt = secrets.token_bytes(32)
        self.password_hash = hashlib.scrypt(
            password.encode(), salt=self.salt, n=16384, r=8, p=1
        )
        self.sessions = {}
        self.attempts = defaultdict(deque)

    def limit(self, key, count=120, window=60):
        clock = time.monotonic()
        q = self.attempts[key]
        while q and q[0] < clock - window:
            q.popleft()
        if len(q) >= count:
            raise HTTPException(429, "Rate limit exceeded; try again later")
        q.append(clock)
        # Bound inactive client bookkeeping; no persisted IP addresses.
        if len(self.attempts) > 5000:
            for old in list(self.attempts):
                if not self.attempts[old] or self.attempts[old][-1] < clock - 900:
                    del self.attempts[old]

    def login(self, username, password, ip):
        self.limit("login:" + ip, 8, 900)
        candidate = hashlib.scrypt(password.encode(), salt=self.salt, n=16384, r=8, p=1)
        if (
            not hmac.compare_digest(candidate, self.password_hash)
            or username != "admin"
        ):
            raise HTTPException(401, "Invalid credentials")
        token = secrets.token_urlsafe(32)
        self.sessions = {
            k: v for k, v in self.sessions.items() if v["expires"] > time.time()
        }
        session = {
            "actor": "admin",
            "role": "admin",
            "csrf": secrets.token_urlsafe(24),
            "expires": time.time() + 28800,
        }
        self.sessions[token] = session
        return token, session

    def authenticate(self, request: Request, permission="read"):
        token = request.cookies.get("jarvis_session", "")
        session = self.sessions.get(token)
        if not session or session["expires"] < time.time():
            raise HTTPException(401, "Sign in required")
        self.limit("session:" + token)
        require_permission(session["role"], permission)
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            if not hmac.compare_digest(
                request.headers.get("x-csrf-token", ""), session["csrf"]
            ):
                raise HTTPException(403, "Invalid CSRF token")
        return session
