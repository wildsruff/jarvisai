"""Local inference with explicit identity, bounded streams and cancellable deadlines."""

import asyncio
import contextlib
import ipaddress
import json
import os
import time
from urllib.parse import urlparse
import httpx
from .storage import now, uid


def validate_local_url(url):
    parsed = urlparse(url)
    if (
        parsed.scheme not in ("http", "https")
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("Invalid local model URL")
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError("Invalid local model port")
    host = parsed.hostname or ""
    if host != "localhost":
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            raise ValueError(
                "Local model host must be localhost or a literal private IP"
            ) from None
        networks = ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")
        if address.is_link_local or not (
            address.is_loopback
            or any(address in ipaddress.ip_network(n) for n in networks)
        ):
            raise ValueError("Model endpoint must be on a private local network")
    return url.rstrip("/")


def bounded_context(messages, max_chars=14000):
    system = [
        {**m, "content": m["content"][: max_chars // 2]}
        for m in messages
        if m["role"] == "system"
    ][:1]
    remaining = max_chars - sum(len(m["content"]) for m in system)
    selected = []
    for msg in reversed([m for m in messages if m["role"] != "system"]):
        if len(msg["content"]) > remaining:
            if not selected and remaining > 0:
                selected.append({**msg, "content": msg["content"][-remaining:]})
            break
        selected.append(msg)
        remaining -= len(msg["content"])
    return system + list(reversed(selected))


def safe_error(exc):
    if isinstance(exc, (TimeoutError, httpx.TimeoutException)):
        return {
            "code": "inference_timeout",
            "message": "Local inference exceeded its connection, idle, or total deadline.",
        }
    if isinstance(exc, httpx.ConnectError):
        return {
            "code": "model_unreachable",
            "message": "Cannot connect to the configured local inference server.",
        }
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        return {
            "code": "model_not_found" if status == 404 else "model_http_error",
            "message": f"Local inference server returned HTTP {status}.",
            "http_status": status,
        }
    return {
        "code": "model_protocol_error",
        "message": "The local server returned an invalid, incomplete, or oversized stream.",
    }


async def interruptible(stream, cancel_event):
    """Interrupt a pending __anext__, not just the next available token."""
    waiter = asyncio.create_task(cancel_event.wait())
    pending = None
    try:
        while True:
            pending = asyncio.create_task(anext(stream))
            done, _ = await asyncio.wait(
                (pending, waiter), return_when=asyncio.FIRST_COMPLETED
            )
            if waiter in done:
                return
            try:
                event = pending.result()
            except StopAsyncIteration:
                return
            yield event
    finally:
        # Cancel the pending anext before aclose to avoid concurrent generator use.
        for job in (pending, waiter):
            if job:
                if not job.done():
                    job.cancel()
                with contextlib.suppress(asyncio.CancelledError, StopAsyncIteration):
                    await job
        await stream.aclose()


class Models:
    def __init__(self, store):
        self.store = store
        self.config = store.get("model_config", "main") or {
            "id": "main",
            "provider": os.getenv("JARVIS_MODEL_PROVIDER", "mock"),
            "url": os.getenv("JARVIS_MODEL_URL", "http://127.0.0.1:11434"),
            "routes": {
                task: os.getenv(f"JARVIS_MODEL_{task.upper()}", default)
                for task, default in [
                    ("conversation", "llama3.2:3b"),
                    ("coding", "qwen2.5-coder:7b"),
                    ("vision", "llava:7b"),
                ]
            },
            "context_chars": 14000,
            "connect_timeout": 3,
            "idle_timeout": 15,
            "total_timeout": 60,
            "connect_retries": 1,
            "max_output_tokens": 2048,
        }
        self.configure(self.config, persist=False)
        self.last_health = {
            "status": "mock" if self.provider == "mock" else "unchecked",
            "provider": self.provider,
        }

    def configure(self, config, persist=True):
        from .contracts import ModelConfiguration

        validated = ModelConfiguration.model_validate(
            {k: v for k, v in config.items() if k != "id"}
        ).model_dump()
        validated["url"] = validate_local_url(validated["url"])
        self.config = {"id": "main", **validated}
        self.provider, self.url, self.routes = (
            validated["provider"],
            validated["url"],
            validated["routes"],
        )
        self.last_health = {
            "status": "mock" if self.provider == "mock" else "unchecked",
            "provider": self.provider,
        }
        if persist:
            self.store.put("model_config", self.config)
        return self.config

    async def discover(self):
        config = json.loads(json.dumps(self.config))
        provider, url = config["provider"], config["url"]
        if provider == "mock":
            return {
                "provider": "mock",
                "status": "mock",
                "models": [{"id": "deterministic-simulator", "simulation": True}],
                "checked_at": now(),
            }
        try:
            async with asyncio.timeout(config["connect_timeout"] + 2):
                async with httpx.AsyncClient(
                    timeout=config["connect_timeout"],
                    trust_env=False,
                    follow_redirects=False,
                ) as client:
                    response = await client.get(
                        url + ("/api/tags" if provider == "ollama" else "/v1/models")
                    )
                    response.raise_for_status()
                    if len(response.content) > 1000000:
                        raise ValueError("Discovery response too large")
                    data = response.json()
                    if not isinstance(data, dict):
                        raise ValueError("Invalid model discovery")
                    items = data.get("models" if provider == "ollama" else "data", [])
                    if not isinstance(items, list) or any(
                        not isinstance(item, dict) for item in items
                    ):
                        raise ValueError("Invalid model list")
                    models = [
                        {
                            "id": str(m.get("name") or m.get("id"))[:200],
                            "simulation": False,
                        }
                        for m in items[:200]
                        if m.get("name") or m.get("id")
                    ]
            observed = {
                "provider": provider,
                "status": "online",
                "checked_at": now(),
            }
            if self.config == config:
                self.last_health = observed
            return {**observed, "models": models}
        except (httpx.HTTPError, ValueError, TypeError, TimeoutError) as exc:
            observed = {
                "provider": provider,
                "status": "offline",
                "checked_at": now(),
                "error": safe_error(exc),
            }
            if self.config == config:
                self.last_health = observed
            return {**observed, "models": []}

    async def health(self):
        observed = await self.discover()
        return {k: v for k, v in observed.items() if k != "models"}

    async def _remote(self, messages, task, config):
        provider = config["provider"]
        payload = {
            "model": config["routes"][task],
            "messages": messages,
            "stream": True,
        }
        if provider == "ollama":
            payload["options"] = {"num_predict": config["max_output_tokens"]}
        else:
            payload.update(
                max_tokens=config["max_output_tokens"],
                stream_options={"include_usage": True},
            )

        async def lines(response):
            buffer = b""
            async for chunk in response.aiter_bytes():
                buffer += chunk
                if len(buffer) > 131072:
                    raise ValueError("Oversized stream frame")
                while b"\n" in buffer:
                    raw, buffer = buffer.split(b"\n", 1)
                    yield raw.decode("utf-8").strip()
            if buffer.strip():
                yield buffer.decode("utf-8").strip()

        for attempt in range(config["connect_retries"] + 1):
            began = False
            try:
                async with httpx.AsyncClient(
                    timeout=httpx.Timeout(
                        config["idle_timeout"], connect=config["connect_timeout"]
                    ),
                    trust_env=False,
                    follow_redirects=False,
                ) as client:
                    async with client.stream(
                        "POST",
                        config["url"]
                        + (
                            "/api/chat"
                            if provider == "ollama"
                            else "/v1/chat/completions"
                        ),
                        json=payload,
                    ) as response:
                        began = True
                        response.raise_for_status()
                        terminal = False
                        output_chars = 0
                        async for line in lines(response):
                            if not line or line.startswith((":", "event:", "id:")):
                                continue
                            if line == "data: [DONE]":
                                terminal = True
                                yield {"type": "finish", "reason": "stop"}
                                continue
                            data = json.loads(line.removeprefix("data: "))
                            if not isinstance(data, dict) or "error" in data:
                                raise ValueError("Provider error")
                            if provider == "ollama":
                                delta = data.get("message", {}).get("content", "")
                                terminal = terminal or data.get("done") is True
                                usage = {
                                    "input_tokens": data.get("prompt_eval_count"),
                                    "output_tokens": data.get("eval_count"),
                                }
                                if data.get("done") is True:
                                    yield {
                                        "type": "finish",
                                        "reason": data.get("done_reason", "stop"),
                                    }
                            else:
                                choice = (data.get("choices") or [{}])[0]
                                delta = choice.get("delta", {}).get("content") or ""
                                terminal = (
                                    terminal or choice.get("finish_reason") is not None
                                )
                                usage = {
                                    "input_tokens": (data.get("usage") or {}).get(
                                        "prompt_tokens"
                                    ),
                                    "output_tokens": (data.get("usage") or {}).get(
                                        "completion_tokens"
                                    ),
                                }
                                if choice.get("finish_reason") is not None:
                                    yield {
                                        "type": "finish",
                                        "reason": choice["finish_reason"],
                                    }
                            if any(v is not None for v in usage.values()):
                                if any(
                                    v is not None
                                    and (type(v) is not int or not 0 <= v <= 10000000)
                                    for v in usage.values()
                                ):
                                    raise ValueError("Invalid usage")
                                yield {"type": "usage", **usage}
                            if delta:
                                if not isinstance(delta, str):
                                    raise ValueError("Invalid token")
                                output_chars += len(delta)
                                if output_chars > 64000:
                                    raise ValueError("Output limit exceeded")
                                yield {"type": "token", "text": delta}
                        if not terminal:
                            raise ValueError("Stream ended without completion")
                return
            except (httpx.ConnectError, httpx.ConnectTimeout):
                if began or attempt >= config["connect_retries"]:
                    raise
                yield {
                    "type": "status",
                    "provider": provider,
                    "state": "reconnecting",
                    "attempt": attempt + 2,
                }
                await asyncio.sleep(0.05)

    async def stream(self, messages, task="conversation"):
        config = json.loads(json.dumps(self.config))
        original_chars = sum(len(m["content"]) for m in messages)
        messages = bounded_context(messages, config["context_chars"])
        start = time.monotonic()
        stat = {
            "id": uid(),
            "timestamp": now(),
            "provider": config["provider"],
            "requested_provider": config["provider"],
            "model": config["routes"][task]
            if config["provider"] != "mock"
            else "deterministic-simulator",
            "task": task,
            "status": "running",
            "fallback": False,
            "error": None,
            "input_tokens": None,
            "output_tokens": None,
            "token_counts": "estimated",
            "estimated_input_tokens": sum(len(m["content"]) for m in messages) // 4,
            "estimated_output_tokens": 0,
            "first_token_ms": None,
            "finish_reason": None,
            "context_chars": sum(len(m["content"]) for m in messages),
            "context_truncated": sum(len(m["content"]) for m in messages)
            < original_chars,
        }
        queue = asyncio.Queue(maxsize=16)
        self.store.put("inference", {**stat, "latency_ms": 0})

        async def produce():
            try:
                async with asyncio.timeout(config["total_timeout"]):
                    if config["provider"] == "mock":
                        text = self.mock(messages[-1]["content"])
                        for word in text.split(" "):
                            await asyncio.sleep(0.008)
                            await queue.put({"type": "token", "text": word + " "})
                    else:
                        async for event in self._remote(messages, task, config):
                            await queue.put(event)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await queue.put({"type": "error", "error": safe_error(exc)})
            finally:
                # Cancellation must not block on a full queue during disconnect.
                if not asyncio.current_task().cancelling():
                    await queue.put(None)

        worker = asyncio.create_task(produce())
        output = ""
        try:
            yield {
                "type": "status",
                "provider": config["provider"],
                "model": stat["model"],
                "simulation": config["provider"] == "mock",
                "state": "generating",
            }
            while True:
                event = await queue.get()
                if event is None:
                    break
                if event["type"] == "token":
                    if stat["first_token_ms"] is None:
                        stat["first_token_ms"] = round(
                            (time.monotonic() - start) * 1000
                        )
                    output += event["text"]
                elif event["type"] == "usage":
                    for key in ("input_tokens", "output_tokens"):
                        if event.get(key) is not None:
                            stat[key] = event[key]
                    continue
                elif event["type"] == "finish":
                    # Preserve a length/tool stop even if a later SSE [DONE] arrives.
                    if stat["finish_reason"] is None or event["reason"] != "stop":
                        stat["finish_reason"] = str(event["reason"])[:100]
                    continue
                elif event["type"] == "error":
                    stat.update(status="failed", error=event["error"])
                yield event
            if not output and stat["status"] != "failed":
                stat.update(
                    status="failed",
                    error={
                        "code": "model_empty_response",
                        "message": "Local model completed without text.",
                    },
                )
                yield {"type": "error", "error": stat["error"]}
            if stat["status"] == "running":
                stat["status"] = "completed"
        finally:
            worker.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await worker
            if stat["status"] == "running":
                stat["status"] = "cancelled"
            stat.update(
                latency_ms=round((time.monotonic() - start) * 1000),
                estimated_output_tokens=len(output) // 4,
                token_counts="provider-reported"
                if stat["input_tokens"] is not None
                and stat["output_tokens"] is not None
                else "estimated",
            )
            self.store.put("inference", stat)
        yield {"type": "done", "metrics": stat}

    def mock(self, message):
        lower = message.lower()
        settings = self.store.get("settings", "main")
        prefix = {
            "precise": "",
            "warm": "Of course. ",
            "rustic": "Well now, let's take a look. ",
        }[settings["personality"]]
        if any(w in lower for w in ["status", "estate", "home", "overview"]):
            rooms = self.store.all("room")
            alerts = [a for a in self.store.all("alert") if a["status"] == "active"]
            text = f"The simulated estate has {len(rooms)} rooms, {sum(r['occupancy'] for r in rooms)} anonymous occupancy detections, and {len(alerts)} active alerts. Autonomous actions are {'enabled' if settings['autonomous'] else 'disabled'}. All device data is simulated."
        elif any(w in lower for w in ["air", "co2", "temperature", "environment"]):
            readings = [s for s in self.store.all("sensor") if s["metric"] == "co2"]
            high = max(readings, key=lambda s: s["value"])
            text = f"The highest simulated CO₂ reading is {high['value']:.0f} ppm in {self.store.get('room', high['room_id'])['name']}. I recommend reviewing trends before changing ventilation. You can inspect sensor history in Environment and dry-run an approved rule in Automations."
        elif any(w in lower for w in ["turn", "set ", "activate", "unlock", "run "]):
            text = "Chat has no control privileges. Use the Devices or Automations controls to review and authorize a simulated action. Hazardous equipment remains interlocked."
        elif "memory" in lower or "remember" in lower:
            text = "You can add a memory explicitly in Memory, with its source, confidence, verification status, and retention period. I do not silently save inferred preferences as facts."
        else:
            text = "I am running the local mock inference adapter. I can summarize the simulated estate, air quality, and control boundaries. Configure Ollama or an OpenAI-compatible local endpoint for open-ended conversation. What would you like to inspect?"
        return prefix + text
