"""Future driver contracts. Declaring a protocol does not implement hardware.

Adapters belong behind Control and must never be handed directly to an agent.
Every real implementation requires enrollment, host isolation and hardware review.
"""

from dataclasses import dataclass
from typing import AsyncIterator, Literal, Protocol


@dataclass(frozen=True)
class TelemetryEvent:
    device_id: str
    room_id: str
    metric: str
    value: float
    unit: str
    timestamp: str
    provenance: str
    quality: Literal["measured", "simulated", "uncertain"]


@dataclass(frozen=True)
class AuthorizedCommand:
    """Capability would be issued by a separate control authority in production."""

    request_id: str
    device_id: str
    actor: str
    action: str
    value: float
    expires_at: str
    approval_id: str | None = None


class DeviceAdapter(Protocol):
    async def health(self) -> dict: ...
    async def observe(self) -> AsyncIterator[TelemetryEvent]: ...
    async def execute(self, command: AuthorizedCommand) -> dict: ...


class AudioAdapter(Protocol):
    async def hardware_mute_state(self, zone_id: str) -> bool: ...
    async def transcribe_local(self, zone_id: str, samples: bytes) -> str: ...
    async def speak_local(self, zone_id: str, text: str, voice: str) -> None: ...
    async def interrupt(self, zone_id: str) -> None: ...


class RobotAdapter(Protocol):
    async def health(self, robot_id: str) -> dict: ...
    async def check_interlocks(self, robot_id: str) -> bool: ...
    async def mission(self, command: AuthorizedCommand) -> AsyncIterator[dict]: ...
    async def emergency_stop(self, robot_id: str) -> None: ...


# These are deliberately unavailable; the control service denies non-simulation
# adapters. No placeholder success response is exposed as real functionality.
PLANNED_INTEGRATIONS = (
    "mqtt",
    "home-assistant",
    "matter",
    "zigbee",
    "zwave",
    "bluetooth",
    "wired",
    "ros2",
    "cnc",
    "3d-printer",
)
