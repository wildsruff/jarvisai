from typing import Literal, Annotated
from pydantic import BaseModel, Field, ConfigDict


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Login(Input):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class Chat(Input):
    message: str = Field(min_length=1, max_length=8000)
    conversation_id: str = Field(default="main", pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    task: Literal["conversation", "coding", "vision"] = "conversation"


class Memory(Input):
    kind: Literal["working", "episodic", "semantic", "spatial", "procedural"]
    content: str = Field(min_length=1, max_length=4000)
    source: str = Field(default="user", min_length=1, max_length=200)
    confidence: float = Field(default=1, ge=0, le=1)
    verified: bool = False
    sensitive: bool = False
    retention_days: int = Field(default=30, ge=1, le=3650)


class DeviceCommand(Input):
    value: float = Field(ge=0, le=100)


class RuleAction(Input):
    device_id: str = Field(max_length=64)
    value: float = Field(ge=0, le=100)


class Rule(Input):
    name: str = Field(min_length=1, max_length=100)
    room_id: str = Field(max_length=64)
    metric: Literal["temperature", "humidity", "co2", "pm25", "leak", "energy"] = "co2"
    operator: Literal["above", "below"] = "above"
    threshold: float = Field(ge=0, le=10000)
    actions: list[RuleAction] = Field(min_length=1, max_length=8)
    priority: int = Field(default=50, ge=1, le=100)
    trigger: Literal["event", "interval"] = "event"
    interval_seconds: int = Field(default=300, ge=30, le=86400)
    enabled: bool = False


class Toggle(Input):
    enabled: bool


class AudioCommand(Input):
    volume: int = Field(ge=0, le=100)
    playback: Literal["stopped", "ambient", "announcement"]
    microphone: Literal["muted", "push-to-talk", "always-listening"]
    hardware_muted: bool


class Settings(Input):
    autonomous: bool
    personality: Literal["precise", "warm", "rustic"] = "precise"
    proactivity: int = Field(default=35, ge=0, le=100)
    humor: int = Field(default=20, ge=0, le=100)
    voice: Literal["neutral", "warm", "bright"] = "neutral"
    speech_rate: float = Field(default=1, ge=0.5, le=2)
    response_style: Literal["concise", "balanced", "detailed"] = "balanced"
    extract_memories: bool = True
    memory_retention_days: int = Field(default=30, ge=1, le=3650)


class Scenario(Input):
    kind: Literal[
        "normal",
        "smoke",
        "co",
        "leak",
        "power",
        "network",
        "heat",
        "wildfire",
        "intrusion",
        "equipment",
    ]
    room_id: str = "kitchen"


class Occupancy(Input):
    count: int = Field(ge=0, le=20)


class TaskRequest(Input):
    workflow: Literal[
        "estate-review", "research", "diagnostics", "robot-mission", "comfort-plan"
    ]
    subject: str = Field(
        default="Local-first home intelligence", min_length=1, max_length=500
    )
    robot_id: str | None = None
    room_id: str | None = None


class Proposal(Input):
    title: str = Field(min_length=5, max_length=120)
    description: str = Field(min_length=10, max_length=5000)
    components: list[str] = Field(min_length=1, max_length=10)
    risk: Literal["low", "medium", "high"] = "medium"


class ProposalAction(Input):
    action: Literal["approve-plan", "reject"]


class ModelConfiguration(Input):
    provider: Literal["mock", "ollama", "openai-local"] = "mock"
    url: str = Field(default="http://127.0.0.1:11434", max_length=300)
    routes: dict[
        Literal["conversation", "coding", "vision"],
        Annotated[str, Field(min_length=1, max_length=200)],
    ] = Field(min_length=3, max_length=3)
    context_chars: int = Field(default=14000, ge=2048, le=128000)
    connect_timeout: float = Field(default=3, ge=0.05, le=15)
    idle_timeout: float = Field(default=15, ge=0.05, le=120)
    total_timeout: float = Field(default=60, ge=0.05, le=300)
    connect_retries: int = Field(default=1, ge=0, le=2)
    max_output_tokens: int = Field(default=2048, ge=16, le=8192)


class Review(Input):
    decision: Literal["approve", "reject"]
