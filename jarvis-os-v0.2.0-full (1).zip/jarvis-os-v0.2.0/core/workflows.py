"""Bounded, observable workflows. Steps are registered code, never model output."""

import asyncio
import contextlib
import hashlib
import hmac
import json
import os
import time
from uuid import uuid4
import httpx
from fastapi import HTTPException
from .models import validate_local_url
from .simulation import recommendations
from .storage import now, uid

WORKFLOWS = {
    "estate-review": ["security", "memory", "monitor", "environment", "planner"],
    "research": ["security", "research", "planner"],
    "diagnostics": ["security", "diagnostics"],
    "robot-mission": ["security", "robotics"],
}


class ExternalGateway:
    def __init__(self):
        self.url = validate_local_url(
            os.getenv("JARVIS_GATEWAY_URL", "http://127.0.0.1:8100")
        )
        self.key = os.getenv("JARVIS_GATEWAY_KEY", "")

    async def research(self, subject):
        if not self.key:
            return {
                "mode": "offline",
                "trust": "untrusted-data",
                "summary": "Gateway is not configured. This is a local research plan, not a completed web search.",
                "sources": [],
                "next_steps": [
                    f"Review official documentation related to {subject}.",
                    "Compare local operation, maintenance, and security requirements.",
                    "Request human review before proposing an integration.",
                ],
            }
        stamp = str(int(time.time()))
        nonce = uuid4().hex
        body = json.dumps(
            {"scope": "research", "subject": subject},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        signature = hmac.new(
            self.key.encode(),
            stamp.encode() + b"." + nonce.encode() + b"." + body,
            hashlib.sha256,
        ).hexdigest()
        async with httpx.AsyncClient(
            timeout=6, trust_env=False, follow_redirects=False
        ) as client:
            response = await client.post(
                self.url + "/v1/research",
                content=body,
                headers={
                    "content-type": "application/json",
                    "x-timestamp": stamp,
                    "x-nonce": nonce,
                    "x-signature": signature,
                },
            )
            response.raise_for_status()
        signature = response.headers.get("x-signature", "")
        expected = hmac.new(
            self.key.encode(), nonce.encode() + b"." + response.content, hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(signature, expected):
            raise ValueError("Invalid gateway response signature")
        if len(response.content) > 50000:
            raise ValueError("Gateway response too large")
        from gateway.contracts import ResearchResult

        result = ResearchResult.model_validate(response.json()).model_dump(mode="json")
        # Authentication establishes transport provenance, not instruction trust.
        result["trust"] = "untrusted-data"
        return result


# Registered decomposition is code-owned; text and model output cannot add handlers.
WORKFLOWS["comfort-plan"] = [
    "security",
    "planner",
    "memory",
    "monitor",
    "environment",
    "automation",
]
REQUIRED = {
    "security": "read",
    "planner": "read",
    "memory": "memory.read",
    "monitor": "read",
    "environment": "read",
    "diagnostics": "read",
    "research": "research",
    "robotics": "control",
    "automation": "propose",
}


def validate_result(agent, output):
    required = {
        "security": {"policy"},
        "planner": {"summary", "proposals_only"},
        "memory": {"method", "memories"},
        "monitor": {"readings", "active_alerts"},
        "environment": {"execution_privileges"},
        "diagnostics": {"database", "audit_chain"},
        "research": {"mode", "trust", "sources"},
        "robotics": {"simulated", "progress"},
        "automation": {"rule_id", "device_actions", "enabled"},
    }
    keys = (
        {"evidence", "draft_rule"}
        if agent == "environment"
        and isinstance(output, dict)
        and "draft_rule" in output
        else required[agent]
    )
    if (
        not isinstance(output, dict)
        or not keys <= output.keys()
        or len(json.dumps(output, allow_nan=False)) > 50000
    ):
        raise ValueError("Invalid specialist output contract")
    if agent == "research" and output["trust"] != "untrusted-data":
        raise ValueError("Research data cannot become trusted instructions")
    if agent == "automation" and (output["enabled"] or output["device_actions"] != 0):
        raise ValueError("Routine publication cannot actuate devices")


class Orchestrator:
    def __init__(self, store, models):
        from .memory import MemoryService

        self.store, self.models = store, models
        self.memory = MemoryService(store, models)
        self.queue = asyncio.Queue(maxsize=50)
        self.cancelled = set()
        self.running = {}
        self.timeout_seconds = 30
        self.gateway = ExternalGateway()

    def event(self, task, event, summary, agent="orchestrator", payload=None):
        record = {
            "timestamp": now(),
            "agent": agent,
            "event": event,
            "summary": summary,
            "payload": payload or {},
        }
        task["timeline"] = (task.get("timeline", []) + [record])[-100:]
        task["updated_at"] = now()
        with self.store.transaction():
            self.store.db.execute(
                "INSERT INTO workflow_events(task_id,timestamp,agent,event,summary,payload) VALUES(?,?,?,?,?,?)",
                (
                    task["id"],
                    record["timestamp"],
                    agent,
                    event,
                    summary,
                    json.dumps(record["payload"]),
                ),
            )
            self.store.put("task", task)
        return task

    async def submit(self, request, actor="admin", role="admin"):
        from .security import require_permission

        if role == "scheduler":
            require_permission(role, "schedule.research")
            if request["workflow"] != "research":
                raise HTTPException(403, "Scheduler may request research only")
        else:
            require_permission(role, "tasks")
        if request["workflow"] not in WORKFLOWS:
            raise HTTPException(422, "Unknown workflow")
        if (
            request["workflow"] == "comfort-plan"
            and request.get("room_id")
            and not self.store.get("room", request["room_id"])
        ):
            raise HTTPException(404, "Room not found")
        if self.queue.full():
            raise HTTPException(429, "Workflow queue is full")
        if request["workflow"] == "robot-mission":
            require_permission(role, "control")
            robot = self.store.get("robot", request.get("robot_id"))
            if not robot or not self.store.get("room", request.get("room_id")):
                raise HTTPException(404, "Robot or destination not found")
            if robot["estop"] or not robot["interlock"] or robot["status"] != "idle":
                raise HTTPException(409, "Robot is stopped, busy, or interlocked")
            if not self.store.get("settings", "main")["autonomous"]:
                raise HTTPException(
                    409, "Enable autonomous simulation before assigning a mission"
                )
            if robot["battery"] < 20:
                raise HTTPException(409, "Insufficient robot battery")
        steps = [
            {
                "id": f"s{i + 1}",
                "agent": agent,
                "delegated_by": "operator"
                if i == 0 or agent == "planner"
                else "planner",
                "depends_on": [] if i == 0 else [f"s{i}"],
                "permission": REQUIRED[agent],
                "replay_safe": agent != "robotics",
                "state": "pending",
            }
            for i, agent in enumerate(WORKFLOWS[request["workflow"]])
        ]
        task = {
            **request,
            "subject": request.get("subject", "Estate review"),
            "id": uid(),
            "actor": actor,
            "owner_role": role,
            "state": "queued",
            "created_at": now(),
            "updated_at": now(),
            "steps": steps,
            "context": {
                "subject": request.get("subject", "Estate review"),
                "outputs": {},
            },
            "plan": [
                {
                    k: s[k]
                    for k in (
                        "id",
                        "agent",
                        "delegated_by",
                        "depends_on",
                        "permission",
                        "replay_safe",
                    )
                }
                for s in steps
            ],
            "timeline": [],
            "result": None,
            "error": None,
            "timeout_seconds": self.timeout_seconds,
            "attempts": 1,
        }
        with self.store.transaction():
            self.event(
                task,
                "queued",
                "Registered specialists assigned a bounded, ordered plan.",
            )
            if request["workflow"] == "robot-mission":
                robot.update(status="reserved", mission_id=task["id"])
                self.store.put("robot", robot)
            self.store.audit(
                actor, "task.queued", {"id": task["id"], "workflow": task["workflow"]}
            )
        self.queue.put_nowait(task["id"])
        return task

    def cancel(self, id):
        task = self.store.get("task", id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task["state"] not in (
            "queued",
            "running",
            "awaiting_approval",
            "interrupted",
        ):
            raise HTTPException(409, "Task is already terminal")
        if task["state"] in ("queued", "running"):
            self.cancelled.add(id)
        if id in self.running:
            self.running[id].cancel()
        task["state"] = "cancelled"
        self.event(
            task,
            "cancelled",
            "Operator cancelled this workflow; no remaining steps may execute.",
        )
        self.store.audit("admin", "task.cancelled", {"id": id})
        return task

    def digest(self, task):
        return hashlib.sha256(
            json.dumps(
                {
                    "id": task["id"],
                    "plan": task["plan"],
                    "draft": task["context"].get("draft_rule"),
                },
                sort_keys=True,
            ).encode()
        ).hexdigest()

    def review(self, id, decision, actor="admin", role="admin"):
        from .security import require_permission

        require_permission(role, "admin")
        task = self.store.get("task", id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task["state"] != "awaiting_approval":
            raise HTTPException(409, "Task is not awaiting approval")
        if task["checkpoint"]["digest"] != self.digest(task):
            raise HTTPException(409, "Plan changed; approval checkpoint is invalid")
        if decision == "reject":
            task["state"] = "rejected"
            self.event(task, "rejected", "Operator rejected the proposed routine.")
        else:
            if self.queue.full():
                raise HTTPException(429, "Workflow queue is full")
            task.update(
                state="queued",
                approval={
                    "actor": actor,
                    "timestamp": now(),
                    "digest": self.digest(task),
                },
            )
            self.event(
                task,
                "approved",
                "Human approved publishing this exact draft as a disabled routine.",
            )
            self.queue.put_nowait(id)
        self.store.audit(actor, "task.approval", {"id": id, "decision": decision})
        return task

    def resume(self, id, actor="admin", role="admin"):
        from .security import require_permission

        require_permission(role, "tasks")
        task = self.store.get("task", id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task["state"] not in ("interrupted", "failed", "timed_out"):
            raise HTTPException(409, "Only interrupted or failed tasks can be resumed")
        if task["workflow"] == "robot-mission" or not task.get("plan"):
            raise HTTPException(
                409, "This workflow cannot be replayed; submit a new authorized task"
            )
        if task.get("attempts", 1) >= 3:
            raise HTTPException(
                409, "Recovery limit reached; submit a new reviewed task"
            )
        if self.queue.full():
            raise HTTPException(429, "Workflow queue is full")
        for step in task["steps"]:
            if step["state"] != "completed":
                step["state"] = "pending"
        task.update(state="queued", error=None, attempts=task.get("attempts", 1) + 1)
        self.event(
            task,
            "resumed",
            "Operator resumed replay-safe stages; completed outputs are retained as timestamped evidence.",
        )
        self.queue.put_nowait(id)
        self.store.audit(actor, "task.resumed", {"id": id})
        return task

    def recover(self):
        for task in self.store.all("task"):
            if task["state"] in ("queued", "running"):
                self.finish(
                    task["id"],
                    "interrupted",
                    "Core restarted; explicit resume required for replay-safe stages",
                )
                self.release_robot(task["id"])

    async def worker(self):
        while True:
            id = await self.queue.get()
            job = None
            try:
                if (
                    id in self.cancelled
                    or self.store.get("task", id)["state"] == "cancelled"
                ):
                    continue
                job = asyncio.create_task(self.execute(id))
                self.running[id] = job
                await asyncio.wait_for(job, timeout=self.timeout_seconds)
            except asyncio.TimeoutError:
                self.finish(
                    id, "timed_out", f"Workflow exceeded {self.timeout_seconds} seconds"
                )
            except asyncio.CancelledError:
                if id not in self.cancelled:
                    self.finish(
                        id,
                        "interrupted",
                        "Service shutdown; execution checkpoint preserved",
                    )
                    raise
                self.finish(id, "cancelled", "Cancelled by operator")
            except Exception as exc:
                self.finish(id, "failed", type(exc).__name__)
            finally:
                if job and not job.done():
                    job.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await job
                self.release_robot(id)
                self.running.pop(id, None)
                self.cancelled.discard(id)
                self.queue.task_done()

    def finish(self, id, state, error=None):
        task = self.store.get("task", id)
        task.update(state=state, error=error)
        for step in task["steps"]:
            if step["state"] == "running":
                step.update(state=state, finished_at=now())
        self.event(task, state, error or "All registered workflow stages completed.")
        self.store.audit("orchestrator", "task." + state, {"id": id, "error": error})

    def release_robot(self, task_id):
        for robot in self.store.all("robot"):
            if robot["mission_id"] == task_id:
                robot.update(
                    status="emergency-stop" if robot["estop"] else "idle",
                    mission_id=None,
                )
                self.store.put("robot", robot)
        for agent in self.store.all("agent"):
            if agent["status"] == "running":
                agent["status"] = "idle"
                self.store.put("agent", agent)

    async def execute(self, id):
        task = self.store.get("task", id)
        task.update(state="running", started_at=now())
        self.event(task, "started", "Executing the persisted registered plan.")
        results = [s["output"] for s in task["steps"] if s["state"] == "completed"]
        for index, step in enumerate(task["steps"]):
            if step["state"] == "completed":
                continue
            if id in self.cancelled:
                raise asyncio.CancelledError()
            if (
                task["workflow"] == "comfort-plan"
                and step["agent"] == "automation"
                and not task.get("approval")
            ):
                task.update(
                    state="awaiting_approval",
                    checkpoint={
                        "digest": self.digest(task),
                        "scope": "publish-disabled-rule",
                        "requested_at": now(),
                    },
                )
                self.event(
                    task,
                    "approval_required",
                    "Review the evidence and draft. Approval only publishes a disabled rule; no device action occurs.",
                )
                return
            step.update(state="running", started_at=now())
            agent = self.store.get("agent", step["agent"])
            agent.update(status="running", runs=agent["runs"] + 1)
            self.store.put("agent", agent)
            self.event(
                task,
                "delegated",
                f"{step['delegated_by']} delegated {step['agent']} within its registered scope.",
                step["agent"],
                {"step_id": step["id"], "permission": step["permission"]},
            )
            await asyncio.sleep(0.05)
            output = await self.step(step["agent"], task, results)
            validate_result(step["agent"], output)
            results.append(output)
            task["context"]["outputs"][step["agent"]] = output
            step.update(
                state="completed",
                output=output,
                finished_at=now(),
                summary=f"{step['agent']} produced a validated structured result; see output and evidence timestamps.",
            )
            agent["status"] = "idle"
            self.store.put("agent", agent)
            self.event(
                task,
                "step_completed",
                step["summary"],
                step["agent"],
                {"step_id": step["id"]},
            )
            self.store.audit(
                step["agent"],
                "task.step",
                {"id": id, "step": index, "state": "completed"},
            )
        task["result"] = results[-1]
        self.store.put("task", task)
        self.finish(id, "completed")

    async def step(self, agent, task, results):
        from .security import require_permission

        expected = WORKFLOWS.get(task["workflow"], [])
        if [s["agent"] for s in task["steps"]] != expected or agent not in expected:
            raise HTTPException(403, "Workflow plan exceeds registered delegation")
        step = next(s for s in task["steps"] if s["agent"] == agent)
        if (
            step.get("delegated_by") not in ("planner", "operator")
            or step.get("permission") != REQUIRED[agent]
        ):
            raise HTTPException(403, "Invalid delegation capability")
        require_permission(agent, REQUIRED[agent])
        if task["workflow"] == "comfort-plan" and agent not in ("security", "planner"):
            delegated = (
                task["context"]["outputs"].get("planner", {}).get("delegations", [])
            )
            if not any(
                d["id"] == step["id"]
                and d["agent"] == agent
                and d["permission"] == REQUIRED[agent]
                for d in delegated
            ):
                raise HTTPException(
                    403, "Planner has not delegated this stage within its scope"
                )
        if agent == "memory":
            return await self.memory.retrieve(task["subject"])
        if agent == "planner" and task["workflow"] == "comfort-plan":
            return {
                "summary": "Decompose the request into memory retrieval, measured telemetry review, an optional routine draft, and human approval.",
                "delegations": task["plan"],
                "proposals_only": True,
            }
        if agent == "monitor":
            return {
                "active_alerts": len(
                    [a for a in self.store.all("alert") if a["status"] == "active"]
                ),
                "sensors_online": len(
                    [s for s in self.store.all("sensor") if s["status"] == "online"]
                ),
                "readings": [
                    {
                        "id": s["id"],
                        "value": s["value"],
                        "unit": s["unit"],
                        "timestamp": s["updated_at"],
                        "source": s["source"],
                    }
                    for s in self.store.all("sensor")
                    if s["metric"] == "co2" and s["status"] == "online"
                ],
            }
        if agent == "environment" and task["workflow"] == "comfort-plan":
            readings = task["context"]["outputs"]["monitor"]["readings"]
            if task.get("room_id"):
                readings = [r for r in readings if r["id"] == task["room_id"] + "-co2"]
            if not readings:
                raise ValueError("No online evidence for a comfort plan")
            highest = max(readings, key=lambda r: r["value"])
            room = highest["id"].removesuffix("-co2")
            draft = {
                "id": "task-" + task["id"],
                "name": "Reviewed fresh air · " + self.store.get("room", room)["name"],
                "room_id": room,
                "metric": "co2",
                "operator": "above",
                "threshold": 900,
                "actions": [{"device_id": room + "-ventilation", "value": 75}],
                "priority": 60,
                "trigger": "event",
                "interval_seconds": 300,
                "enabled": False,
                "last_run": 0,
                "cooldown_seconds": 60,
            }
            task["context"]["draft_rule"] = draft
            return {
                "evidence": highest,
                "threshold_exceeded": highest["value"] > 900,
                "summary": "Optional ventilation routine proposed from recorded telemetry; no diagnosis or device action.",
                "draft_rule": draft,
                "requires_human_approval": True,
            }
        if agent == "automation":
            if (
                task["workflow"] != "comfort-plan"
                or not task.get("approval")
                or task["approval"]["digest"] != self.digest(task)
            ):
                raise HTTPException(403, "Human approval for this draft is required")
            from .simulation import Automation, Control

            draft = task["context"]["draft_rule"]
            Automation(self.store, Control(self.store)).validate(draft)
            self.store.put(
                "rule",
                {
                    **draft,
                    "enabled": False,
                    "approved_by": task["approval"]["actor"],
                    "source_task": task["id"],
                },
            )
            self.store.audit(
                "automation",
                "routine.published_disabled",
                {"task_id": task["id"], "rule_id": draft["id"]},
            )
            return {
                "rule_id": draft["id"],
                "enabled": False,
                "device_actions": 0,
                "approved_by": task["approval"]["actor"],
            }
        return await self._handle(agent, task, results)

    async def _handle(self, agent, task, results):
        if agent == "security":
            if not self.store.verify_audit():
                raise ValueError("Audit chain integrity check failed")
            return {
                "policy": "passed",
                "scope": task["workflow"],
                "executable_steps": "registered handlers only",
            }
        if agent == "environment":
            return {
                "recommendations": recommendations(self.store),
                "execution_privileges": False,
            }
        if agent == "diagnostics":
            return {
                "database": "online",
                "audit_chain": self.store.verify_audit(),
                "model": await self.models.health(),
                "sensors": len(self.store.all("sensor")),
            }
        if agent == "research":
            result = await self.gateway.research(task["subject"])
            record = {
                "id": "research-" + task["id"],
                "task_id": task["id"],
                "subject": task["subject"],
                "timestamp": now(),
                **result,
            }
            self.store.put("research", record)
            return record
        if agent == "planner":
            return {
                "summary": "Review complete. Recommendations require operator review; no device actions were requested.",
                "findings": list(results),
                "proposals_only": True,
            }
        if agent == "robotics":
            for progress in range(0, 101, 10):
                robot = self.store.get("robot", task["robot_id"])
                if (
                    robot["estop"]
                    or not robot["interlock"]
                    or not self.store.get("settings", "main")["autonomous"]
                ):
                    raise RuntimeError("Robot safety gate interrupted mission")
                robot.update(status="navigating", progress=progress)
                self.store.put("robot", robot)
                await asyncio.sleep(0.4)
            robot.update(
                room_id=task["room_id"],
                battery=max(0, robot["battery"] - 2),
                status="idle",
            )
            self.store.put("robot", robot)
            return {
                "robot_id": robot["id"],
                "destination": robot["room_id"],
                "simulated": True,
                "progress": 100,
            }
        raise ValueError("Unregistered workflow step")
