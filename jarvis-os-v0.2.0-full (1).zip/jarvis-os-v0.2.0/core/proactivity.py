"""Evidence-based local trend advice; no actuator access and no fabricated trends."""

import hashlib
from datetime import datetime, timezone
from .storage import now


class Proactivity:
    def __init__(self, store):
        self.store = store

    def evaluate(self):
        preference = self.store.get("settings", "main").get("proactivity", 35)
        if not preference:
            return []
        fresh = []
        for sensor in self.store.all("sensor"):
            if (
                sensor["metric"] not in ("co2", "temperature")
                or sensor["status"] != "online"
            ):
                continue
            points = self.store.history(sensor["room_id"], sensor["metric"], 12)
            if len(points) < 4:
                continue
            elapsed = (
                datetime.fromisoformat(points[-1]["timestamp"])
                - datetime.fromisoformat(points[0]["timestamp"])
            ).total_seconds()
            age = (
                datetime.now(timezone.utc)
                - datetime.fromisoformat(points[-1]["timestamp"])
            ).total_seconds()
            delta = points[-1]["value"] - points[0]["value"]
            threshold = (100 if sensor["metric"] == "co2" else 1.5) * (
                1.5 - preference / 100
            )
            if elapsed < 30 or age > 120 or age < 0 or delta < threshold:
                continue
            id = hashlib.sha256((sensor["id"] + ":rising").encode()).hexdigest()[:16]
            existing = self.store.get("suggestion", id)
            if existing and (
                existing["status"] != "open"
                or (
                    datetime.now(timezone.utc)
                    - datetime.fromisoformat(existing["updated_at"])
                ).total_seconds()
                < 300
            ):
                continue
            evidence = {
                "sensor_id": sensor["id"],
                "metric": sensor["metric"],
                "unit": sensor["unit"],
                "sample_count": len(points),
                "first": points[0],
                "last": points[-1],
                "delta": round(delta, 2),
                "elapsed_seconds": elapsed,
                "source": sensor["source"],
            }
            suggestion = {
                "id": id,
                "room_id": sensor["room_id"],
                "metric": sensor["metric"],
                "title": f"Rising {sensor['metric']} in {self.store.get('room', sensor['room_id'])['name']}",
                "detail": f"Recorded increase of {delta:.1f} {sensor['unit']} across {len(points)} samples. Review ventilation or climate conditions; this is an observation, not a diagnosis.",
                "evidence": evidence,
                "status": "open",
                "created_at": (existing or {}).get("created_at", now()),
                "updated_at": now(),
                "can_create_routine": sensor["metric"] == "co2",
                "uncertainty": "Threshold-based advice from simulated readings; no causal inference or hardware action.",
            }
            self.store.put("suggestion", suggestion)
            self.store.audit(
                "monitor",
                "suggestion.observed",
                {"id": id, "sensor_id": sensor["id"], "delta": round(delta, 2)},
            )
            fresh.append(suggestion)
        return fresh
