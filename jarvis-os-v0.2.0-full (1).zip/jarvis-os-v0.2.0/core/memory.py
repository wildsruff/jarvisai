"""Explicitly approved memory, conservative contradictions and pluggable retrieval."""

import hashlib
import asyncio
import json
import math
import os
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Protocol
import httpx
from fastapi import HTTPException
from .storage import now, uid


def normalize(text):
    return " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", text).lower()))


def claim(text):
    text = normalize(text)
    found = re.match(r"(?:my|the) (.{1,80}?) (?:is|are) (.+)", text)
    if found:
        return "self:" + found[1], found[2]
    found = re.match(
        r"i (?:prefer|like) (.+?) (?:at|to be) (\d+(?: \d+)?)\s*(?:c|degrees|°c)?$",
        text,
    )
    if found:
        return "preference:" + found[1] + ":temperature", found[2]
    found = re.match(r"i (like|dislike|avoid) (.+)", text)
    if found:
        return "preference:" + found[2], "positive" if found[
            1
        ] == "like" else "negative"
    return None, None


class RetrievalAdapter(Protocol):
    async def rank(
        self, query: str, memories: list[dict]
    ) -> list[tuple[float, dict]]: ...


class LexicalRetrieval:
    name = "lexical-concepts"
    GROUPS = [
        {"study", "office", "workspace"},
        {"temperature", "warm", "hot", "cool", "climate", "cooling"},
        {"air", "ventilation", "co2", "carbon", "dioxide"},
        {"prefer", "preferred", "preference", "like"},
        {"routine", "workflow", "automation"},
    ]

    def terms(self, text):
        terms = set(normalize(text).split()) - {
            "the",
            "and",
            "is",
            "are",
            "what",
            "how",
            "my",
            "your",
            "you",
            "i",
            "a",
            "to",
            "in",
            "of",
        }
        for i, group in enumerate(self.GROUPS):
            if terms & group:
                terms.add("concept" + str(i))
        return terms

    async def rank(self, query, memories):
        terms = self.terms(query)
        return sorted(
            [
                (len(terms & self.terms(m["content"])) / max(1, len(terms)), m)
                for m in memories
            ],
            key=lambda pair: pair[0],
            reverse=True,
        )


class LocalEmbeddings:
    """Real local embeddings only when configured; no fabricated vectors."""

    def __init__(self, store, models, model):
        self.store, self.models, self.model = store, models, model
        self.name = f"{models.provider}:{models.url}:{model}"

    async def vectors(self, texts):
        if self.models.provider == "mock":
            raise ValueError("Embedding requires a real local provider")
        ollama = self.models.provider == "ollama"
        async with httpx.AsyncClient(
            timeout=5, trust_env=False, follow_redirects=False
        ) as client:
            r = await client.post(
                self.models.url + ("/api/embed" if ollama else "/v1/embeddings"),
                json={"model": self.model, "input": texts},
            )
            r.raise_for_status()
            if len(r.content) > 2000000:
                raise ValueError("Oversized embedding response")
            data = r.json()
        vectors = (
            data["embeddings"]
            if ollama
            else [
                v["embedding"] for v in sorted(data["data"], key=lambda x: x["index"])
            ]
        )
        if (
            len(vectors) != len(texts)
            or not vectors
            or not 1 <= len(vectors[0]) <= 4096
        ):
            raise ValueError("Invalid embedding dimensions")
        for vector in vectors:
            if (
                len(vector) != len(vectors[0])
                or any(
                    type(v) not in (float, int) or not math.isfinite(v) for v in vector
                )
                or not any(vector)
                or not 1e-12 <= math.hypot(*vector) <= 1e8
            ):
                raise ValueError("Invalid embedding vector")
        return vectors

    async def rank(self, query, memories):
        query_vector = (await self.vectors([query]))[0]
        cached = {}
        missing = []
        for memory in memories:
            fingerprint = hashlib.sha256(memory["content"].encode()).hexdigest()
            with self.store.lock:
                row = self.store.db.execute(
                    "SELECT vector FROM memory_vectors WHERE memory_id=? AND fingerprint=? AND adapter=?",
                    (memory["id"], fingerprint, self.name),
                ).fetchone()
            if row:
                cached[memory["id"]] = json.loads(row[0])
            else:
                missing.append((memory, fingerprint))
        for offset in range(0, len(missing), 16):
            batch = missing[offset : offset + 16]
            vectors = await self.vectors([m["content"] for m, _ in batch])
            with self.store.lock:
                for (m, fingerprint), vector in zip(batch, vectors):
                    cached[m["id"]] = vector
                    current = self.store.get("memory", m["id"])
                    if (
                        not current
                        or current["expires_at"] <= now()
                        or hashlib.sha256(current["content"].encode()).hexdigest()
                        != fingerprint
                    ):
                        continue
                    self.store.db.execute(
                        "INSERT OR REPLACE INTO memory_vectors VALUES(?,?,?,?)",
                        (m["id"], fingerprint, self.name, json.dumps(vector)),
                    )
        ranked = []
        for memory in memories:
            vector = cached[memory["id"]]
            if len(vector) != len(query_vector):
                raise ValueError(
                    "Embedding model dimensions changed; use a new model identity"
                )
            score = sum(a * b for a, b in zip(vector, query_vector)) / (
                math.sqrt(sum(v * v for v in vector))
                * math.sqrt(sum(v * v for v in query_vector))
            )
            ranked.append((score, memory))
        return sorted(ranked, key=lambda pair: pair[0], reverse=True)


class MemoryService:
    def __init__(self, store, models=None):
        self.store, self.models = store, models

    def active(self):
        return [
            m for m in self.store.all("memory") if m.get("expires_at", now()) > now()
        ]

    def annotated(self):
        memories = self.active()
        groups = {}
        for m in memories:
            key, value = claim(m["content"])
            if key:
                groups.setdefault(key, []).append((m["id"], value))
        return [
            {
                **m,
                "conflicts": [
                    id
                    for id, value in groups.get(claim(m["content"])[0], [])
                    if id != m["id"] and value != claim(m["content"])[1]
                ],
            }
            for m in memories
        ]

    def conflicts(self, content, exclude=None):
        key, value = claim(content)
        return [
            m["id"]
            for m in self.active()
            if m["id"] != exclude
            and key
            and claim(m["content"])[0] == key
            and claim(m["content"])[1] != value
        ]

    def save(self, body, id, actor="admin"):
        data = body.model_dump() if hasattr(body, "model_dump") else dict(body)
        if not data["content"].strip():
            raise HTTPException(422, "Memory content cannot be blank")
        with self.store.transaction():
            old = self.store.get("memory", id)
            duplicate = next(
                (
                    m
                    for m in self.active()
                    if m["id"] != id
                    and normalize(m["content"]) == normalize(data["content"])
                ),
                None,
            )
            if duplicate:
                if old:
                    raise HTTPException(
                        409,
                        "Another memory already contains this information; correct or delete the duplicate explicitly",
                    )
                return {**duplicate, "deduplicated": True}
            conflicts = self.conflicts(data["content"], id)
            if old and not self.history(id):
                self.store.db.execute(
                    "INSERT INTO memory_revisions(memory_id,revision,actor,timestamp,snapshot) VALUES(?,?,?,?,?)",
                    (id, 0, "legacy", old.get("updated_at", now()), json.dumps(old)),
                )
            data.update(
                id=id,
                created_at=old["created_at"] if old else now(),
                updated_at=now(),
                expires_at=(
                    datetime.now(timezone.utc) + timedelta(days=data["retention_days"])
                ).isoformat(),
                revision=(old or {}).get("revision", 0) + 1,
                conflicts=conflicts,
            )
            self.store.put("memory", data)
            self.store.db.execute(
                "INSERT INTO memory_revisions(memory_id,revision,actor,timestamp,snapshot) VALUES(?,?,?,?,?)",
                (id, data["revision"], actor, now(), json.dumps(data)),
            )
            self.store.db.execute("DELETE FROM memory_vectors WHERE memory_id=?", (id,))
            if old:
                self.store.redact_memory_references({id})
            self.store.audit(
                actor,
                "memory.updated" if old else "memory.created",
                {"id": id, "revision": data["revision"], "conflicts": conflicts},
            )
        return data

    def history(self, id):
        with self.store.lock:
            return [
                {**dict(r), "snapshot": json.loads(r["snapshot"])}
                for r in self.store.db.execute(
                    "SELECT * FROM memory_revisions WHERE memory_id=? ORDER BY revision",
                    (id,),
                )
            ]

    def delete(self, id, actor="admin"):
        with self.store.transaction():
            original = self.store.get("memory", id) or {}
            self.store.delete("memory", id)
            self.store.db.execute(
                "DELETE FROM memory_revisions WHERE memory_id=?", (id,)
            )
            self.store.db.execute("DELETE FROM memory_vectors WHERE memory_id=?", (id,))
            self.store.redact_memory_references({id})
            for c in self.store.all("memory_candidate"):
                if c.get("memory_id") == id or normalize(c["content"]) == normalize(
                    original.get("content", "")
                ):
                    self.store.delete("memory_candidate", c["id"])
            self.store.audit(actor, "memory.deleted", {"id": id})

    def extract(self, text, conversation_id, message_id):
        settings = self.store.get("settings", "main") or {}
        if not settings.get("extract_memories", True):
            return []
        candidates = []
        for sentence in re.split(r"(?<=[.!?])\s+|\n+", text):
            sentence = sentence.strip()[:1000]
            if not re.match(
                r"^(?:remember that |please remember (?:that )?)?(?:i (?:prefer|like|dislike|avoid|am|have)|my [\w ]{1,70} (?:is|are))\b",
                sentence,
                re.I,
            ):
                continue
            sentence = re.sub(
                r"^(?:remember that |please remember (?:that )?)",
                "",
                sentence,
                flags=re.I,
            )
            secret = bool(
                re.search(
                    r"password|api.?key|secret|access.?token|pin code", sentence, re.I
                )
            )
            if secret:
                # Do not retain credential values, even in pending candidates.
                continue
            normalized = normalize(sentence)
            if any(
                normalize(m["content"]) == normalized
                for m in self.active() + self.store.all("memory_candidate")
            ):
                continue
            sensitive = bool(
                re.search(
                    r"health|medical|allerg|diagnos|medicat|address|bank|financial|child|disab",
                    sentence,
                    re.I,
                )
            )
            candidate = {
                "id": uid(),
                "content": sentence,
                "kind": "semantic",
                "source": f"conversation:{conversation_id}:{message_id}",
                "confidence": 0.65,
                "verified": False,
                "status": "pending",
                "sensitive": sensitive,
                "requires_approval": True,
                "extractor": "explicit-first-person-patterns-v1",
                "created_at": now(),
                "expires_at": (
                    datetime.now(timezone.utc) + timedelta(days=7)
                ).isoformat(),
                "conflicts": self.conflicts(sentence),
                "retention_days": settings.get("memory_retention_days", 30),
            }
            self.store.put("memory_candidate", candidate)
            candidates.append(candidate)
            if len(candidates) >= 5:
                break
        return candidates

    def review(self, id, decision, actor="admin"):
        with self.store.transaction():
            c = self.store.get("memory_candidate", id)
            if not c or c["expires_at"] <= now():
                raise HTTPException(404, "Candidate not found or expired")
            if c["status"] != "pending":
                raise HTTPException(409, "Candidate already reviewed")
            if decision != "approve":
                c.update(status="rejected", reviewed_at=now(), reviewed_by=actor)
                self.store.put("memory_candidate", c)
                self.store.audit(actor, "memory.candidate_rejected", {"id": id})
                return c
            fields = {
                key: c[key]
                for key in (
                    "kind",
                    "content",
                    "source",
                    "confidence",
                    "verified",
                    "retention_days",
                    "sensitive",
                )
            }
            saved = self.save(fields, uid(), actor)
            c.update(
                status="approved",
                memory_id=saved["id"],
                reviewed_at=now(),
                reviewed_by=actor,
            )
            self.store.put("memory_candidate", c)
            self.store.audit(
                actor, "memory.candidate_approved", {"id": id, "memory_id": saved["id"]}
            )
            return c

    async def retrieve(self, query, limit=5):
        active = self.active()
        values = {}
        for m in active:
            key, value = claim(m["content"])
            if key:
                values.setdefault(key, set()).add(value)
        eligible = [
            m for m in active if len(values.get(claim(m["content"])[0], set())) <= 1
        ]
        memories = eligible[:500]
        adapter = LexicalRetrieval()
        model = os.getenv("JARVIS_EMBEDDING_MODEL")
        failure = None
        if model and self.models:
            adapter = LocalEmbeddings(self.store, self.models, model)
        try:
            async with asyncio.timeout(8):
                ranked = await adapter.rank(query, memories)
        except (httpx.HTTPError, ValueError, KeyError, TypeError, TimeoutError) as exc:
            failure = type(exc).__name__
            adapter = LexicalRetrieval()
            ranked = await adapter.rank(query, memories)
        live = {m["id"]: m for m in self.annotated()}
        matches = [
            {**m, "relevance": round(score, 4)}
            for score, m in ranked
            if score > 0.05
            and (live.get(m["id"]) or {}).get("updated_at") == m["updated_at"]
            and not live[m["id"]]["conflicts"]
            and m["expires_at"] > now()
        ][:limit]
        return {
            "method": adapter.name,
            "fallback_error": failure,
            "memories": matches,
            "excluded_conflicts": len(active) - len(eligible),
            "index_limit": 500,
            "truncated": len(eligible) > 500,
        }
