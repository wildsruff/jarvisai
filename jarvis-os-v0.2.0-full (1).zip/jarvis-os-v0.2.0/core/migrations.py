"""Forward-only transactional migrations; v0.1 databases are adopted intact."""

MIGRATIONS = {
    1: [
        "CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)"
    ],
    2: [
        "CREATE TABLE memory_revisions(id INTEGER PRIMARY KEY, memory_id TEXT NOT NULL, revision INTEGER NOT NULL, actor TEXT NOT NULL, timestamp TEXT NOT NULL, snapshot TEXT NOT NULL)",
        "CREATE INDEX memory_revision_owner ON memory_revisions(memory_id,revision)",
        "CREATE TABLE memory_vectors(memory_id TEXT NOT NULL, fingerprint TEXT NOT NULL, adapter TEXT NOT NULL, vector TEXT NOT NULL, PRIMARY KEY(memory_id,adapter))",
        "CREATE TABLE workflow_events(seq INTEGER PRIMARY KEY, task_id TEXT NOT NULL, timestamp TEXT NOT NULL, agent TEXT NOT NULL, event TEXT NOT NULL, summary TEXT NOT NULL, payload TEXT NOT NULL)",
        "CREATE INDEX workflow_event_owner ON workflow_events(task_id,seq)",
    ],
}


def migrate(store):
    from .storage import now

    with store.lock:
        exists = store.db.execute(
            "SELECT 1 FROM sqlite_master WHERE name='schema_migrations'"
        ).fetchone()
        current = (
            store.db.execute(
                "SELECT COALESCE(MAX(version),0) FROM schema_migrations"
            ).fetchone()[0]
            if exists
            else 0
        )
        if current > max(MIGRATIONS):
            raise RuntimeError(
                "Database schema is newer than this application; refusing to start"
            )
        for version, statements in MIGRATIONS.items():
            if version <= current:
                continue
            with store.transaction():
                for statement in statements:
                    store.db.execute(statement)
                store.db.execute(
                    "INSERT INTO schema_migrations VALUES(?,?)", (version, now())
                )
