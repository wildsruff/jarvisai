"""Small transactional repository. JSON payloads allow versioned adapter contracts.

The audit chain detects accidental/tampered history given a trusted external head;
it is not tamper-proof against a host administrator. See docs/security.md.
"""

import hashlib
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


def uid():
    return uuid4().hex[:16]


class Store:
    def __init__(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        from .migrations import MIGRATIONS

        if self.db.execute(
            "SELECT 1 FROM sqlite_master WHERE name='schema_migrations'"
        ).fetchone():
            if self.db.execute(
                "SELECT COALESCE(MAX(version),0) FROM schema_migrations"
            ).fetchone()[0] > max(MIGRATIONS):
                self.db.close()
                raise RuntimeError(
                    "Database schema is newer than this application; refusing to start"
                )
        self.db.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;
            PRAGMA secure_delete=ON;
            CREATE TABLE IF NOT EXISTS entities (
                kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
                PRIMARY KEY(kind,id));
            CREATE TABLE IF NOT EXISTS audit (
                seq INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
                actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL,
                previous TEXT NOT NULL, hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS readings (
                id INTEGER PRIMARY KEY, timestamp TEXT NOT NULL,
                room TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS readings_lookup ON readings(room,metric,id);
            CREATE INDEX IF NOT EXISTS readings_time ON readings(timestamp);
        """)
        from .migrations import migrate

        try:
            migrate(self)
        except BaseException:
            self.db.close()
            raise
        self._audit_cache = None
        self.redact_memory_references()

    @contextmanager
    def transaction(self):
        with self.lock:
            nested = self.db.in_transaction
            savepoint = "sp_" + uid()
            self.db.execute("SAVEPOINT " + savepoint if nested else "BEGIN IMMEDIATE")
            try:
                yield
                self.db.execute(
                    "RELEASE SAVEPOINT " + savepoint if nested else "COMMIT"
                )
            except BaseException:
                if nested:
                    self.db.execute("ROLLBACK TO SAVEPOINT " + savepoint)
                    self.db.execute("RELEASE SAVEPOINT " + savepoint)
                else:
                    self.db.execute("ROLLBACK")
                raise

    def all(self, kind):
        with self.lock:
            return [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT data FROM entities WHERE kind=? ORDER BY rowid", (kind,)
                )
            ]

    def latest(self, kind, limit=60):
        with self.lock:
            return [
                json.loads(r[0])
                for r in self.db.execute(
                    "SELECT data FROM entities WHERE kind=? ORDER BY rowid DESC LIMIT ?",
                    (kind, limit),
                )
            ]

    def cached_integrity(self):
        import time

        if self._audit_cache is None or time.monotonic() - self._audit_cache[0] > 10:
            self._audit_cache = (time.monotonic(), self.verify_audit(), now())
        return {
            "valid": self._audit_cache[1],
            "checked_at": self._audit_cache[2],
            "cache_seconds": 10,
        }

    def get(self, kind, id):
        with self.lock:
            row = self.db.execute(
                "SELECT data FROM entities WHERE kind=? AND id=?", (kind, id)
            ).fetchone()
            return json.loads(row[0]) if row else None

    def put(self, kind, data):
        with self.lock:
            if kind == "task":
                data = self._redact_task_memory(data)
            self.db.execute(
                "INSERT INTO entities VALUES (?,?,?) ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data",
                (kind, data["id"], json.dumps(data, sort_keys=True)),
            )
        return data

    def delete(self, kind, id):
        with self.lock:
            self.db.execute("DELETE FROM entities WHERE kind=? AND id=?", (kind, id))

    def audit(self, actor, action, detail):
        with self.lock:
            self._audit_cache = None
            previous = self.db.execute(
                "SELECT hash FROM audit ORDER BY seq DESC LIMIT 1"
            ).fetchone()
            previous = previous[0] if previous else "0" * 64
            stamp, detail = now(), json.dumps(detail, sort_keys=True)
            digest = hashlib.sha256(
                json.dumps([stamp, actor, action, detail, previous]).encode()
            ).hexdigest()
            self.db.execute(
                "INSERT INTO audit(timestamp,actor,action,detail,previous,hash) VALUES(?,?,?,?,?,?)",
                (stamp, actor, action, detail, previous, digest),
            )

    def logs(self, limit=100):
        with self.lock:
            return [
                {**dict(r), "detail": json.loads(r["detail"])}
                for r in self.db.execute(
                    "SELECT * FROM audit ORDER BY seq DESC LIMIT ?", (limit,)
                )
            ]

    def verify_audit(self):
        previous = "0" * 64
        with self.lock:
            for row in self.db.execute("SELECT * FROM audit ORDER BY seq"):
                digest = hashlib.sha256(
                    json.dumps(
                        [
                            row["timestamp"],
                            row["actor"],
                            row["action"],
                            row["detail"],
                            previous,
                        ]
                    ).encode()
                ).hexdigest()
                if row["previous"] != previous or row["hash"] != digest:
                    return False
                previous = digest
        return True

    def reading(self, room, metric, value, timestamp=None):
        with self.lock:
            self.db.execute(
                "INSERT INTO readings(timestamp,room,metric,value) VALUES(?,?,?,?)",
                (timestamp or now(), room, metric, value),
            )

    def history(self, room, metric, limit=120):
        with self.lock:
            rows = self.db.execute(
                "SELECT timestamp,value FROM readings WHERE room=? AND metric=? ORDER BY id DESC LIMIT ?",
                (room, metric, limit),
            ).fetchall()
            return [dict(r) for r in reversed(rows)]

    def prune(self):
        with self.transaction():
            self.db.execute(
                "DELETE FROM readings WHERE timestamp < ?",
                ((datetime.now(timezone.utc) - timedelta(days=7)).isoformat(),),
            )
            expired = {
                row[0]
                for row in self.db.execute(
                    "SELECT id FROM entities WHERE kind='memory' AND json_extract(data,'$.expires_at') < ?",
                    (now(),),
                )
            }
            self.db.execute(
                "DELETE FROM entities WHERE kind='memory' AND json_extract(data,'$.expires_at') IS NOT NULL AND json_extract(data,'$.expires_at') < ?",
                (now(),),
            )
            self.db.execute(
                "DELETE FROM entities WHERE kind='memory_candidate' AND json_extract(data,'$.expires_at') < ?",
                (now(),),
            )
            self.db.execute(
                "DELETE FROM memory_revisions WHERE memory_id NOT IN (SELECT id FROM entities WHERE kind='memory')"
            )
            self.db.execute(
                "DELETE FROM memory_vectors WHERE memory_id NOT IN (SELECT id FROM entities WHERE kind='memory')"
            )
            self.redact_memory_references(expired)

    def _redact_task_memory(self, data, ids=None):
        cache = {}

        def redact(value):
            if isinstance(value, dict):
                if "id" in value and "content" in value and "confidence" in value:
                    id = value["id"]
                    if id not in cache:
                        cache[id] = self.get("memory", id)
                    current = cache[id]
                    if (
                        (ids is not None and id in ids)
                        or not current
                        or current.get("expires_at", "") <= now()
                        or value.get("revision", 0) != current.get("revision", 0)
                    ):
                        return {
                            "id": id,
                            "redacted": True,
                            "reason": "memory_unavailable_or_revised",
                        }
                return {key: redact(item) for key, item in value.items()}
            if isinstance(value, list):
                return [redact(item) for item in value]
            return value

        return redact(data)

    def redact_memory_references(self, ids=None):
        """Remove deleted/expired/revised snapshots, including legacy task copies."""
        if ids is not None and not ids:
            return
        for task in self.all("task"):
            updated = self._redact_task_memory(task, ids)
            if updated != task:
                self.put("task", updated)

    def close(self):
        self.db.close()
