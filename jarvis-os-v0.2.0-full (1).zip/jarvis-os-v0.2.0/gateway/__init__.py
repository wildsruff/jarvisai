"""Separately deployed data-only external intelligence domain."""
