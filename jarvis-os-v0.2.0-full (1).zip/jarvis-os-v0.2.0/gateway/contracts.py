from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, HttpUrl


class ResearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scope: Literal["research"]
    subject: str = Field(min_length=1, max_length=500)


class Source(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(max_length=300)
    url: HttpUrl
    evidence: Literal["reference-only", "retrieved"]


class ResearchResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    mode: Literal["simulated", "offline", "retrieved"]
    trust: Literal["untrusted-data"]
    summary: str = Field(max_length=12000)
    sources: list[Source] = Field(max_length=20)
    next_steps: list[str] = Field(max_length=20)
