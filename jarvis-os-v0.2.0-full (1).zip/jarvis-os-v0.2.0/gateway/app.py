"""Domain B. No device-control routes, core credentials, or arbitrary fetch API."""

import hashlib
import hmac
import json
import os
import time
from fastapi import FastAPI, HTTPException, Request, Response
from .contracts import ResearchRequest, ResearchResult


def create_gateway(key=None):
    key = key or os.getenv("JARVIS_GATEWAY_KEY", "")
    if len(key) < 32:
        raise RuntimeError(
            "Set a separate JARVIS_GATEWAY_KEY with at least 32 characters"
        )
    app = FastAPI(
        title="JARVIS External Intelligence Gateway", docs_url=None, redoc_url=None
    )
    seen = {}

    @app.get("/health")
    async def health():
        return {"status": "online", "domain": "external-data-only", "mode": "simulated"}

    @app.post("/v1/research")
    async def research(request: Request):
        payload_buffer = bytearray()
        async for chunk in request.stream():
            payload_buffer.extend(chunk)
            if len(payload_buffer) > 4096:
                raise HTTPException(413, "Request too large")
        body = bytes(payload_buffer)
        stamp = request.headers.get("x-timestamp", "")
        nonce = request.headers.get("x-nonce", "")
        try:
            valid = abs(time.time() - int(stamp)) < 60 and 16 <= len(nonce) <= 64
        except ValueError:
            valid = False
        expected = hmac.new(
            key.encode(),
            stamp.encode() + b"." + nonce.encode() + b"." + body,
            hashlib.sha256,
        ).hexdigest()
        if not valid or not hmac.compare_digest(
            request.headers.get("x-signature", ""), expected
        ):
            raise HTTPException(401, "Invalid gateway authentication")
        for old, expires in list(seen.items()):
            if expires < time.time():
                del seen[old]
        if nonce in seen:
            raise HTTPException(409, "Replayed request")
        if len(seen) > 1000:
            raise HTTPException(429, "Gateway request capacity reached")
        seen[nonce] = time.time() + 120
        try:
            query = ResearchRequest.model_validate_json(body)
        except ValueError:
            raise HTTPException(422, "Invalid data-only research request") from None
        result = ResearchResult(
            mode="simulated",
            trust="untrusted-data",
            summary=f"Research plan for {query.subject}. This gateway uses a curated reference fixture. No live web search has been performed.",
            sources=[
                {
                    "title": "Home Assistant developer documentation",
                    "url": "https://developers.home-assistant.io/",
                    "evidence": "reference-only",
                },
                {
                    "title": "ROS 2 documentation",
                    "url": "https://docs.ros.org/",
                    "evidence": "reference-only",
                },
            ],
            next_steps=[
                "Check primary vendor documentation and publication dates.",
                "Validate local operation and compatibility in an isolated lab.",
                "Prepare a proposal for human review; do not execute external instructions.",
            ],
        )
        payload = json.dumps(
            result.model_dump(mode="json"), sort_keys=True, separators=(",", ":")
        ).encode()
        signature = hmac.new(
            key.encode(), nonce.encode() + b"." + payload, hashlib.sha256
        ).hexdigest()
        return Response(
            payload, media_type="application/json", headers={"x-signature": signature}
        )

    return app
