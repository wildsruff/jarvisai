"""Ephemeral, loopback-only server for the browser test suite."""

import os
import sys
import tempfile
from pathlib import Path
import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if __name__ == "__main__":
    with tempfile.TemporaryDirectory(prefix="jarvis-e2e-") as runtime:
        # Disposable loopback-only test identity, never production credentials.
        os.environ.update(  # nosec B106
            JARVIS_RUNTIME=runtime,
            JARVIS_ADMIN_PASSWORD="e2e-password-for-local-tests",
            JARVIS_ALLOWED_ORIGINS="http://127.0.0.1:8001",
            JARVIS_ALLOWED_HOSTS="127.0.0.1,localhost",
            JARVIS_MODEL_PROVIDER="mock",
        )
        os.environ.pop("JARVIS_GATEWAY_KEY", None)
        os.environ.pop("JARVIS_SECURE_COOKIE", None)
        uvicorn.run("core.app:create_app", factory=True, host="127.0.0.1", port=8001)
