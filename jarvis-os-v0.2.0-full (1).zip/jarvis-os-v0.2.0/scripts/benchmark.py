"""Small in-process simulation API latency sample, not a deployment benchmark."""

import json
import os
import statistics
import secrets
import sys
import tempfile
import time
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.app import create_app  # noqa: E402


if __name__ == "__main__":
    with tempfile.TemporaryDirectory(prefix="jarvis-benchmark-") as runtime:
        password = secrets.token_urlsafe(24)
        os.environ.update(
            JARVIS_RUNTIME=runtime,
            JARVIS_MODEL_PROVIDER="mock",
            JARVIS_ADMIN_PASSWORD=password,
            JARVIS_ALLOWED_HOSTS="testserver",
        )
        os.environ.pop("JARVIS_SECURE_COOKIE", None)
        app = create_app(simulation=False)
        with TestClient(app) as client:
            session = client.post(
                "/api/login", json={"username": "admin", "password": password}
            )
            session.raise_for_status()
            durations = []
            for _ in range(40):
                start = time.perf_counter()
                response = client.get("/api/state")
                response.raise_for_status()
                durations.append((time.perf_counter() - start) * 1000)
            print(
                json.dumps(
                    {
                        "endpoint": "/api/state",
                        "requests": len(durations),
                        "p50_ms": round(statistics.median(durations), 2),
                        "p95_ms": round(sorted(durations)[37], 2),
                        "max_ms": round(max(durations), 2),
                        "context": "in-process TestClient, seeded 6-room/120-channel estate, no concurrent inference, not a hardware/network load test",
                    },
                    indent=2,
                )
            )
