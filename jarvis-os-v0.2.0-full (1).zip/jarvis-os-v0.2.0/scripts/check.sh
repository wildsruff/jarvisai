#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
.venv/bin/ruff check core gateway tests scripts
.venv/bin/ruff format --check core gateway tests scripts
.venv/bin/python -m pytest -q
npm --prefix web run build
.venv/bin/bandit -r core gateway scripts
.venv/bin/pip-audit -r requirements.txt
npm --prefix web audit
