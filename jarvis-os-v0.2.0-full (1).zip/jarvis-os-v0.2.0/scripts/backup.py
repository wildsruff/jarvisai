"""Online SQLite snapshot with exclusive, content-addressed, read-only artifacts.

Move copies to offline/WORM storage for actual administrator-resistant immutability.
"""

import argparse
import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def backup(source: Path, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix=".snapshot-", dir=directory)
    os.close(fd)
    try:
        with sqlite3.connect(f"file:{source.resolve()}?mode=ro", uri=True) as src:
            with sqlite3.connect(temporary) as dest:
                src.backup(dest)
                if dest.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("Source database integrity check failed")
                row = dest.execute(
                    "SELECT seq,hash FROM audit ORDER BY seq DESC LIMIT 1"
                ).fetchone()
        digest = hashlib.sha256(Path(temporary).read_bytes()).hexdigest()
        target = directory / f"{digest}.sqlite3"
        os.chmod(temporary, 0o400)
        try:
            os.link(temporary, target)  # Atomic creation; never overwrite a backup.
        except FileExistsError:
            if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
                raise ValueError("Existing backup is corrupt") from None
        manifest = target.with_suffix(".json")
        if not manifest.exists():
            fd = os.open(manifest, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o400)
            with os.fdopen(fd, "w") as f:
                json.dump(
                    {
                        "sha256": digest,
                        "created_at": datetime.now(timezone.utc).isoformat(),
                        "audit_seq": row[0] if row else 0,
                        "audit_head": row[1] if row else None,
                        "immutability": "application-no-overwrite; external WORM required",
                    },
                    f,
                    indent=2,
                )
                f.flush()
                os.fsync(f.fileno())
        return target
    finally:
        Path(temporary).unlink(missing_ok=True)


def restore(snapshot: Path, destination: Path) -> None:
    manifest = json.loads(snapshot.with_suffix(".json").read_text())
    data = snapshot.read_bytes()
    if hashlib.sha256(data).hexdigest() != manifest["sha256"]:
        raise ValueError("Snapshot digest mismatch")
    with sqlite3.connect(f"file:{snapshot.resolve()}?mode=ro", uri=True) as db:
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("Snapshot integrity check failed")
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["backup", "restore"])
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    if args.action == "backup":
        print(backup(args.source, args.destination))
    else:
        restore(args.source, args.destination)
        print(
            "Restored to new destination. Verify audit integrity before starting the core."
        )
