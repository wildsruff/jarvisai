#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
npm --prefix web ci --no-audit --no-fund
npm --prefix web run build
echo 'Ready. Run ./scripts/run.sh'
