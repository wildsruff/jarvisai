"""Run an isolated, scripted approval/restart demonstration. No live deployment."""

import asyncio
import contextlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.storage import Store  # noqa: E402
from core.simulation import seed  # noqa: E402
from core.models import Models  # noqa: E402
from core.memory import MemoryService  # noqa: E402
from core.workflows import Orchestrator  # noqa: E402


async def demonstrate():
    with tempfile.TemporaryDirectory(prefix="jarvis-intelligence-demo-") as directory:
        path = str(Path(directory) / "demo.db")
        store = Store(path)
        seed(store)
        model = Models(store)
        model.configure({**model.config, "provider": "mock", "context_chars": 8192})
        memory = MemoryService(store, model)
        candidate = memory.extract(
            "My preferred study temperature is 22 C.", "demo", "scripted-user-input"
        )[0]
        before_approval = await memory.retrieve("preferred study temperature")
        reviewed = memory.review(
            candidate["id"], "approve", actor="scripted-admin-review"
        )
        o = Orchestrator(store, model)
        task = await o.submit(
            {
                "workflow": "comfort-plan",
                "room_id": "office",
                "subject": "Prepare a ventilation routine for operator review",
            },
            actor="scripted-admin-review",
        )
        devices_before = store.all("device")
        worker = asyncio.create_task(o.worker())
        try:
            await asyncio.wait_for(o.queue.join(), 5)
            waiting = store.get("task", task["id"])
            if waiting["state"] != "awaiting_approval":
                raise RuntimeError(
                    "Demonstration did not reach its approval checkpoint"
                )
            o.review(task["id"], "approve", actor="scripted-admin-review")
            await asyncio.wait_for(o.queue.join(), 5)
            completed = store.get("task", task["id"])
            if completed["state"] != "completed":
                raise RuntimeError("Demonstration did not complete")
            report = {
                "mode": "isolated simulation with scripted administrator approvals; not a real human deployment approval",
                "inference_provider": "mock; no real inference performed",
                "candidate_initial_state": candidate["status"],
                "candidate_was_retrievable_before_approval": any(
                    m["source"] == candidate["source"]
                    for m in before_approval["memories"]
                ),
                "approved_memory_verified": store.get("memory", reviewed["memory_id"])[
                    "verified"
                ],
                "workflow_checkpoint": waiting["state"],
                "delegations": completed["plan"],
                "evidence": completed["context"]["outputs"]["environment"]["evidence"],
                "result": completed["result"],
                "device_state_unchanged": devices_before == store.all("device"),
                "timeline": completed["timeline"],
            }
        finally:
            worker.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await worker
        store.close()
        restarted = Store(path)
        result = await MemoryService(restarted, Models(restarted)).retrieve(
            "preferred study temperature"
        )
        report["after_database_reopen"] = {
            "schema_version": restarted.db.execute(
                "SELECT MAX(version) FROM schema_migrations"
            ).fetchone()[0],
            "workflow_state": restarted.get("task", task["id"])["state"],
            "approved_memory_retrieved": any(
                m["id"] == reviewed["memory_id"] for m in result["memories"]
            ),
            "context_budget": Models(restarted).config["context_chars"],
            "audit_integrity": restarted.verify_audit(),
        }
        restarted.close()
        return report


if __name__ == "__main__":
    print(json.dumps(asyncio.run(demonstrate()), indent=2))
