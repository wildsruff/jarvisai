#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${JARVIS_GATEWAY_KEY:?Provision the separate gateway key before starting this service}"
exec .venv/bin/uvicorn gateway.app:create_gateway --factory --host 127.0.0.1 --port 8100
