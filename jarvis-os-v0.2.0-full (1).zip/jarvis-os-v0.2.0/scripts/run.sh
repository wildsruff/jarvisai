#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -x .venv/bin/python ] || [ ! -f web/dist-next/index.html ]; then
  echo 'Run ./scripts/setup.sh first.' >&2
  exit 1
fi
echo 'JARVIS OS · simulation · http://127.0.0.1:8000'
echo 'First startup creates .runtime/admin-password (owner-readable). Sign in as admin.'
exec .venv/bin/uvicorn core.app:create_app --factory --host "${JARVIS_BIND:-127.0.0.1}" --port "${JARVIS_PORT:-8000}"
